# Lap Timer · versión 0.8

Cronómetro propio para antena GPS u-blox de 25 Hz por USB. Instalación y actualización en `LEEME-INSTALACION.md`.

## Novedades de la 0.8
- **Carril de boxes**: se marca en el editor del mapa con una línea de entrada y otra de salida. Al entrar aparece una
  pantalla amarilla que parpadea entre dos tonos, encima de todo. En resistencia lleva una cuenta atrás del tiempo
  mínimo de parada; al llegar a cero se pone verde ("YA PUEDES SALIR"). Si sales antes, queda registrada como parada
  incumplida y se avisa en rojo. El cambio de piloto se confirma desde esa pantalla.
- **Resumen al cruzar la meta**: tiempo de vuelta, delta final frente a la mejor, número de vuelta y colores de los
  sectores; en resistencia también el stint. Dura de 3 a 6 s (configurable) y se cierra tocando la pantalla.
- **Tres modos de carrera** en el menú: track day, carrera sprint y carrera de resistencia. Track day y sprint son
  iguales por ahora (el modo queda listo para diferenciarlos). El stint, el cambio de piloto y la cuenta atrás de
  boxes solo existen en resistencia, que tiene su configuración previa (pilotos en orden de relevo, tiempo mínimo de
  boxes y valores de stint).
- **Ancho de pista por línea**: cada línea (meta, sectores, entrada y salida de boxes) tiene su ancho a la izquierda y a
  la derecha, ajustable con círculos en los extremos o escribiendo los metros. Los circuitos antiguos siguen con 15 m
  a cada lado y los récords no se pierden al cambiar anchos.
- **Panel**: número de coches configurable (1 a 30) con tabla compacta cuando hay muchos, solo se tratan como coches los
  datos válidos (arregla los "18 coches"), botón para limpiar restos antiguos de Firebase, y consulta menos frecuente
  con muchos coches. Muestra paradas, paradas incumplidas y "EN BOXES".
- **Firebase más limpio**: las vueltas ya no se duplican si se pierde una respuesta de red, y cada móvil borra al
  conectar los mensajes antiguos de su buzón (conserva los últimos 20).

## Ajustes en el código
`MainActivity.kt`: `DELTA_UI_MS`, `MSG_MAX_MS`, `TOPBAR_MS`, `AUTOLOAD_M`, `SIGNAL_TIMEOUT_MS`, `STINT_WARN_MIN`,
`PIT_BLINK_MS`, `PIT_MAX_MS`. `LapEngine.kt`: `MIN_LAP_MS`. `Circuit.kt`: `DEFAULT_HALF_WIDTH_M`.
