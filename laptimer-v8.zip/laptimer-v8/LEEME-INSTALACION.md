# Actualizar de la 0.7 a la 0.8

La firma es la misma de siempre, así que la 0.8 se instala **encima** y se conservan circuitos, sesiones y ajustes.

## 1. App
1. En tu repositorio privado: **Add file > Upload files** y sube `laptimer-v8.zip` sin descomprimir. Commit.
   El flujo usa siempre el zip con el número más alto.
2. **Actions**: espera al ✓ verde (3 a 5 minutos). Después **Releases > APK más reciente > laptimer.apk**, en tu Android.
3. Instálala encima de la 0.7. Si Android dice que hay un conflicto con otra app, avísame antes de desinstalar nada.
4. Si sale en rojo, copia el error del paso "Compilar APK" y pégalo en el chat.

## 2. Panel web
1. Descomprime `panel-pit-v8.zip`. En el repositorio público `panel-pit`: **Add file > Upload files**, sube el
   `index.html` y **Commit changes**.
2. Espera 1 o 2 minutos. Si no cambia, añade `?v=8` al final de la dirección.
3. **Las reglas de Firebase no cambian.**
4. Abre **ajustes** en el panel: pon el **número de coches** (1 para este fin de semana) y pulsa **Guardar y conectar**.
5. En esos mismos ajustes, **Limpiar restos antiguos** borra los datos de versiones anteriores (campos sueltos en `live`,
   buzones en `inbox` con nombres que no son coches y `msgs`). Los coches actuales no se tocan.

## 3. Carril de boxes
1. **INICIO > CIRCUITOS > Editar circuito en el mapa**.
2. **+ ENTRADA BOXES**: toca el mapa donde está la línea de entrada y luego un punto hacia donde avanzas.
   Repite con **+ SALIDA BOXES**. Hacen falta las dos (o ninguna).
3. Para cada línea (meta, sectores, boxes): tócala y arrastra los **círculos blancos** de los extremos, o pulsa
   **ANCHO** y escribe los metros a la izquierda y a la derecha del punto, mirando en el sentido de marcha.
4. **GUARDAR**. Sin carril de boxes el circuito funciona como antes (y el cambio de piloto se confirma en la banda azul).
5. Si la pantalla de boxes se quedara puesta por error, **mantén pulsada** la pantalla para cerrarla. Se cierra sola a los 15 minutos.

## 4. Modos de carrera
**INICIO > MODO DE CARRERA**: track day, carrera sprint o carrera de resistencia (hoy los dos primeros son iguales).
**INICIO > CONFIGURAR RESISTENCIA**: pilotos en orden de relevo, tiempo mínimo de parada en boxes y valores de stint por
defecto. Con "Empezar de cero" reinicia el stint con el primer piloto de la lista. El panel puede cambiar el tiempo
mínimo de boxes en cada parada al pedir el cambio de piloto.

## 5. Resumen al cruzar la meta
**INICIO > AJUSTES DE SESIÓN**: duración del resumen (3 a 6 s). Tócalo para cerrarlo antes.

## 6. Configurar cada móvil
**INICIO > AJUSTES Y PIT CREW**: pon un **nombre de coche distinto** en cada móvil y el **piloto actual**.

## 7. Probar en casa
1. **MODO DEMO** (el circuito demo ya lleva carril de boxes): cada tres vueltas entra en boxes y verás la pantalla amarilla.
2. Para ver la cuenta atrás: **MODO DE CARRERA > resistencia** y un tiempo mínimo de boxes de unos 10 s en
   **CONFIGURAR RESISTENCIA** (el carril demo dura unos 7 s: saldrá como parada incumplida).
3. Abre el panel y pide un cambio de piloto; se confirma desde la pantalla de boxes.

## Copia de seguridad
**INICIO > COPIA DE SEGURIDAD**: haz una copia antes de actualizar. Incluye tu código de sala: guárdala en privado.
