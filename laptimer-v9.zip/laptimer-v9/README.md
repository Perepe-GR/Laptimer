# Lap Timer · versión 0.9

Cronómetro propio para antena GPS u-blox de 25 Hz por USB. Instalación y actualización en `LEEME-INSTALACION.md`.

## Novedades de la 0.9
- **Menús a pantalla completa** con tarjetas, con el estilo de la app: modo de carrera, ajustes de sesión, ajustes y pit
  crew, resistencia, estrategia, copia de seguridad y circuitos. Las ventanas de confirmación también usan el estilo oscuro.
- **Estrategia por stint** (resistencia): cada stint con piloto, mínimo y máximo en minutos y en vueltas, objetivo en
  vueltas o en minutos y tiempo mínimo de boxes de esa parada. No tienen que ser iguales; el panel puede cambiar los
  valores al pedir un cambio. Duración total de la carrera.
- **Colores del stint**: rojo si entrar a boxes ahora incumpliría los límites (antes del mínimo o pasado el máximo),
  verde dentro de ellos, lila si las vueltas coinciden con el objetivo.
- **FINAL STINT - BOX this lap**: banda ámbar en la parte baja durante la última vuelta planificada. El panel muestra
  "ÚLTIMA VUELTA PROGRAMADA". A partir de ahí hay un cambio programado que se confirma en la pantalla de boxes.
- **Boxes**: al cumplir el mínimo sale "GO, GO, GO!!!!" en verde; el tiempo total en boxes se cuenta siempre y queda
  registrado por parada (visible en la pantalla de resistencia).
- **Confirmar el cambio desde el panel**, solo con el coche en boxes (la app lo aplica en su siguiente intercambio).
- **Demo coherente con ×2 y ×4**: los tiempos de boxes y de stint siguen el reloj simulado. Sin botones: el coche virtual
  entra en boxes solo cuando toca (final de stint programado, petición del panel o, en track day y sprint, cada 3 vueltas),
  frena hasta el box, espera y sale. Confirmar el cambio es siempre manual y exige ir parado.
- **Layout principal**: tiempo de vuelta mucho más grande, mejor/última/óptima más legibles y, en track day y sprint,
  la velocidad pasa a la esquina de la tarjeta del tiempo (la franja de abajo solo existe en resistencia).

## Ajustes en el código
`MainActivity.kt`: `DELTA_UI_MS`, `MSG_MAX_MS`, `TOPBAR_MS`, `AUTOLOAD_M`, `SIGNAL_TIMEOUT_MS`, `STINT_WARN_MIN`,
`PIT_BLINK_MS`, `PIT_MAX_MS`, `DEMO_LANE_TRAVEL_MS`. `LapEngine.kt`: `MIN_LAP_MS`. `Circuit.kt`: `DEFAULT_HALF_WIDTH_M`.
`PageActivity.kt` es la base de las pantallas de menú.
