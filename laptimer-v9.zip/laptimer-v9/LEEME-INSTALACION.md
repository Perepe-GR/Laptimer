# Actualizar de la 0.8 a la 0.9

La firma es la misma de siempre: la 0.9 se instala **encima** y se conservan circuitos, sesiones y ajustes.
Haz antes una copia en **INICIO > COPIA DE SEGURIDAD**.

## 1. App
1. En tu repositorio privado: **Add file > Upload files** y sube `laptimer-v9.zip` sin descomprimir. Commit.
   El flujo usa siempre el zip con el número más alto.
2. **Actions**: espera al ✓ verde. Después **Releases > APK más reciente > laptimer.apk**, en tu Android.
3. Instálala encima de la 0.8. Si falla la compilación, copia el error del paso "Compilar APK" y pégalo en el chat.

## 2. Panel web
Descomprime `panel-pit-v9.zip`, sube el `index.html` al repositorio público `panel-pit` (**Add file > Upload files**,
**Commit changes**) y espera 1 o 2 minutos (si no cambia, añade `?v=9` a la dirección).
Las reglas de Firebase no cambian.

## 3. Estrategia de resistencia
1. **INICIO > MODO DE CARRERA > Carrera de resistencia**.
2. **INICIO > CONFIGURAR RESISTENCIA**: pilotos en orden de relevo y tiempo mínimo de boxes.
3. **EDITAR ESTRATEGIA POR STINT**: **+ STINT** añade uno; en cada uno, mínimo y máximo (minutos y vueltas), objetivo
   (vueltas o minutos) y mínimo de boxes de esa parada. 0 = sin definir. **GUARDAR**.
4. Marca **Empezar de cero** al guardar para que el stint 1 use el primer piloto y los objetivos de la estrategia.

Colores del stint: **rojo** si entrar a boxes ahora incumpliría los límites, **verde** dentro de ellos, **lila** si las
vueltas coinciden con el objetivo. En la última vuelta planificada sale **FINAL STINT - BOX this lap**.

## 4. Boxes
Al cumplir el mínimo: **GO, GO, GO!!!!** en verde. El tiempo total en boxes se registra en cada parada.
El cambio se confirma en la pantalla de boxes de la app o desde el panel (**Confirmar cambio**, solo con el coche en
boxes; la app lo aplica en su siguiente intercambio, hasta 10 s). Si la pantalla se queda puesta, pulsación larga para cerrarla.

## 5. Probar en casa con el demo
1. **MODO DE CARRERA > resistencia**, una estrategia con un stint de 2 o 3 vueltas y un mínimo de boxes de **40 s**.
2. **MODO DEMO**: el coche virtual no tiene botones. En la última vuelta planificada sale el aviso, entra solo en boxes,
   frena y espera. Las paradas alternan: una incumplida (el 60 % del mínimo) y otra cumplida (el 140 %).
   En **AJUSTES DE SESIÓN > Modo demo** puedes fijar los segundos parados.
3. Confirma el cambio **a mano** en la pantalla de boxes, con el coche parado, o desde el panel.
4. Con ×2 o ×4 la cuenta atrás y el cronómetro de stint van a la misma velocidad que el coche.
5. En track day y sprint el coche virtual entra en boxes cada 3 vueltas, sin cuenta atrás.
