# Changelog

Todas las novedades y cambios notables de Lap Timer.

## [1.1] - 2026-10-30

### Añadido
- **Diversificación de fuentes de entrada GPS**:
  - Soporte configurable para antena externa USB u-blox (25 Hz) como entrada principal de alta frecuencia.
  - Soporte nativo para antena GPS interna de smartphones, tablets y sistemas integrados de coche Android (`LocationManager`).
  - Compatibilidad directa seleccionable para herramientas GPS comerciales populares de competición: RaceBox (Mini, Micro, Pro), Dragy (10Hz / 25Hz), Garmin (Catalyst, GLO) y receptores GPS Bluetooth NMEA / Mock Locations.
- **Configuración de Temas visuales (`ThemeManager`)**:
  - Paletas temáticas seleccionables: *F1 Neon Lime (Original)*, *Toyota GR86 Gazoo Racing (Circuit Pack)* y *Racing Cyan / Gulf GT*.
  - Aplicación dinámica de acentos, barras de delta, trazado de mapa, botones y fondos.
- **Estrategia ágil en vivo para Endurance**:
  - Campo rápido para crear y asignar nuevos pilotos al vuelo en cada stint sin reiniciar el flujo ni perder cambios.
  - Guardado automático del roster al navegar entre configuración y estrategia de stints.

### Cambiado
- **Vueltas de entrada y salida activadas por defecto**:
  - `outlapCounts` e `inlapCounts` ahora están predeterminadas como activas (`true`), contabilizando las vueltas de boxes desde el primer momento.
- **Proporción de pantalla de conducción**:
  - Nueva distribución 60% (Delta en tiempo real y barra comparativa) y 40% (tarjeta de tiempos, BEST, LAST, OPTIMAL y sectores).
- **Simplificación y rediseño de menús (UX/UI)**:
  - Panel principal reorganizado en 6 tarjetas directas con título y subtítulo descriptivo.
  - Unificación de modos de carrera y configuración de resistencia en una única vista coherente.
  - Unificación de ajustes del coche, telemetría de boxes y copias de seguridad.

### Corregido
- **Paleta de colores y tinte en checkboxes y selectores**:
  - Solucionado el contraste y color estático de los checkboxes (`CheckBox`) y selectores de radio en modos oscuros y alternativos; ahora utilizan el color de acento del tema activo con estados checked/unchecked adaptativos.
- **Resolución de nombres de pilotos en desplegables de estrategia**:
  - Eliminado el requisito de pulsar "Guardar" de forma intermedia para que aparezcan pilotos recién introducidos.

---

## [1.0] - 2026-09-15

### Añadido
- Inicio de tiempo de stint al cruzar la línea de PIT OUT.
- Modo Sprint con objetivos combinables de vueltas totales y duración.
- Almacenamiento local y sincronización en Firebase de *Race Summaries*.
- Tercera vista con mapa dinámico del circuito, posición en tiempo real y líneas de paso.
- Soporte para zonas de PADDOCK poligonales editables en el mapa.
