package com.ejemplo.laptimer

import android.os.Handler
import java.util.Random
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.sin

/**
 * Circuito demo: un óvalo tipo kartódromo de unos 714 m (dos rectas de 200 m y dos curvas de 50 m
 * de radio) con meta en la recta inferior y 3 sectores. Se recorre en sentido antihorario.
 */
object DemoCircuit {
    const val NAME = "Circuito Demo"
    private const val STRAIGHT = 200.0
    private const val R = 50.0
    private val ARC = Math.PI * R
    val LENGTH: Double = 2 * STRAIGHT + 2 * ARC
    val frame = LocalFrame(41.0, 1.0)

    private fun wrap(s: Double): Double = ((s % LENGTH) + LENGTH) % LENGTH
    private fun norm(a: Double): Double = ((a % 360.0) + 360.0) % 360.0

    /** Posición (x, y en metros) y rumbo (grados) en la distancia s a lo largo del circuito. */
    fun pose(sIn: Double): DoubleArray {
        val s = wrap(sIn)
        return when {
            s < STRAIGHT -> doubleArrayOf(s, 0.0, 90.0)
            s < STRAIGHT + ARC -> {
                val phi = -Math.PI / 2 + (s - STRAIGHT) / R
                doubleArrayOf(STRAIGHT + R * cos(phi), R + R * sin(phi), norm(-Math.toDegrees(phi)))
            }
            s < 2 * STRAIGHT + ARC -> {
                val d = s - STRAIGHT - ARC
                doubleArrayOf(STRAIGHT - d, 2 * R, 270.0)
            }
            else -> {
                val phi = Math.PI / 2 + (s - 2 * STRAIGHT - ARC) / R
                doubleArrayOf(R * cos(phi), R + R * sin(phi), norm(-Math.toDegrees(phi)))
            }
        }
    }

    /** Velocidad de un piloto virtual: lento en curva, rápido en recta, con rampas. */
    fun speedMs(sIn: Double): Double {
        val s = wrap(sIn)
        val edge = when {
            s < STRAIGHT -> min(s, STRAIGHT - s)
            s in (STRAIGHT + ARC)..(2 * STRAIGHT + ARC) -> {
                val d = s - STRAIGHT - ARC
                min(d, STRAIGHT - d)
            }
            else -> 0.0
        }
        return 12.5 + 12.5 * min(1.0, edge / 60.0)
    }

    val circuit: Circuit by lazy {
        fun gp(s: Double, leftM: Double = DEFAULT_HALF_WIDTH_M, rightM: Double = DEFAULT_HALF_WIDTH_M): GatePoint {
            val p = pose(s)
            return GatePoint(frame.lat(p[1]), frame.lon(p[0]), p[2], leftM, rightM)
        }
        fun pitGp(u: Double, leftM: Double = 6.0, rightM: Double = 6.0): GatePoint {
            val p = pitPose(u)
            return GatePoint(frame.lat(p[1]), frame.lon(p[0]), p[2], leftM, rightM)
        }
        // Meta en s = 100 m; 2 puntos intermedios dividen el óvalo en 3 sectores iguales:
        // Sector 1: de 100 m a 338 m (termina en s1)
        // Sector 2: de 338 m a 576 m (termina en s2)
        // Sector 3: de 576 m a 100 m (cierra en finish)
        val s1 = wrap(100.0 + LENGTH / 3.0)
        val s2 = wrap(100.0 + 2.0 * LENGTH / 3.0)
        // Pit lane independiente en el interior de la recta principal (y < 0).
        // PIT IN a u = 20 m (desviando desde la última curva)
        // PIT OUT a u = 100 m (reincorporándose a la recta principal antes de la meta)
        Circuit(
            name = NAME,
            finish = gp(100.0, 10.0, 10.0),
            sectors = listOf(gp(s1, 10.0, 10.0), gp(s2, 10.0, 10.0)),
            pitIn = pitGp(20.0),
            pitOut = pitGp(100.0)
        )
    }

    // Geometría del carril de boxes independiente (longitud total PIT_LENGTH ~120 m)
    const val PIT_LENGTH = 120.0
    const val PIT_OFFSET_Y = -12.0 // situado 12 m al interior (abajo) de la recta principal

    /**
     * Posición (x, y en metros) y rumbo (grados) en la distancia u a lo largo del carril de boxes.
     * u = 0..30m: rampa de entrada divergente desde la última curva (x=0, y=10) hacia (x=20, y=-12)
     * u = 30..90m: carril de boxes recto paralelo a la recta principal (y = -12, rumbo este 90°)
     * u = 90..120m: rampa de salida convergente desde (x=80, y=-12) hacia la pista (x=100, y=0)
     */
    fun pitPose(uIn: Double): DoubleArray {
        val u = uIn.coerceIn(0.0, PIT_LENGTH)
        return when {
            u < 30.0 -> {
                // Entrada: de x = 0, y = 10 a x = 20, y = PIT_OFFSET_Y (-12)
                val t = u / 30.0
                val x = 0.0 + t * 20.0
                val y = 10.0 + t * (PIT_OFFSET_Y - 10.0)
                val angleRad = Math.atan2(PIT_OFFSET_Y - 10.0, 20.0)
                doubleArrayOf(x, y, norm(90.0 - Math.toDegrees(angleRad)))
            }
            u <= 90.0 -> {
                // Recta de boxes: x avanza de 20 a 80 m a lo largo de y = -12 m
                val x = 20.0 + (u - 30.0)
                doubleArrayOf(x, PIT_OFFSET_Y, 90.0)
            }
            else -> {
                // Salida: de x = 80, y = PIT_OFFSET_Y (-12) a x = 100, y = 0
                val t = (u - 90.0) / 30.0
                val x = 80.0 + t * 20.0
                val y = PIT_OFFSET_Y + t * (0.0 - PIT_OFFSET_Y)
                val angleRad = Math.atan2(0.0 - PIT_OFFSET_Y, 20.0)
                doubleArrayOf(x, y, norm(90.0 - Math.toDegrees(angleRad)))
            }
        }
    }
}

/**
 * Piloto virtual: genera posiciones a 25 Hz sobre el circuito demo, con ritmo distinto en cada
 * vuelta (±1-2 %) y algo de ruido de GPS. Permite acelerar la simulación (x1, x2, x4).
 */
class DemoSource(
    private val handler: Handler,
    private val sink: (NmeaEvent.Position, Boolean) -> Unit
) {
    @Volatile
    var factor = 1
    private var running = false
    private var sTotal = -30.0
    private var lapIdx = -1
    private var pace = 1.0
    private var clockMs = 12 * 3_600_000L
    private val rnd = Random(7)

    // Paradas en boxes: el piloto virtual entra, frena hasta el box, espera y sale (todo en tiempo simulado)
    @Volatile private var pitReq = false
    @Volatile private var pitPhase = 0 // 0 pista normal, 1 entrando al pit, 2 parado en el box, 3 saliendo del pit
    private var stopSimMs = 10_000L
    private var stoppedMs = 0L
    private var pitDist = 0.0 // Distancia u (0..PIT_LENGTH) a lo largo del carril de boxes
    private var pitV = 0.0
    private var rampV = 99.0

    /** Hay una parada pedida o en curso. */
    val pitBusy: Boolean get() = pitReq || pitPhase != 0

    /** Está dentro del carril de boxes (entrando, parado o saliendo). */
    val inPitLane: Boolean get() = pitPhase != 0

    /** Pide una parada en la próxima vuelta; stopMs es el tiempo que estará parado, en tiempo simulado. */
    fun requestPit(stopMs: Long) {
        stopSimMs = stopMs
        pitReq = true
    }

    private companion object {
        const val PIT_V = 8.0 // velocidad en el carril de boxes (m/s, unos 29 km/h)
        const val BOX_STOP_U = 60.0 // parada en el centro de la recta de boxes (u = 60 m)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val f = factor
            for (i in 0 until f) step(i == f - 1)
            handler.postDelayed(this, 40)
        }
    }

    fun start() {
        running = true
        handler.post(tick)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tick)
    }

    private fun step(render: Boolean) {
        val idx = floor(sTotal / DemoCircuit.LENGTH).toInt()
        if (idx != lapIdx) {
            lapIdx = idx
            pace = 1.0 + (rnd.nextGaussian() * 0.012).coerceIn(-0.03, 0.03)
        }
        val lapBase = floor(sTotal / DemoCircuit.LENGTH) * DemoCircuit.LENGTH
        val local = sTotal - lapBase
        var v = DemoCircuit.speedMs(sTotal) * pace

        var inPitTrack = false
        when (pitPhase) {
            0 -> {
                // Entrada al carril de boxes antes de la última curva (alrededor de local >= 690 m)
                // En s=690 m el coche se desvía al pit lane (u=0).
                if (pitReq && local >= 685.0 && local < 710.0) {
                    pitPhase = 1
                    pitDist = 0.0
                    pitV = v
                    inPitTrack = true
                } else if (rampV < 90.0) {
                    rampV += 3.0 * 0.04
                    if (rampV >= v) rampV = 99.0 else v = rampV
                }
            }
            1 -> {
                inPitTrack = true
                // El coche avanza por el carril de boxes hasta el box en BOX_STOP_U (u = 60 m)
                // Cruzará PIT IN (u = 20 m) a PIT_V (~29 km/h)
                val d = BOX_STOP_U - pitDist
                val vStop = sqrt(2.0 * 3.0 * max(d, 0.0))
                val target = min(PIT_V, vStop)
                pitV = if (pitV > target) max(target, pitV - 4.0 * 0.04) else min(target, pitV + 2.0 * 0.04)
                v = pitV
                pitDist += v * 0.04
                if (d <= 0.2 || pitDist >= BOX_STOP_U) {
                    v = 0.0
                    pitV = 0.0
                    stoppedMs = 0L
                    pitPhase = 2
                    pitDist = BOX_STOP_U
                }
            }
            2 -> {
                inPitTrack = true
                v = 0.0
                stoppedMs += 40L
                if (stoppedMs >= stopSimMs) {
                    pitV = 0.0
                    pitPhase = 3
                }
            }
            3 -> {
                inPitTrack = true
                // Acelera por el carril de boxes, cruza PIT OUT (u = 100 m) y se reincorpora a la pista al llegar a PIT_LENGTH (120 m)
                pitV = min(PIT_V, pitV + 2.5 * 0.04)
                v = pitV
                pitDist += v * 0.04
                if (pitDist >= DemoCircuit.PIT_LENGTH) {
                    // Reincorporado a la pista principal en x = 100 m (recta principal, justo en la meta)
                    pitPhase = 0
                    pitReq = false
                    rampV = pitV
                    inPitTrack = false
                    sTotal = lapBase + DemoCircuit.LENGTH + 100.0 // sTotal posicionado en la reincorporación
                }
            }
        }

        if (!inPitTrack) {
            sTotal += v * 0.04
        }
        clockMs += 40

        val p = if (inPitTrack) DemoCircuit.pitPose(pitDist) else DemoCircuit.pose(sTotal)
        val x = p[0] + rnd.nextGaussian() * 0.3
        val y = p[1] + rnd.nextGaussian() * 0.3
        val course = (((p[2] + rnd.nextGaussian()) % 360.0) + 360.0) % 360.0
        val ev = NmeaEvent.Position(
            lat = DemoCircuit.frame.lat(y),
            lon = DemoCircuit.frame.lon(x),
            speedKmh = v * 3.6 + rnd.nextGaussian() * 0.3,
            courseDeg = course,
            timeMs = clockMs
        )
        sink(ev, render)
    }
}
