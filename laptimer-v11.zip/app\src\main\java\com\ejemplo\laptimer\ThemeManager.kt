package com.ejemplo.laptimer

import android.content.Context
import android.graphics.Color

/**
 * Paleta temática de colores para la aplicación.
 */
data class AppTheme(
    val id: String,
    val name: String,
    val description: String,
    val accent: Int,       // Color primario / ganando tiempo / activo
    val alert: Int,        // Perdiendo tiempo / error / alarma
    val cardBg: Int = Color.parseColor("#12161B"),
    val bg: Int = Color.parseColor("#0B0D10"),
    val muted: Int = Color.parseColor("#9AA3AE"),
    val text: Int = Color.parseColor("#F2F4F7")
)

object ThemeManager {
    // 1. Clásico / F1 Lime
    val THEME_CLASSIC = AppTheme(
        id = "classic",
        name = "F1 Neon Lime (Original)",
        description = "Contraste máximo con verde lima de circuito y rojo fluorescente",
        accent = Color.parseColor("#C6F432"),
        alert = Color.parseColor("#FF5A5F")
    )

    // 2. Toyota Gazoo Racing (GR86 Circuit Pack)
    // Rojo GR oficial (#D90429 / #E0041B), acento blanco/plata y contraste negro mate Gazoo Racing
    val THEME_GR86 = AppTheme(
        id = "gr86",
        name = "Toyota GR86 Gazoo Racing",
        description = "Edición Circuit Pack: Rojo Gazoo Racing, blanco puro y fondo de fibra de carbono",
        accent = Color.parseColor("#E0041B"),
        alert = Color.parseColor("#FF5A5F"),
        cardBg = Color.parseColor("#15181C"),
        bg = Color.parseColor("#0A0B0D")
    )

    // 3. Porsche GT / Racing Blue
    val THEME_RACING_BLUE = AppTheme(
        id = "racing_blue",
        name = "Racing Cyan / Gulf GT",
        description = "Estilo clásico de resistencia: azul cian eléctrico y acento naranja de competición",
        accent = Color.parseColor("#00E5FF"),
        alert = Color.parseColor("#FF7700")
    )

    val THEMES = listOf(THEME_CLASSIC, THEME_GR86, THEME_RACING_BLUE)

    fun getTheme(context: Context): AppTheme {
        val sp = context.getSharedPreferences("laptimer_prefs", Context.MODE_PRIVATE)
        val id = sp.getString("app_theme_id", "classic")
        return THEMES.firstOrNull { it.id == id } ?: THEME_CLASSIC
    }

    fun setTheme(context: Context, themeId: String) {
        val sp = context.getSharedPreferences("laptimer_prefs", Context.MODE_PRIVATE)
        sp.edit().putString("app_theme_id", themeId).apply()
    }
}
