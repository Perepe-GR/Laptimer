package com.ejemplo.laptimer

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lista de sesiones guardadas. Toque = detalle, pulsación larga = borrar. */
class HistoryActivity : AppCompatActivity() {

    private lateinit var store: SessionStore
    private lateinit var list: ListView
    private lateinit var empty: TextView
    private var sessions: List<SessionRecord> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SessionStore(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0B0D10.toInt())
        root.setPadding(pad, pad, pad, pad)

        val titleRow = LinearLayout(this)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = android.view.Gravity.CENTER_VERTICAL
        val back = TextView(this)
        back.text = "‹  VOLVER"
        back.textSize = 15f
        back.typeface = Typeface.DEFAULT_BOLD
        back.setTextColor(Color.parseColor("#C6F432"))
        back.setPadding(0, 0, (16 * resources.displayMetrics.density).toInt(), 0)
        back.setOnClickListener { finish() }
        titleRow.addView(back)

        val title = TextView(this)
        title.text = "Historial y Sesiones"
        title.textSize = 20f
        title.setTextColor(Color.WHITE)
        title.typeface = Typeface.DEFAULT_BOLD
        titleRow.addView(title)

        val space = android.view.View(this)
        titleRow.addView(space, LinearLayout.LayoutParams(0, 1, 1f))

        val btnRecords = TextView(this)
        btnRecords.text = "VER RÉCORDS Y GRÁFICAS ›"
        btnRecords.textSize = 14f
        btnRecords.typeface = Typeface.DEFAULT_BOLD
        btnRecords.setTextColor(Color.parseColor("#0B0D10"))
        val g = android.graphics.drawable.GradientDrawable()
        g.setColor(Color.parseColor("#C6F432"))
        g.cornerRadius = (10 * resources.displayMetrics.density)
        btnRecords.background = g
        btnRecords.setPadding(pad, pad / 2, pad, pad / 2)
        btnRecords.setOnClickListener {
            startActivity(Intent(this, RecordsActivity::class.java))
        }
        titleRow.addView(btnRecords)
        root.addView(titleRow)

        empty = TextView(this)
        empty.text = "Aún no hay sesiones guardadas. Se graban solas al moverte con un circuito activo y completar laps."
        empty.setTextColor(0xFF9AA3AE.toInt())
        empty.setPadding(0, pad, 0, 0)
        root.addView(empty)

        list = ListView(this)
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        list.setOnItemClickListener { _, _, pos, _ ->
            val i = Intent(this, SessionActivity::class.java)
            i.putExtra("id", sessions[pos].id)
            startActivity(i)
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            confirmDelete(sessions[pos])
            true
        }
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        sessions = store.list()
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val lines = sessions.map { s ->
            fmt.format(Date(s.startEpochMs)) + " · " + s.circuitName + driverTag(s) + "\n" +
                s.laps.size + " laps · BEST " + fmtMs(s.bestLap()?.lapMs)
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, lines)
        empty.visibility = if (sessions.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun confirmDelete(s: SessionRecord) {
        AlertDialog.Builder(this)
            .setTitle("Borrar sesión")
            .setMessage("¿Borrar la sesión de " + s.circuitName + "?")
            .setPositiveButton("Borrar") { _, _ ->
                store.delete(s.id)
                reload()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
