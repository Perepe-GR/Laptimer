package com.ejemplo.laptimer

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Base de las pantallas de menú a pantalla completa, con el estilo de la app: fondo oscuro, tarjetas de
 * esquinas redondeadas, acento verde lima. Cada pantalla rellena [content] (tarjetas) y [footer] (botones).
 */
abstract class PageActivity : AppCompatActivity() {

    protected open val colBg get() = ThemeManager.getTheme(this).bg
    protected open val colCard get() = ThemeManager.getTheme(this).cardBg
    protected val colField = Color.parseColor("#1E242B")
    protected open val colLime get() = ThemeManager.getTheme(this).accent
    protected open val colMuted get() = ThemeManager.getTheme(this).muted
    protected open val colText get() = ThemeManager.getTheme(this).text
    protected open val colRed get() = ThemeManager.getTheme(this).alert

    protected lateinit var content: LinearLayout
    protected lateinit var footer: LinearLayout

    protected abstract val pageTitle: String

    /** Rellena [content] y [footer]. Se vuelve a llamar con [rebuild] cuando cambian los datos. */
    protected abstract fun build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(colBg)

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(16), dp(10), dp(16), dp(6))
        val back = TextView(this)
        back.text = "‹  VOLVER"
        back.textSize = 15f
        back.typeface = Typeface.DEFAULT_BOLD
        back.setTextColor(colLime)
        back.setPadding(0, dp(6), dp(16), dp(6))
        back.setOnClickListener { finish() }
        header.addView(back)
        val title = TextView(this)
        title.text = pageTitle
        title.textSize = 20f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(colText)
        header.addView(title)
        root.addView(header)

        val scroll = ScrollView(this)
        scroll.isFillViewport = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(4), dp(16), dp(12))
        scroll.addView(content, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        footer = LinearLayout(this)
        footer.orientation = LinearLayout.HORIZONTAL
        footer.setPadding(dp(16), dp(8), dp(16), dp(10))
        root.addView(footer)

        setContentView(root)
        build()
        refreshFooter()
    }

    /** Vacía y vuelve a construir la pantalla. */
    protected fun rebuild() {
        content.removeAllViews()
        footer.removeAllViews()
        build()
        refreshFooter()
    }

    private fun refreshFooter() {
        footer.visibility = if (footer.childCount == 0) View.GONE else View.VISIBLE
    }

    // ---------- Utilidades ----------

    protected fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    protected fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    protected fun roundBg(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
        return g
    }

    // ---------- Componentes ----------

    /** Tarjeta nueva añadida a la pantalla, con título opcional. */
    protected fun card(title: String? = null): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(colCard, 16)
        c.setPadding(dp(16), dp(12), dp(16), dp(14))
        if (title != null) {
            val t = TextView(this)
            t.text = title.uppercase()
            t.textSize = 12f
            t.letterSpacing = 0.1f
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextColor(colMuted)
            c.addView(t)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        content.addView(c, lp)
        return c
    }

    protected fun label(parent: LinearLayout, text: String): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = 12f
        v.setTextColor(colMuted)
        v.setPadding(0, dp(10), 0, dp(4))
        parent.addView(v)
        return v
    }

    protected fun note(parent: LinearLayout, text: String): TextView {
        val v = TextView(this)
        v.text = text
        v.textSize = 14f
        v.setTextColor(colText)
        v.setPadding(0, dp(8), 0, 0)
        parent.addView(v)
        return v
    }

    private fun styleField(e: EditText) {
        e.setTextColor(colText)
        e.setHintTextColor(colMuted)
        e.textSize = 16f
        e.background = roundBg(colField, 10)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        e.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI
    }

    protected fun newText(value: String, hint: String = "", flags: Int = InputType.TYPE_CLASS_TEXT): EditText {
        val e = EditText(this)
        e.inputType = flags
        e.hint = hint
        e.setText(value)
        styleField(e)
        return e
    }

    protected fun newNum(value: String, decimal: Boolean = false): EditText {
        val flags = if (decimal) {
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        } else {
            InputType.TYPE_CLASS_NUMBER
        }
        return newText(value, "", flags)
    }

    /** Campo de texto con su rótulo, ya añadido a la tarjeta. */
    protected fun textField(
        parent: LinearLayout,
        labelText: String,
        value: String,
        hint: String = "",
        flags: Int = InputType.TYPE_CLASS_TEXT
    ): EditText {
        label(parent, labelText)
        val e = newText(value, hint, flags)
        parent.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return e
    }

    protected fun numField(parent: LinearLayout, labelText: String, value: String, decimal: Boolean = false): EditText {
        label(parent, labelText)
        val e = newNum(value, decimal)
        parent.addView(e, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return e
    }

    protected fun check(parent: LinearLayout, text: String, checked: Boolean): CheckBox {
        val c = CheckBox(this)
        c.text = text
        c.isChecked = checked
        c.setTextColor(colText)
        c.textSize = 15f
        c.setPadding(dp(4), dp(8), 0, dp(8))
        val accent = ThemeManager.getTheme(this).accent
        val states = arrayOf(
            intArrayOf(android.R.attr.state_checked),
            intArrayOf(-android.R.attr.state_checked)
        )
        val colors = intArrayOf(accent, colMuted)
        androidx.core.widget.CompoundButtonCompat.setButtonTintList(
            c,
            android.content.res.ColorStateList(states, colors)
        )
        parent.addView(c)
        return c
    }

    /** Rótulo y campo apilados, para ponerlos en una fila con [rowOf]. */
    protected fun block(labelText: String, field: View): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.text = labelText
        t.textSize = 12f
        t.setTextColor(colMuted)
        t.setPadding(0, dp(10), 0, dp(4))
        b.addView(t)
        b.addView(field, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return b
    }

    /** Pone varias vistas en una fila a partes iguales. */
    protected fun rowOf(parent: LinearLayout, vararg views: View) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for ((i, v) in views.withIndex()) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.marginStart = dp(10)
            r.addView(v, lp)
        }
        parent.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    /** Botón de la app: verde lima si es el principal, tarjeta oscura si no. */
    protected fun button(text: String, primary: Boolean = false, action: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.gravity = Gravity.CENTER
        b.textSize = 15f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(if (primary) colBg else colText)
        b.background = roundBg(if (primary) colLime else colField, 14)
        b.setPadding(dp(14), dp(12), dp(14), dp(12))
        b.isClickable = true
        b.setOnClickListener { action() }
        return b
    }

    /** Añade botones al pie, a partes iguales. */
    protected fun addFooter(vararg buttons: TextView) {
        for ((i, b) in buttons.withIndex()) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.marginStart = dp(10)
            footer.addView(b, lp)
        }
    }

    /** Botón ancho dentro de una tarjeta. */
    protected fun addButton(parent: LinearLayout, b: TextView) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        parent.addView(b, lp)
    }

    /** Tarjeta pulsable con título y descripción; la seleccionada lleva borde verde lima. */
    protected fun optionCard(title: String, desc: String, selected: Boolean, action: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(colCard, 16, if (selected) colLime else colCard, 2)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val t = TextView(this)
        t.text = title
        t.textSize = 18f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(if (selected) colLime else colText)
        c.addView(t)
        if (desc.isNotEmpty()) {
            val d = TextView(this)
            d.text = desc
            d.textSize = 14f
            d.setTextColor(colMuted)
            d.setPadding(0, dp(4), 0, 0)
            c.addView(d)
        }
        c.isClickable = true
        c.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        content.addView(c, lp)
        return c
    }

    /**
     * Selector de una opción entre varias dentro de una tarjeta. Devuelve una función que da la clave elegida.
     */
    protected fun choice(parent: LinearLayout, options: List<Pair<String, String>>, selectedKey: String): () -> String {
        var current = selectedKey
        val views = ArrayList<TextView>()
        fun paint() {
            for ((i, v) in views.withIndex()) {
                val sel = options[i].first == current
                v.background = roundBg(colField, 12, if (sel) colLime else colField, 2)
                v.setTextColor(if (sel) colLime else colText)
            }
        }
        for ((key, text) in options) {
            val v = TextView(this)
            v.text = text
            v.textSize = 15f
            v.setPadding(dp(14), dp(12), dp(14), dp(12))
            v.setOnClickListener {
                current = key
                paint()
            }
            views.add(v)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            parent.addView(v, lp)
        }
        paint()
        return { current }
    }
}
