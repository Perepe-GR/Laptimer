# Lap Timer · versión 1.1

Cronómetro de alta precisión para circuito y motorsport en Android. Soporta antena GPS externa u-blox de 25 Hz por USB, GPS interno del dispositivo y sistemas GPS comerciales externos.

## Novedades de la 1.1
- **Diversificación de entradas GPS**: Soporte multi-fuente configurable desde *Ajustes y Pit Crew*:
  - Antena GPS externa u-blox USB a 25 Hz (opción principal de alta frecuencia).
  - GPS nativo/interno del smartphone, tablet o sistema multimedia del coche Android.
  - Sistemas GPS comerciales de competición y telemetría: RaceBox (Mini/Micro/Pro), Dragy (10Hz/25Hz), Garmin (Catalyst/GLO) y otros receptores Bluetooth externos vía NMEA/Mock Locations.
- **Vueltas de entrada y salida (IN LAP / OUT LAP) activas por defecto**:
  - `outlapCounts` e `inlapCounts` vienen activadas por defecto para que las vueltas de salida de boxes a meta y de meta a boxes se registren como vueltas numeradas de la sesión de manera inmediata.
- **Corrección y adaptación de la paleta de colores en checkboxes**:
  - Tinte dinámico adaptativo para casillas de verificación (`CheckBox`) y selectores según el tema activo, asegurando contraste y legibilidad óptima en fondos oscuros y claros.
- **Rediseño UX/UI y proporción de conducción 60% / 40%**:
  - Columna izquierda del Delta a pantalla completa ensanchada al 60% para máxima visibilidad durante la conducción; 40% para tiempos de vuelta, BEST, LAST y OPTIMAL.
  - Menús simplificados en 6 tarjetas directas sin submenús anidados redundantes.
  - Adición y asignación ágil de pilotos en vivo en la estrategia de resistencia (Endurance).
- **Capa de configuración temática de colores (`ThemeManager`)**:
  - *F1 Neon Lime (Original)*
  - *Toyota GR86 Gazoo Racing (Circuit Pack)*
  - *Racing Cyan / Gulf GT*

## Novedades de la 1.0
- **Stint**: el tiempo de conducción empieza al cruzar PIT OUT (no al confirmar el cambio).
- **Modos**: track day libre; sprint a vueltas y/o tiempo; endurance con gestión de pilotos, stints y paradas.
- **Race summaries**: resúmenes completos archivados en la app y sincronizados con Firebase.
- **Tercer layout (mapa)**: trazado en vivo coloreado por sectores, posición GPS y líneas de paso.
- **PADDOCK**: polígonos delimitadores en mapa con detección de estancia en paddock.

## Ajustes en el código
`MainActivity.kt`: integración híbrida USB/LocationManager, `applyThemeStyles`, `DELTA_UI_MS`, `AUTOLOAD_M`.
`ThemeManager.kt`: paletas y gestión de temas. `PitLink.kt`: `gpsSource`, persistencia y telemetría.
`Pages.kt` y `PageActivity.kt`: tintado de controles, navegación y configuración unificada.
