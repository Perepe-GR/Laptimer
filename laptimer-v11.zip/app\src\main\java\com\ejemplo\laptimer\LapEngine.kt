package com.ejemplo.laptimer

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Línea de paso: segmento a-b perpendicular al rumbo, más la dirección de marcha (dx, dy). */
private class Gate(
    val ax: Double, val ay: Double,
    val bx: Double, val by: Double,
    val dx: Double, val dy: Double
)

/** Muestra de la vuelta de referencia: tiempo (ms desde el inicio de vuelta) y posición local. */
class RefSample(val t: Long, val x: Double, val y: Double)

/**
 * Vuelta de referencia (la mejor). Dada una posición, devuelve en qué instante de la
 * vuelta pasó la referencia por el punto más cercano de su trazado.
 */
class ReferenceLap(samples: List<RefSample>) {
    private val n = samples.size
    private val xs = DoubleArray(n) { samples[it].x }
    private val ys = DoubleArray(n) { samples[it].y }
    private val ts = LongArray(n) { samples[it].t }
    private val cum = DoubleArray(n) // distancia acumulada a lo largo de la traza (m)
    private var last = 0
    private var misses = 0

    init {
        for (i in 1 until n) {
            cum[i] = cum[i - 1] + hypot(xs[i] - xs[i - 1], ys[i] - ys[i - 1])
        }
    }

    fun reset() {
        last = 0
        misses = 0
    }

    fun timeAt(x: Double, y: Double): Double? {
        if (n < 2) return null

        var lo = last
        var hi = last
        if (misses > 50) {
            // Perdido (trompo, salida de pista): búsqueda global
            lo = 0
            hi = n - 2
        } else {
            // Ventana: 15 m hacia atrás y 80 m hacia delante de la última posición
            while (lo > 0 && cum[last] - cum[lo - 1] < 15.0) lo--
            while (hi < n - 2 && cum[hi + 1] - cum[last] < 80.0) hi++
        }
        if (hi > n - 2) hi = n - 2

        var bestD = Double.MAX_VALUE
        var bestT = 0.0
        var bestIdx = last
        for (i in lo..hi) {
            val sx = xs[i + 1] - xs[i]
            val sy = ys[i + 1] - ys[i]
            val len2 = sx * sx + sy * sy
            val u = if (len2 < 1e-9) 0.0
            else (((x - xs[i]) * sx + (y - ys[i]) * sy) / len2).coerceIn(0.0, 1.0)
            val px = xs[i] + u * sx
            val py = ys[i] + u * sy
            val d = hypot(x - px, y - py)
            if (d < bestD) {
                bestD = d
                bestT = ts[i] + u * (ts[i + 1] - ts[i])
                bestIdx = i
            }
        }

        if (bestD > 40.0) {
            misses++
            return null
        }
        misses = 0
        last = bestIdx
        return bestT
    }
}

/** Color de un sector tipo F1. */
enum class MarkKind { NEUTRAL, PURPLE, GREEN, YELLOW }

class SectorMark(val ms: Long, val kind: MarkKind)

class LapResult(
    val number: Int,
    val lapMs: Long,
    val splits: List<Long>,
    val startMs: Long,
    val endMs: Long,
    val isBest: Boolean,
    val trace: List<RefSample>,
    /** Diferencia con la mejor vuelta anterior (negativo = más rápida); null si era la primera. */
    val deltaMs: Long? = null,
    /** Colores de los sectores de esta vuelta (el último es el que cierra en meta). */
    val marks: List<SectorMark?> = emptyList(),
    /** 0 = vuelta normal, 1 = OUT LAP (desde la salida del PIT), 2 = IN LAP (hasta la entrada al PIT). */
    val kind: Int = 0
)

class PersistData(val bestLapMs: Long?, val bestSectors: LongArray, val ref: List<RefSample>?)

data class EngineState(
    val running: Boolean,
    val lapNumber: Int,
    val sector: Int,
    val sectorCount: Int,
    val currentLapMs: Long?,
    val lastLapMs: Long?,
    val bestLapMs: Long?,
    val optimalMs: Long?,
    val deltaSec: Double?,
    val speedKmh: Double,
    val gpsTimeMs: Long,
    val marks: List<SectorMark?>
)

/**
 * Motor de cronometraje:
 *  - detecta el paso por meta y sectores (cruce de línea con interpolación entre muestras),
 *  - guarda la mejor vuelta como traza de referencia (y la recupera de sesiones anteriores),
 *  - calcula el delta en vivo en cada posición frente a esa referencia,
 *  - calcula la vuelta óptima como suma de los mejores sectores (historial + sesión),
 *  - colorea los sectores tipo F1 (morado / verde / amarillo).
 */
class LapEngine(private val circuit: Circuit, initial: Persisted? = null) {

    companion object {
        const val MIN_LAP_MS = 10_000L
        const val MAX_GAP_MS = 1_000L
        private const val HALF_DAY_MS = 43_200_000L
        private const val DAY_MS = 86_400_000L
    }

    private val frame = LocalFrame(circuit.finish.lat, circuit.finish.lon)
    private val finishGate = makeGate(circuit.finish)

    /** Carril de boxes: solo se usa si hay entrada y salida. */
    private val pitInGate: Gate? = if (circuit.hasPitLane) circuit.pitIn?.let { makeGate(it) } else null
    private val pitOutGate: Gate? = if (circuit.hasPitLane) circuit.pitOut?.let { makeGate(it) } else null
    private var inPit = false

    /** Orden de paso dentro de una vuelta: sectores intermedios y, al final, la meta. */
    private val sequence: List<Gate> = circuit.sectors.map { makeGate(it) } + finishGate
    private val n = sequence.size

    private var hasPrev = false
    private var prevX = 0.0
    private var prevY = 0.0
    private var prevT = 0L
    private var dayOffset = 0L
    private var lastRaw: Long? = null

    private var lapStart: Double? = null
    private var expected = 0
    private var splitStart = 0.0
    private val currentSplits = ArrayList<Long>()
    private val trace = ArrayList<RefSample>()

    private var lapsCompleted = 0
    private var lastLapMs: Long? = null
    private var bestLapMs: Long? = null
    private val histBest = LongArray(n) { Long.MAX_VALUE }
    private val sessBest = LongArray(n) { Long.MAX_VALUE }
    private var marks = arrayOfNulls<SectorMark>(n)
    private var prevMarks = arrayOfNulls<SectorMark>(n)
    private var reference: ReferenceLap? = null
    private var refSamples: List<RefSample>? = null
    private var deltaSmooth: Double? = null

    var onLap: ((LapResult) -> Unit)? = null

    /** Si la OUT LAP / IN LAP cuentan como vuelta numerada (nunca entran en BEST, récords ni mejores sectores). */
    @Volatile var outlapCounts = false
    @Volatile var inlapCounts = false

    /** Tipo de la vuelta en curso: 0 normal, 1 OUT LAP (empezó al cruzar la salida del PIT). */
    private var special = 0

    /** Se llama cada vez que se cruza un sector o la meta con una vuelta en curso. */
    var onBoundary: (() -> Unit)? = null

    /** Se llama al cruzar la línea de entrada y la de salida del carril de boxes. */
    var onPitIn: (() -> Unit)? = null
    var onPitOut: (() -> Unit)? = null

    init {
        if (initial != null) {
            val s = initial.stats
            if (s.bestSectors.size == n) {
                for (i in 0 until n) histBest[i] = s.bestSectors[i]
            }
            bestLapMs = s.bestLapMs
            val r = initial.ref
            if (r != null && r.size >= 2) {
                refSamples = r
                reference = ReferenceLap(r)
            }
        }
    }

    private fun makeGate(p: GatePoint): Gate {
        val x = frame.x(p.lon)
        val y = frame.y(p.lat)
        val h = Math.toRadians(p.headingDeg)
        val dx = sin(h)
        val dy = cos(h)
        // Perpendicular a la izquierda del sentido de marcha: (-dy, dx). Cada lado con su propio ancho.
        val lx = -dy * p.leftM
        val ly = dx * p.leftM
        val rx = dy * p.rightM
        val ry = -dx * p.rightM
        return Gate(x + lx, y + ly, x + rx, y + ry, dx, dy)
    }

    @Synchronized
    fun isRunning(): Boolean = lapStart != null

    /** Permite a un motor nuevo continuar con el estado de boxes del anterior. */
    @Synchronized
    fun setInPit(v: Boolean) {
        inPit = v
    }

    /** Empieza una sesión nueva: conserva los récords históricos, olvida lo de la sesión anterior. */
    @Synchronized
    fun resetSession() {
        special = 0
        lapStart = null
        expected = 0
        lapsCompleted = 0
        lastLapMs = null
        for (i in 0 until n) sessBest[i] = Long.MAX_VALUE
        marks = arrayOfNulls<SectorMark>(n)
        prevMarks = arrayOfNulls<SectorMark>(n)
        hasPrev = false
        deltaSmooth = null
        inPit = false
        trace.clear()
        currentSplits.clear()
        reference?.reset()
    }

    @Synchronized
    fun persistData(): PersistData {
        val merged = LongArray(n) { minOf(histBest[it], sessBest[it]) }
        return PersistData(bestLapMs, merged, refSamples)
    }

    @Synchronized
    fun onFix(lat: Double, lon: Double, speedKmh: Double, rawTimeMs: Long): EngineState {
        // Cambio de día (medianoche UTC)
        val prevRaw = lastRaw
        if (prevRaw != null && rawTimeMs < prevRaw - HALF_DAY_MS) dayOffset += DAY_MS
        lastRaw = rawTimeMs
        val t = rawTimeMs + dayOffset
        val x = frame.x(lon)
        val y = frame.y(lat)

        if (hasPrev && t > prevT && t - prevT <= MAX_GAP_MS) {
            processSegment(prevX, prevY, prevT.toDouble(), x, y, t.toDouble())
        }
        hasPrev = true
        prevX = x
        prevY = y
        prevT = t

        var current: Long? = null
        var delta: Double? = null
        val start = lapStart
        if (start != null) {
            val rel = t - start
            current = Math.round(rel)
            if (rel > 0.0) trace.add(RefSample(Math.round(rel), x, y))

            val ref = reference
            if (ref != null && special == 0) {
                val refT = ref.timeAt(x, y)
                if (refT != null) {
                    val raw = rel - refT
                    val s = deltaSmooth?.let { it * 0.7 + raw * 0.3 } ?: raw
                    deltaSmooth = s
                    delta = s / 1000.0
                }
            }
        }

        val shown = if (marks.any { it != null }) marks else prevMarks

        return EngineState(
            running = lapStart != null,
            lapNumber = lapsCompleted + 1,
            sector = minOf(expected + 1, n),
            sectorCount = n,
            currentLapMs = current,
            lastLapMs = lastLapMs,
            bestLapMs = bestLapMs,
            optimalMs = optimal(),
            deltaSec = delta,
            speedKmh = speedKmh,
            gpsTimeMs = t,
            marks = shown.toList()
        )
    }

    private fun optimal(): Long? {
        var sum = 0L
        for (i in 0 until n) {
            val m = minOf(histBest[i], sessBest[i])
            if (m == Long.MAX_VALUE) return null
            sum += m
        }
        return sum
    }

    /** Morado: mejor que todo lo conocido. Verde: mejor que tu mejor de la sesión. Amarillo: más lento. */
    private fun kindFor(i: Int, ms: Long): MarkKind {
        val h = histBest[i]
        val s = sessBest[i]
        val hasH = h != Long.MAX_VALUE
        val hasS = s != Long.MAX_VALUE
        if (!hasH && !hasS) return MarkKind.NEUTRAL
        val beatsH = !hasH || ms < h
        val beatsS = !hasS || ms < s
        return when {
            beatsH && beatsS -> MarkKind.PURPLE
            hasS && ms < s -> MarkKind.GREEN
            else -> MarkKind.YELLOW
        }
    }

    /** Fracción (0..1) del segmento de movimiento donde cruza la línea, o null. Solo en sentido de marcha. */
    private fun crossing(g: Gate, x1: Double, y1: Double, x2: Double, y2: Double): Double? {
        val rx = x2 - x1
        val ry = y2 - y1
        val sx = g.bx - g.ax
        val sy = g.by - g.ay
        val den = rx * sy - ry * sx
        if (abs(den) < 1e-9) return null
        val t = ((g.ax - x1) * sy - (g.ay - y1) * sx) / den
        val u = ((g.ax - x1) * ry - (g.ay - y1) * rx) / den
        if (t < 0.0 || t > 1.0 || u < 0.0 || u > 1.0) return null
        if (rx * g.dx + ry * g.dy <= 0.0) return null
        return t
    }

    private fun processSegment(
        x1: Double, y1: Double, t1: Double,
        x2: Double, y2: Double, t2: Double
    ) {
        // Carril de boxes: independiente de la vuelta en curso
        val pin = pitInGate
        val pout = pitOutGate
        if (pin != null && pout != null) {
            if (!inPit) {
                val fIn = crossing(pin, x1, y1, x2, y2)
                if (fIn != null) {
                    inPit = true
                    endInLap(
                        t1 + (t2 - t1) * fIn,
                        x1 + (x2 - x1) * fIn,
                        y1 + (y2 - y1) * fIn
                    )
                    onPitIn?.invoke()
                }
            } else {
                val fOut = crossing(pout, x1, y1, x2, y2)
                if (fOut != null) {
                    inPit = false
                    startOutLap(
                        t1 + (t2 - t1) * fOut,
                        x1 + (x2 - x1) * fOut,
                        y1 + (y2 - y1) * fOut
                    )
                    onPitOut?.invoke()
                }
            }
        }

        val running = lapStart != null
        val gate = if (running) sequence[expected] else finishGate
        val f = crossing(gate, x1, y1, x2, y2)
        if (f != null) {
            val tc = t1 + (t2 - t1) * f
            val xc = x1 + (x2 - x1) * f
            val yc = y1 + (y2 - y1) * f
            if (running) onGate(tc, xc, yc) else startLap(tc, xc, yc)
            return
        }

        // Cruzar la meta sin haber pasado por todos los sectores invalida la vuelta: se reinicia.
        if (running && expected < n - 1) {
            val f2 = crossing(finishGate, x1, y1, x2, y2)
            if (f2 != null) {
                startLap(
                    t1 + (t2 - t1) * f2,
                    x1 + (x2 - x1) * f2,
                    y1 + (y2 - y1) * f2
                )
            }
        }
    }

    private fun startLap(tc: Double, xc: Double, yc: Double) {
        special = 0
        lapStart = tc
        expected = 0
        splitStart = tc
        currentSplits.clear()
        trace.clear()
        trace.add(RefSample(0L, xc, yc))
        prevMarks = marks
        marks = arrayOfNulls<SectorMark>(n)
        reference?.reset()
        deltaSmooth = null
    }

    /** Al cruzar la salida del PIT empieza la OUT LAP: con sectores, hasta la meta. */
    private fun startOutLap(tc: Double, xc: Double, yc: Double) {
        startLap(tc, xc, yc)
        special = 1
    }

    /** Al cruzar la entrada del PIT termina la IN LAP (si había una vuelta en curso). El último sector es parcial. */
    private fun endInLap(tc: Double, xc: Double, yc: Double) {
        val start = lapStart
        if (start != null && special == 0) {
            val lap = Math.round(tc - start)
            if (lap >= MIN_LAP_MS) {
                val splits = ArrayList(currentSplits)
                splits.add(Math.round(tc - splitStart))
                val mk = marks.toMutableList()
                if (expected < mk.size) mk[expected] = SectorMark(splits.last(), MarkKind.NEUTRAL)
                if (inlapCounts) lapsCompleted++
                onLap?.invoke(
                    LapResult(
                        if (inlapCounts) lapsCompleted else 0, lap, splits,
                        Math.round(start), Math.round(tc), false, emptyList(),
                        null, mk, 2
                    )
                )
            }
        }
        lapStart = null
        special = 0
        expected = 0
        currentSplits.clear()
        trace.clear()
        deltaSmooth = null
    }

    private fun onGate(tc: Double, xc: Double, yc: Double) {
        val idx = expected
        val split = Math.round(tc - splitStart)
        currentSplits.add(split)
        marks[idx] = SectorMark(split, kindFor(idx, split))
        splitStart = tc
        expected++
        onBoundary?.invoke()
        if (expected < n) return // sector intermedio

        // Vuelta completa
        val start = lapStart ?: return
        val lap = Math.round(tc - start)
        if (special == 1) {
            // OUT LAP: empezó en la salida del PIT, así que es una vuelta parcial. Sus sectores se muestran,
            // pero no entra en BEST, referencia ni mejores sectores. El primer sector es parcial (neutro).
            if (lap >= MIN_LAP_MS) {
                if (outlapCounts) lapsCompleted++
                if (marks.isNotEmpty() && currentSplits.isNotEmpty()) {
                    marks[0] = SectorMark(currentSplits[0], MarkKind.NEUTRAL)
                }
                onLap?.invoke(
                    LapResult(
                        if (outlapCounts) lapsCompleted else 0, lap, ArrayList(currentSplits),
                        Math.round(start), Math.round(tc), false, emptyList(),
                        null, marks.toList(), 1
                    )
                )
            }
            startLap(tc, xc, yc)
            return
        }
        if (lap >= MIN_LAP_MS) {
            lastLapMs = lap
            lapsCompleted++
            for (i in currentSplits.indices) {
                if (currentSplits[i] < sessBest[i]) sessBest[i] = currentSplits[i]
            }
            trace.add(RefSample(lap, xc, yc))
            val copy = ArrayList(trace)
            val best = bestLapMs
            val deltaMs = if (best == null) null else lap - best
            val isBest = best == null || lap < best
            if (isBest) {
                bestLapMs = lap
                refSamples = copy
                reference = ReferenceLap(copy)
            }
            onLap?.invoke(
                LapResult(
                    lapsCompleted, lap, ArrayList(currentSplits),
                    Math.round(start), Math.round(tc), isBest, copy,
                    deltaMs, marks.toList()
                )
            )
        }
        startLap(tc, xc, yc)
    }
}
