package com.ejemplo.laptimer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import java.util.Locale

/** Una vuelta extraída de la traza: distancia acumulada (m), tiempo (s), velocidad (km/h) y posición local. */
class LapTrace(
    val dist: DoubleArray,
    val time: DoubleArray,
    val speed: DoubleArray,
    val x: DoubleArray,
    val y: DoubleArray
)

object Analysis {
    fun slice(tr: Trace, startMs: Long, endMs: Long): LapTrace? {
        var i0 = -1
        var i1 = -1
        for (i in 0 until tr.size) {
            val t = tr.t[i]
            if (i0 < 0 && t >= startMs) i0 = i
            if (t <= endMs) i1 = i
        }
        if (i0 < 0 || i1 - i0 < 10) return null
        val n = i1 - i0 + 1
        val f = LocalFrame(tr.lat[i0], tr.lon[i0])
        val dist = DoubleArray(n)
        val time = DoubleArray(n)
        val speed = DoubleArray(n)
        val x = DoubleArray(n)
        val y = DoubleArray(n)
        for (k in 0 until n) {
            val i = i0 + k
            x[k] = f.x(tr.lon[i])
            y[k] = f.y(tr.lat[i])
            time[k] = (tr.t[i] - startMs) / 1000.0
            speed[k] = tr.v[i].toDouble()
            if (k > 0) dist[k] = dist[k - 1] + Math.hypot(x[k] - x[k - 1], y[k] - y[k - 1])
        }
        return LapTrace(dist, time, speed, x, y)
    }

    /** Interpolación lineal; xs debe ser no decreciente. */
    fun interp(xs: DoubleArray, ys: DoubleArray, x: Double): Double {
        if (x <= xs[0]) return ys[0]
        val last = xs.size - 1
        if (x >= xs[last]) return ys[last]
        var lo = 0
        var hi = last
        while (hi - lo > 1) {
            val mid = (lo + hi) ushr 1
            if (xs[mid] <= x) lo = mid else hi = mid
        }
        val d = xs[hi] - xs[lo]
        return if (d < 1e-9) ys[lo] else ys[lo] + (ys[hi] - ys[lo]) * (x - xs[lo]) / d
    }
}

/** Gráfica de líneas simple (hasta varias series sobre un mismo eje X). */
class LineChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var xs = DoubleArray(0)
    private var series: List<DoubleArray> = emptyList()
    private var colors = IntArray(0)
    private var zeroLine = false
    private var xUnit = " m"
    private val d = resources.displayMetrics.density
    private val axis = Paint().apply {
        color = 0xFF3A424C.toInt()
        strokeWidth = 1f * d
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
        strokeJoin = Paint.Join.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9AA3AE.toInt()
        textSize = 11f * d
    }

    fun setData(
        xs: DoubleArray, series: List<DoubleArray>, colors: IntArray, zeroLine: Boolean,
        xUnit: String = " m"
    ) {
        this.xUnit = xUnit
        this.xs = xs
        this.series = series
        this.colors = colors
        this.zeroLine = zeroLine
        invalidate()
    }

    fun clear() {
        xs = DoubleArray(0)
        series = emptyList()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (xs.size < 2 || series.isEmpty()) return
        val left = 44f * d
        val right = width - 8f * d
        val top = 8f * d
        val bottom = height - 18f * d

        var mn = Double.MAX_VALUE
        var mx = -Double.MAX_VALUE
        for (s in series) for (v in s) {
            if (v < mn) mn = v
            if (v > mx) mx = v
        }
        if (zeroLine) {
            mn = minOf(mn, 0.0)
            mx = maxOf(mx, 0.0)
        }
        if (mx - mn < 1e-6) mx = mn + 1.0

        val x0 = xs[0]
        val x1 = xs[xs.size - 1]
        fun px(x: Double) = left + ((x - x0) / (x1 - x0)).toFloat() * (right - left)
        fun py(v: Double) = bottom - ((v - mn) / (mx - mn)).toFloat() * (bottom - top)

        canvas.drawLine(left, top, left, bottom, axis)
        canvas.drawLine(left, bottom, right, bottom, axis)
        if (zeroLine && mn < 0.0 && mx > 0.0) canvas.drawLine(left, py(0.0), right, py(0.0), axis)

        canvas.drawText(String.format(Locale.US, "%.1f", mx), 2f * d, top + txt.textSize, txt)
        canvas.drawText(String.format(Locale.US, "%.1f", mn), 2f * d, bottom, txt)
        txt.textAlign = Paint.Align.RIGHT
        canvas.drawText(String.format(Locale.US, "%.0f%s", x1, xUnit), right, height - 3f * d, txt)
        txt.textAlign = Paint.Align.LEFT

        for ((idx, s) in series.withIndex()) {
            val path = Path()
            for (i in xs.indices) {
                val X = px(xs[i])
                val Y = py(s[i])
                if (i == 0) path.moveTo(X, Y) else path.lineTo(X, Y)
            }
            line.color = colors[idx]
            canvas.drawPath(path, line)
        }
    }
}

/** Trazado de una vuelta coloreado por velocidad (rojo = lento, verde = rápido). */
class TraceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var xs = DoubleArray(0)
    private var ys = DoubleArray(0)
    private var vs = DoubleArray(0)
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 4f * d
        strokeCap = Paint.Cap.ROUND
    }

    fun setData(x: DoubleArray, y: DoubleArray, v: DoubleArray) {
        xs = x
        ys = y
        vs = v
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val n = xs.size
        if (n < 2) return
        var minX = Double.MAX_VALUE
        var maxX = -Double.MAX_VALUE
        var minY = Double.MAX_VALUE
        var maxY = -Double.MAX_VALUE
        var minV = Double.MAX_VALUE
        var maxV = -Double.MAX_VALUE
        for (i in 0 until n) {
            if (xs[i] < minX) minX = xs[i]
            if (xs[i] > maxX) maxX = xs[i]
            if (ys[i] < minY) minY = ys[i]
            if (ys[i] > maxY) maxY = ys[i]
            if (vs[i] < minV) minV = vs[i]
            if (vs[i] > maxV) maxV = vs[i]
        }
        val m = 16f * d
        val w = (maxX - minX).coerceAtLeast(1.0)
        val h = (maxY - minY).coerceAtLeast(1.0)
        val scale = minOf((width - 2 * m) / w, (height - 2 * m) / h).toFloat()
        val offX = (width - (w * scale).toFloat()) / 2f
        val offY = (height - (h * scale).toFloat()) / 2f
        fun sx(x: Double) = offX + ((x - minX) * scale).toFloat()
        fun sy(y: Double) = height - (offY + ((y - minY) * scale).toFloat())

        val range = (maxV - minV).coerceAtLeast(1.0)
        val hsv = FloatArray(3)
        for (i in 0 until n - 1) {
            val t = ((vs[i] - minV) / range).toFloat()
            hsv[0] = 120f * t
            hsv[1] = 0.9f
            hsv[2] = 1f
            paint.color = Color.HSVToColor(hsv)
            canvas.drawLine(sx(xs[i]), sy(ys[i]), sx(xs[i + 1]), sy(ys[i + 1]), paint)
        }
    }
}
