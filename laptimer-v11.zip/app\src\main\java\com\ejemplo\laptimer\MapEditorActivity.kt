package com.ejemplo.laptimer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.Polyline
import java.io.File
import java.util.Locale

/**
 * Editor de circuitos sobre OpenStreetMap: se toca el mapa para colocar la meta, los sectores y la
 * entrada y salida del carril de boxes; se arrastran los puntos para moverlos y se fija el sentido de
 * marcha con un segundo toque. Cada línea tiene su propio ancho a cada lado (círculos blancos en los
 * extremos de la línea seleccionada, o el botón ANCHO para escribirlo).
 * El orden en que se añaden los sectores es el orden de paso.
 */
class MapEditorActivity : AppCompatActivity() {

    private enum class Mode {
        IDLE, FINISH_POS, FINISH_DIR, SECTOR_POS, SECTOR_DIR, PITIN_POS, PITIN_DIR, PITOUT_POS, PITOUT_DIR, SET_DIR, PADDOCK_ADD
    }

    private companion object {
        const val SEL_NONE = -1
        const val SEL_PIT_IN = -2
        const val SEL_PIT_OUT = -3
        const val MIN_WIDTH_M = 2.0
        const val MAX_WIDTH_M = 150.0
        val COL_FINISH = 0xFFC6F432.toInt()
        val COL_SECTOR = 0xFFF5A524.toInt()
        val COL_PIT = 0xFF38BDF8.toInt()
        val COL_PADDOCK = 0xFFE879F9.toInt()
    }

    private lateinit var map: MapView
    private lateinit var hint: TextView
    private lateinit var store: CircuitStore
    private var name = ""
    private val points = ArrayList<GatePoint>() // 0 = meta, 1.. = sectores en orden de paso
    private var pitIn: GatePoint? = null
    private var pitOut: GatePoint? = null
    private val paddock = ArrayList<LatLon>()
    private var selected = SEL_NONE
    private var mode = Mode.IDLE
    private var pending: GeoPoint? = null
    private var gpsLat = Double.NaN
    private var gpsLon = Double.NaN
    private val dynamic = ArrayList<Overlay>()
    private val density get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, getSharedPreferences("osm", MODE_PRIVATE))
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(cacheDir, "osmdroid")
        cfg.osmdroidTileCache = File(cacheDir, "osmdroid/tiles")

        store = CircuitStore(this)
        name = intent.getStringExtra("name") ?: "Circuito"
        val isNew = intent.getBooleanExtra("new", false)
        gpsLat = intent.getDoubleExtra("lat", Double.NaN)
        gpsLon = intent.getDoubleExtra("lon", Double.NaN)
        if (!isNew) {
            val c = store.list().firstOrNull { it.name == name }
            if (c != null) {
                points.add(c.finish)
                points.addAll(c.sectors)
                pitIn = c.pitIn
                pitOut = c.pitOut
                paddock.addAll(c.paddock)
            }
        }

        val root = FrameLayout(this)
        map = MapView(this)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        root.addView(map, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        hint = TextView(this)
        hint.setBackgroundColor(0xCC0B0D10.toInt())
        hint.setTextColor(Color.WHITE)
        hint.textSize = 13f
        val pad = (8 * density).toInt()
        hint.setPadding(pad * 2, pad, pad * 2, pad)
        root.addView(
            hint,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        )

        // Dos filas de botones abajo
        val bars = LinearLayout(this)
        bars.orientation = LinearLayout.VERTICAL
        bars.setBackgroundColor(0xCC0B0D10.toInt())
        fun newRow(): LinearLayout {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            bars.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return r
        }
        val row1 = newRow()
        val row2 = newRow()
        val row3 = newRow()
        fun addButton(row: LinearLayout, text: String, action: () -> Unit) {
            val b = Button(this)
            b.text = text
            b.textSize = 11f
            b.setOnClickListener { action() }
            row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        addButton(row1, "+ FINISH") { mode = Mode.FINISH_POS; pending = null; updateHint() }
        addButton(row1, "+ SECTOR") {
            if (points.isEmpty()) toast("Primero coloca FINISH")
            else { mode = Mode.SECTOR_POS; pending = null; updateHint() }
        }
        addButton(row1, "+ PIT IN") { mode = Mode.PITIN_POS; pending = null; updateHint() }
        addButton(row1, "+ PIT OUT") { mode = Mode.PITOUT_POS; pending = null; updateHint() }
        addButton(row1, "SENTIDO") {
            if (getSel() == null) toast("Toca primero una línea del mapa")
            else { mode = Mode.SET_DIR; updateHint() }
        }
        addButton(row1, "BORRAR") { deleteSelected() }

        addButton(row3, "+ PADDOCK") { mode = Mode.PADDOCK_ADD; pending = null; updateHint() }
        addButton(row3, "LISTO") { mode = Mode.IDLE; redraw(); updateHint() }
        addButton(row3, "DESHACER") {
            if (paddock.isNotEmpty()) paddock.removeAt(paddock.size - 1)
            redraw(); updateHint()
        }
        addButton(row3, "BORRAR PADDOCK") {
            paddock.clear()
            mode = Mode.IDLE
            redraw(); updateHint()
        }

        addButton(row2, "ANCHO") { askWidth() }
        addButton(row2, "MI POSICIÓN") {
            if (gpsLat.isNaN()) toast("Sin posición GPS todavía")
            else map.controller.animateTo(GeoPoint(gpsLat, gpsLon))
        }
        addButton(row2, "GUARDAR") { save() }
        addButton(row2, "SALIR") { finish() }
        root.addView(
            bars,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )
        setContentView(root)

        val receiver = object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                onTap(p)
                return true
            }

            override fun longPressHelper(p: GeoPoint): Boolean = false
        }
        map.overlays.add(MapEventsOverlay(receiver))

        when {
            points.isNotEmpty() -> {
                map.controller.setZoom(17.0)
                map.controller.setCenter(GeoPoint(points[0].lat, points[0].lon))
            }
            !gpsLat.isNaN() -> {
                map.controller.setZoom(17.0)
                map.controller.setCenter(GeoPoint(gpsLat, gpsLon))
            }
            else -> {
                map.controller.setZoom(6.0)
                map.controller.setCenter(GeoPoint(40.4, -3.7))
            }
        }
        redraw()
        updateHint()
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
    }

    override fun onPause() {
        map.onPause()
        super.onPause()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Selección ----------

    private fun getSel(): GatePoint? = when {
        selected >= 0 && selected < points.size -> points[selected]
        selected == SEL_PIT_IN -> pitIn
        selected == SEL_PIT_OUT -> pitOut
        else -> null
    }

    private fun setSel(g: GatePoint) {
        when {
            selected >= 0 && selected < points.size -> points[selected] = g
            selected == SEL_PIT_IN -> pitIn = g
            selected == SEL_PIT_OUT -> pitOut = g
        }
    }

    private fun selName(): String = when {
        selected == 0 -> "FINISH"
        selected > 0 -> "Sector $selected"
        selected == SEL_PIT_IN -> "PIT IN"
        selected == SEL_PIT_OUT -> "PIT OUT"
        else -> ""
    }

    private fun deleteSelected() {
        when {
            selected >= 0 && selected < points.size -> points.removeAt(selected)
            selected == SEL_PIT_IN -> pitIn = null
            selected == SEL_PIT_OUT -> pitOut = null
            else -> {
                toast("Toca primero una línea del mapa")
                return
            }
        }
        selected = SEL_NONE
        redraw()
        updateHint()
    }

    private fun askWidth() {
        val g = getSel()
        if (g == null) {
            toast("Toca primero una línea del mapa")
            return
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val pad = (16 * density).toInt()
        box.setPadding(pad, pad / 2, pad, 0)

        fun label(t: String): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = 12f
            v.setPadding(0, (8 * density).toInt(), 0, 0)
            return v
        }

        fun field(v: Double): EditText {
            val e = EditText(this)
            e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            e.setText(String.format(Locale.US, "%.1f", v))
            return e
        }

        val etL = field(g.leftM)
        val etR = field(g.rightM)
        box.addView(label("Ancho a la izquierda del punto, mirando en el sentido de marcha (m)"))
        box.addView(etL)
        box.addView(label("Ancho a la derecha del punto (m)"))
        box.addView(etR)
        AlertDialog.Builder(this)
            .setTitle("Ancho de la línea · ${selName()}")
            .setView(box)
            .setPositiveButton("Aplicar") { _, _ ->
                val l = (etL.text.toString().toDoubleOrNull() ?: g.leftM).coerceIn(MIN_WIDTH_M, MAX_WIDTH_M)
                val r = (etR.text.toString().toDoubleOrNull() ?: g.rightM).coerceIn(MIN_WIDTH_M, MAX_WIDTH_M)
                setSel(g.copy(leftM = l, rightM = r))
                redraw()
                updateHint()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Textos y toques ----------

    private fun updateHint() {
        hint.text = when (mode) {
            Mode.IDLE -> {
                val g = getSel()
                if (g != null) {
                    String.format(
                        Locale.US,
                        "«%s» · %s · izq %.0f m · der %.0f m. Arrastra los círculos blancos de los extremos para el ancho, o pulsa ANCHO.",
                        name, selName(), g.leftM, g.rightM
                    )
                } else {
                    "«$name» · Toca + FINISH, + SECTOR, + PIT IN / PIT OUT o + PADDOCK. Arrastra un punto para moverlo; toca una línea para ajustar su ancho o girarla con SENTIDO. Los sectores se numeran en el orden en que los añades."
                }
            }
            Mode.FINISH_POS -> "Toca el mapa donde está la línea de FINISH."
            Mode.SECTOR_POS -> "Toca el mapa donde está el sector."
            Mode.PITIN_POS -> "Toca el mapa donde está la línea de PIT IN (entrada al carril de PIT)."
            Mode.PITOUT_POS -> "Toca el mapa donde está la línea de PIT OUT (salida del carril de PIT)."
            Mode.PADDOCK_ADD -> "PADDOCK: toca los vértices de la zona (${paddock.size} puestos, mínimo 3). DESHACER quita el último; LISTO termina."
            Mode.FINISH_DIR, Mode.SECTOR_DIR, Mode.PITIN_DIR, Mode.PITOUT_DIR, Mode.SET_DIR ->
                "Ahora toca un punto hacia donde avanzas (sentido de marcha)."
        }
    }

    private fun onTap(p: GeoPoint) {
        when (mode) {
            Mode.FINISH_POS -> { pending = p; mode = Mode.FINISH_DIR }
            Mode.SECTOR_POS -> { pending = p; mode = Mode.SECTOR_DIR }
            Mode.PITIN_POS -> { pending = p; mode = Mode.PITIN_DIR }
            Mode.PITOUT_POS -> { pending = p; mode = Mode.PITOUT_DIR }
            Mode.FINISH_DIR, Mode.SECTOR_DIR, Mode.PITIN_DIR, Mode.PITOUT_DIR -> {
                val a = pending
                if (a != null) {
                    val h = bearingDeg(a.latitude, a.longitude, p.latitude, p.longitude)
                    val gp = GatePoint(a.latitude, a.longitude, h)
                    when (mode) {
                        Mode.FINISH_DIR -> {
                            if (points.isEmpty()) points.add(gp) else points[0] = gp
                            selected = 0
                        }
                        Mode.SECTOR_DIR -> {
                            points.add(gp)
                            selected = points.size - 1
                        }
                        Mode.PITIN_DIR -> {
                            pitIn = gp
                            selected = SEL_PIT_IN
                        }
                        else -> {
                            pitOut = gp
                            selected = SEL_PIT_OUT
                        }
                    }
                }
                pending = null
                mode = Mode.IDLE
            }
            Mode.SET_DIR -> {
                val s = getSel()
                if (s != null) setSel(s.copy(headingDeg = bearingDeg(s.lat, s.lon, p.latitude, p.longitude)))
                mode = Mode.IDLE
            }
            Mode.PADDOCK_ADD -> paddock.add(LatLon(p.latitude, p.longitude))
            Mode.IDLE -> selected = SEL_NONE
        }
        redraw()
        updateHint()
    }

    // ---------- Dibujo ----------

    private fun addLine(a: GeoPoint, b: GeoPoint, color: Int, width: Float) {
        val pl = Polyline(map)
        pl.setPoints(listOf(a, b))
        pl.outlinePaint.color = color
        pl.outlinePaint.strokeWidth = width
        dynamic.add(pl)
        map.overlays.add(pl)
    }

    /** Dibuja una línea de paso: la línea con su ancho, la flecha de marcha, el punto y (si está seleccionada) los tiradores. */
    private fun drawGate(
        g: GatePoint,
        label: String,
        accent: Int,
        sel: Int,
        onMoved: (Double, Double) -> Unit,
        onWidth: (Double, Double) -> Unit
    ) {
        val f = LocalFrame(g.lat, g.lon)
        val h = Math.toRadians(g.headingDeg)
        val dx = Math.sin(h)
        val dy = Math.cos(h)
        val isSel = sel == selected
        // Perpendicular a la izquierda del sentido de marcha: (-dy, dx)
        val leftX = -dy * g.leftM
        val leftY = dx * g.leftM
        val rightX = dy * g.rightM
        val rightY = -dx * g.rightM
        val leftEnd = GeoPoint(f.lat(leftY), f.lon(leftX))
        val rightEnd = GeoPoint(f.lat(rightY), f.lon(rightX))
        addLine(leftEnd, rightEnd, accent, 6f * density)
        addLine(
            GeoPoint(g.lat, g.lon),
            GeoPoint(f.lat(30.0 * dy), f.lon(30.0 * dx)),
            if (isSel) Color.WHITE else 0xFFB8C0CC.toInt(), 3f * density
        )

        val m = Marker(map)
        m.position = GeoPoint(g.lat, g.lon)
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        m.icon = labelIcon(label, isSel, accent)
        m.isDraggable = true
        m.setOnMarkerClickListener { _, _ ->
            selected = sel
            mode = Mode.IDLE
            map.post { redraw(); updateHint() }
            true
        }
        m.setOnMarkerDragListener(object : Marker.OnMarkerDragListener {
            override fun onMarkerDrag(marker: Marker?) {}
            override fun onMarkerDragStart(marker: Marker?) {}
            override fun onMarkerDragEnd(marker: Marker?) {
                val mp = marker?.position ?: return
                onMoved(mp.latitude, mp.longitude)
                map.post { redraw() }
            }
        })
        dynamic.add(m)
        map.overlays.add(m)

        if (isSel) {
            fun handle(pos: GeoPoint, isLeft: Boolean) {
                val hm = Marker(map)
                hm.position = pos
                hm.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                hm.icon = handleIcon(accent)
                hm.isDraggable = true
                hm.setOnMarkerDragListener(object : Marker.OnMarkerDragListener {
                    override fun onMarkerDrag(marker: Marker?) {}
                    override fun onMarkerDragStart(marker: Marker?) {}
                    override fun onMarkerDragEnd(marker: Marker?) {
                        val mp = marker?.position ?: return
                        val x = f.x(mp.longitude)
                        val y = f.y(mp.latitude)
                        // Distancia con signo sobre la perpendicular izquierda: positiva = izquierda
                        val d = x * (-dy) + y * dx
                        if (isLeft) onWidth(d.coerceIn(MIN_WIDTH_M, MAX_WIDTH_M), g.rightM)
                        else onWidth(g.leftM, (-d).coerceIn(MIN_WIDTH_M, MAX_WIDTH_M))
                        map.post { redraw(); updateHint() }
                    }
                })
                dynamic.add(hm)
                map.overlays.add(hm)
            }
            handle(leftEnd, true)
            handle(rightEnd, false)
        }
    }

    private fun redraw() {
        map.overlays.removeAll(dynamic)
        dynamic.clear()

        for (i in points.indices) {
            val idx = i
            drawGate(
                points[idx],
                if (idx == 0) "M" else idx.toString(),
                if (idx == 0) COL_FINISH else COL_SECTOR,
                idx,
                { lat, lon -> if (idx in points.indices) points[idx] = points[idx].copy(lat = lat, lon = lon) },
                { l, r -> if (idx in points.indices) points[idx] = points[idx].copy(leftM = l, rightM = r) }
            )
        }
        pitIn?.let { g ->
            drawGate(
                g, "E", COL_PIT, SEL_PIT_IN,
                { lat, lon -> pitIn = pitIn?.copy(lat = lat, lon = lon) },
                { l, r -> pitIn = pitIn?.copy(leftM = l, rightM = r) }
            )
        }
        pitOut?.let { g ->
            drawGate(
                g, "S", COL_PIT, SEL_PIT_OUT,
                { lat, lon -> pitOut = pitOut?.copy(lat = lat, lon = lon) },
                { l, r -> pitOut = pitOut?.copy(leftM = l, rightM = r) }
            )
        }

        if (paddock.size >= 2) {
            val poly = Polygon(map)
            poly.points = paddock.map { GeoPoint(it.lat, it.lon) }
            poly.fillPaint.color = 0x33E879F9
            poly.outlinePaint.color = COL_PADDOCK
            poly.outlinePaint.strokeWidth = 3f * density
            dynamic.add(poly)
            map.overlays.add(poly)
        }
        for (i in paddock.indices) {
            val idx = i
            val m = Marker(map)
            m.position = GeoPoint(paddock[idx].lat, paddock[idx].lon)
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            m.icon = handleIcon(COL_PADDOCK)
            m.isDraggable = true
            m.setOnMarkerDragListener(object : Marker.OnMarkerDragListener {
                override fun onMarkerDrag(marker: Marker?) {}
                override fun onMarkerDragStart(marker: Marker?) {}
                override fun onMarkerDragEnd(marker: Marker?) {
                    val mp = marker?.position ?: return
                    if (idx in paddock.indices) paddock[idx] = LatLon(mp.latitude, mp.longitude)
                    map.post { redraw() }
                }
            })
            dynamic.add(m)
            map.overlays.add(m)
        }

        val pd = pending
        if (pd != null) {
            val m = Marker(map)
            m.position = pd
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            m.icon = labelIcon("?", true, COL_SECTOR)
            dynamic.add(m)
            map.overlays.add(m)
        }
        map.invalidate()
    }

    private fun labelIcon(text: String, isSelected: Boolean, accent: Int): Drawable {
        val s = (36 * density).toInt()
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = if (isSelected) Color.WHITE else accent
        c.drawCircle(s / 2f, s / 2f, s / 2f, p)
        p.color = 0xFF0B0D10.toInt()
        c.drawCircle(s / 2f, s / 2f, s / 2f - 3f * density, p)
        p.color = accent
        p.textSize = s * 0.5f
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        c.drawText(text, s / 2f, s / 2f + p.textSize * 0.35f, p)
        return BitmapDrawable(resources, bmp)
    }

    /** Círculo blanco con borde del color de la línea, para estirar o encoger el ancho. */
    private fun handleIcon(accent: Int): Drawable {
        val s = (26 * density).toInt()
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = accent
        c.drawCircle(s / 2f, s / 2f, s / 2f, p)
        p.color = Color.WHITE
        c.drawCircle(s / 2f, s / 2f, s / 2f - 4f * density, p)
        return BitmapDrawable(resources, bmp)
    }

    private fun save() {
        if (points.isEmpty()) {
            toast("Coloca al menos FINISH")
            return
        }
        if ((pitIn == null) != (pitOut == null)) {
            toast("El carril de PIT necesita PIT IN y PIT OUT: añade la que falta o bórrala")
            return
        }
        if (paddock.size in 1..2) {
            toast("La zona PADDOCK necesita al menos 3 puntos: añade los que faltan o bórrala")
            return
        }
        val c = Circuit(name, points[0], points.drop(1), pitIn, pitOut, ArrayList(paddock))
        store.save(c)
        store.activeName = name
        val extra = (if (c.hasPitLane) " + PIT" else "") + (if (c.hasPaddock) " + PADDOCK" else "")
        toast("Circuito guardado: ${c.sectorCount} sectores$extra")
        finish()
    }
}
