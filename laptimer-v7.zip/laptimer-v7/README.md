# Lap Timer · versión 0.7

Cronómetro propio para antena GPS u-blox de 25 Hz por USB. Actualización en `LEEME-INSTALACION.md`.

## Novedades de la 0.7
- **Varios coches en la misma sala**: cada móvil tiene un nombre de coche; el panel muestra una tarjeta por coche y
  los mensajes van a todos o a uno. Datos en `live/<coche>`, `laps/<coche>`, `inbox/<coche>` y `cmd/<coche>`.
- **Resistencia**: piloto y stint en cada sesión, cronómetro de stint con tiempo mínimo y máximo, vueltas
  realizadas y planificadas (en el móvil y en el panel), y cambio de piloto pedido desde el panel y confirmado en boxes.
- **Avisos visuales** (sin sonido): sin antena, sin GPS, batería baja o crítica (no avisa si está cargando) y límites
  del stint. Se ven también en el panel.
- **Ajustes de sesión**: bloqueo, rango de la barra, duración de mensajes, umbrales de batería, ámbito del delta y
  los récords (coche o piloto) y valores por defecto del stint.
- **Récords por circuito** con la gráfica de la mejor vuelta por sesión, del coche o de cada piloto.
- **Copia de seguridad y restauración** en un zip.
- **Doble confirmación** al salir de la sesión con "atrás" o INICIO.
- **Panel más ligero**: consulta solo los datos en vivo cada 3 s y las últimas 10 vueltas cada 15 s, para no gastar
  la cuota de Firebase en carreras largas.

## Ajustes en el código
`MainActivity.kt`: `DELTA_UI_MS`, `MSG_MAX_MS`, `TOPBAR_MS`, `AUTOLOAD_M`, `SIGNAL_TIMEOUT_MS`, `STINT_WARN_MIN`.
`LapEngine.kt`: `GATE_HALF_WIDTH_M`, `MIN_LAP_MS`.
