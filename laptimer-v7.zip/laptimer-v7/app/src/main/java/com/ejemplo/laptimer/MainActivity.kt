package com.ejemplo.laptimer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Spannable
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.TextViewCompat
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Pantalla de sesión (se abre desde el menú de inicio).
 * Dos vistas (completa y simplificada), barra superior y banda inferior ocultas hasta que hacen falta,
 * stint con piloto y avisos visuales. Salir exige doble confirmación.
 */
class MainActivity : AppCompatActivity(), SerialInputOutputManager.Listener {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.ejemplo.laptimer.USB_PERMISSION"
        private const val BAUD_RATE = 115200
        private const val DELTA_UI_MS = 200L          // el delta se refresca a 5 Hz
        private const val MSG_MAX_MS = 600_000L       // tope de seguridad de un mensaje: 10 minutos
        private const val TOPBAR_MS = 5_000L          // la barra superior se oculta sola a los 5 s
        private const val AUTOLOAD_M = 3000.0         // radio de carga automática de circuito
        private const val SIGNAL_TIMEOUT_MS = 3_000L  // sin datos de antena o de GPS durante este tiempo = aviso
        private const val STINT_WARN_MIN = 5          // aviso ámbar cuando faltan estos minutos para el máximo
        private const val APP_VERSION = "0.7"
        private val COL_GREEN = Color.parseColor("#C6F432")
        private val COL_RED = Color.parseColor("#FF5A5F")
        private val COL_ALERT_RED = Color.parseColor("#EF4444")
        private val COL_AMBER = Color.parseColor("#F5A524")
        private val COL_PURPLE = Color.parseColor("#A855F7")
        private val COL_YELLOW = Color.parseColor("#FACC15")
        private val COL_NEUTRAL = Color.parseColor("#1E242B")
        private val COL_MUTED = Color.parseColor("#9AA3AE")
        private val COL_DARK = Color.parseColor("#0B0D10")
    }

    private class ActiveMsg(val text: String, val bg: String, var remaining: Int, val at: Long)

    private class StintState(
        var number: Int,
        var driver: String,
        var lapsDone: Int,
        var startEpoch: Long,
        var plan: Int,
        var minMin: Int,
        var maxMin: Int
    )

    private lateinit var topBar: View
    private lateinit var txtTop: TextView
    private lateinit var btnHome: Button
    private lateinit var txtNet: TextView
    private lateinit var txtGps: TextView
    private lateinit var alertStrip: TextView
    private lateinit var viewMain: View
    private lateinit var viewSimple: View
    private lateinit var txtDelta: TextView
    private lateinit var deltaBar: DeltaBarView
    private lateinit var txtRangeNeg: TextView
    private lateinit var txtRangePos: TextView
    private lateinit var txtRangeLabel: TextView
    private lateinit var txtLap: TextView
    private lateinit var chipsRow: LinearLayout
    private lateinit var txtBest: TextView
    private lateinit var txtLast: TextView
    private lateinit var txtOpt: TextView
    private lateinit var txtStint: TextView
    private lateinit var txtSpeed: TextView
    private lateinit var txtDelta2: TextView
    private lateinit var deltaBar2: DeltaBarView
    private lateinit var chipsRow2: LinearLayout
    private lateinit var bottomBar: View
    private lateinit var bannerPit: TextView
    private lateinit var reconBar: View
    private lateinit var swapBar: View
    private lateinit var txtSwap: TextView
    private lateinit var btnSwapConfirm: Button
    private lateinit var btnMarkFinish: Button
    private lateinit var btnMarkSector: Button
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button

    private val usbManager by lazy { getSystemService(Context.USB_SERVICE) as UsbManager }
    private val parser = NmeaParser()
    private val lineBuffer = StringBuilder()
    private val ioExecutor: ExecutorService = Executors.newCachedThreadPool()
    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null

    private lateinit var store: CircuitStore
    private lateinit var statsStore: StatsStore
    private lateinit var sessionStore: SessionStore
    private lateinit var settings: NetSettings
    @Volatile private var recorder: SessionRecorder? = null
    @Volatile private var link: FirebaseRestLink? = null

    @Volatile private var circuit: Circuit? = null
    @Volatile private var engine: LapEngine? = null
    @Volatile private var lastState: EngineState? = null
    @Volatile private var stint = StintState(1, "Piloto 1", 0, 0L, 0, 0, 0)

    // Última posición conocida (hilo USB -> UI)
    @Volatile private var hasFix = false
    @Volatile private var lastLat = 0.0
    @Volatile private var lastLon = 0.0
    @Volatile private var lastKmh = 0.0
    @Volatile private var lastCourse: Double? = null
    @Volatile private var lastDataAt = 0L
    @Volatile private var lastFixAt = 0L
    @Volatile private var currentAlert: String? = null
    private var hz = 0.0
    private var lastRawMs: Long? = null
    private var sats = 0
    private var autoLoadDone = false

    // Modo demo
    @Volatile private var demoActive = false
    private var demo: DemoSource? = null
    private var demoFactor = 1

    // Reconocimiento de circuito (borrador)
    private var reconName: String? = null
    private var draftFinish: GatePoint? = null
    private val draftSectors = mutableListOf<GatePoint>()

    private var netStatus = NetStatus.OFF

    // Delta filtrado a 5 Hz: se muestra la media de cada ventana de 200 ms
    private var deltaSum = 0.0
    private var deltaCount = 0
    private var deltaShownAt = 0L

    // Vistas y gestos
    private var simpleMode = false
    private var downX = 0f
    private var downY = 0f
    private var tracking = false
    private val hideTop = Runnable { topBar.visibility = View.GONE }

    // Mensajes del pit y petición de cambio de piloto
    private val activeMsgs = ArrayList<ActiveMsg>()
    private val prune = Runnable { pruneMsgs() }
    @Volatile private var pendingSwap: SwapRequest? = null

    // Reloj de 1 s: franja de stint y avisos
    private val tickHandler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateStintStrip()
            updateAlerts()
            tickHandler.postDelayed(this, 1000L)
        }
    }

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                openPort()
            } else {
                toast("Permiso USB denegado")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        bindViews()
        store = CircuitStore(this)
        statsStore = StatsStore(this)
        sessionStore = SessionStore(this)
        settings = NetSettings(this)
        recorder = SessionRecorder(sessionStore) { settings.saveTrace }
        stint = loadStint()

        circuit = store.loadActive()
        engine = circuit?.let { buildEngine(it, true) }

        link = FirebaseRestLink(
            settings,
            { buildTelemetry() },
            { msgs -> runOnUiThread { showPitMessages(msgs) } },
            { req -> runOnUiThread { pendingSwap = req; renderBottom() } },
            { st -> runOnUiThread { netStatus = st; renderNet() } }
        )

        btnHome.setOnClickListener { askExit() }
        btnMarkFinish.setOnClickListener { markFinish() }
        btnMarkSector.setOnClickListener { markSector() }
        btnSave.setOnClickListener { saveCircuit() }
        btnCancel.setOnClickListener { exitRecon() }
        btnSwapConfirm.setOnClickListener { confirmSwap() }
        txtTop.setOnClickListener { if (demoActive) cycleDemoSpeed() }

        // Salir con el botón "atrás" exige doble confirmación
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                askExit()
            }
        })

        ContextCompat.registerReceiver(
            this,
            permissionReceiver,
            IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        resetDisplay()
        refreshTop()
        renderNet()
        renderBottom()

        val recon = intent.getStringExtra("recon")
        if (recon != null) startRecon(recon)
        if (intent.getBooleanExtra("demo", false)) startDemo()

        showTopBar() // se ve 5 s al entrar para consultar el estado y luego se oculta
    }

    private fun bindViews() {
        topBar = findViewById(R.id.topBar)
        txtTop = findViewById(R.id.txtTop)
        btnHome = findViewById(R.id.btnHome)
        txtNet = findViewById(R.id.txtNet)
        txtGps = findViewById(R.id.txtGps)
        alertStrip = findViewById(R.id.alertStrip)
        viewMain = findViewById(R.id.viewMain)
        viewSimple = findViewById(R.id.viewSimple)
        txtDelta = findViewById(R.id.txtDelta)
        deltaBar = findViewById(R.id.deltaBar)
        txtRangeNeg = findViewById(R.id.txtRangeNeg)
        txtRangePos = findViewById(R.id.txtRangePos)
        txtRangeLabel = findViewById(R.id.txtRangeLabel)
        txtLap = findViewById(R.id.txtLap)
        chipsRow = findViewById(R.id.chipsRow)
        txtBest = findViewById(R.id.txtBest)
        txtLast = findViewById(R.id.txtLast)
        txtOpt = findViewById(R.id.txtOpt)
        txtStint = findViewById(R.id.txtStint)
        txtSpeed = findViewById(R.id.txtSpeed)
        txtDelta2 = findViewById(R.id.txtDelta2)
        deltaBar2 = findViewById(R.id.deltaBar2)
        chipsRow2 = findViewById(R.id.chipsRow2)
        bottomBar = findViewById(R.id.bottomBar)
        bannerPit = findViewById(R.id.bannerPit)
        reconBar = findViewById(R.id.reconBar)
        swapBar = findViewById(R.id.swapBar)
        txtSwap = findViewById(R.id.txtSwap)
        btnSwapConfirm = findViewById(R.id.btnSwapConfirm)
        btnMarkFinish = findViewById(R.id.btnMarkFinish)
        btnMarkSector = findViewById(R.id.btnMarkSector)
        btnSave = findViewById(R.id.btnSave)
        btnCancel = findViewById(R.id.btnCancel)
    }

    override fun onResume() {
        super.onResume()
        if (!demoActive) {
            stint = loadStint()
            syncActiveCircuit()
        }
        connect()
        link?.start()
        renderNet()
        tickHandler.post(tick)
    }

    override fun onPause() {
        tickHandler.removeCallbacks(tick)
        link?.stop()
        if (demoActive) stopDemo()
        if (hasFix && !demoActive) store.saveLastPosition(lastLat, lastLon)
        disconnect()
        super.onPause()
    }

    override fun onDestroy() {
        demo?.stop()
        recorder?.end()
        unregisterReceiver(permissionReceiver)
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    // ---------- Salir con doble confirmación ----------

    private fun askExit() {
        if (!checkUnlocked()) return
        AlertDialog.Builder(this)
            .setTitle("¿Cerrar la sesión?")
            .setMessage("Se dejará de cronometrar.")
            .setNegativeButton("Seguir", null)
            .setPositiveButton("Cerrar") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Confirma otra vez")
                    .setMessage("¿Seguro que quieres cerrar la sesión?")
                    .setNegativeButton("No, seguir", null)
                    .setPositiveButton("SÍ, CERRAR") { _, _ -> finish() }
                    .show()
            }
            .show()
    }

    // ---------- Gestos ----------

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
                tracking = true
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL -> tracking = false
            MotionEvent.ACTION_UP -> {
                if (tracking) {
                    tracking = false
                    handleSwipe(downX, downY, ev.rawX, ev.rawY)
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun handleSwipe(x0: Float, y0: Float, x1: Float, y1: Float) {
        val dm = resources.displayMetrics
        val dx = x1 - x0
        val dy = y1 - y0
        val min = 70f * dm.density
        val w = dm.widthPixels
        val h = dm.heightPixels
        val vertical = abs(dy) > abs(dx) * 1.5f
        val horizontal = abs(dx) > abs(dy) * 1.5f
        if (vertical && dy > min && y0 < h * 0.35f) {
            showTopBar()
        } else if (vertical && dy < -min && topBar.visibility == View.VISIBLE) {
            hideTopBarNow()
        } else if (horizontal && abs(dx) > min * 1.4f && x0 > w * 0.25f && x0 < w * 0.75f) {
            toggleView()
        }
    }

    private fun showTopBar() {
        topBar.visibility = View.VISIBLE
        topBar.removeCallbacks(hideTop)
        topBar.postDelayed(hideTop, TOPBAR_MS)
    }

    private fun hideTopBarNow() {
        topBar.removeCallbacks(hideTop)
        topBar.visibility = View.GONE
    }

    private fun toggleView() {
        simpleMode = !simpleMode
        viewMain.visibility = if (simpleMode) View.GONE else View.VISIBLE
        viewSimple.visibility = if (simpleMode) View.VISIBLE else View.GONE
    }

    // ---------- Stint ----------

    private fun loadStint(): StintState = StintState(
        settings.stintNumber,
        settings.driverName,
        settings.stintLapsDone,
        settings.stintStartEpoch,
        if (settings.stintPlan >= 0) settings.stintPlan else settings.defPlanLaps,
        if (settings.stintMin >= 0) settings.stintMin else settings.defMinMin,
        if (settings.stintMax >= 0) settings.stintMax else settings.defMaxMin
    )

    /** En modo demo el stint es temporal y no toca el estado guardado. */
    private fun saveStint() {
        if (demoActive) return
        val s = stint
        settings.stintNumber = s.number
        settings.stintLapsDone = s.lapsDone
        settings.stintStartEpoch = s.startEpoch
        settings.stintPlan = s.plan
        settings.stintMin = s.minMin
        settings.stintMax = s.maxMin
        settings.driverName = s.driver
    }

    private fun stintElapsedMs(): Long {
        val s = stint
        return if (s.startEpoch > 0L) System.currentTimeMillis() - s.startEpoch else 0L
    }

    private fun mmss(ms: Long): String {
        val t = ms / 1000
        return String.format(Locale.US, "%d:%02d", t / 60, t % 60)
    }

    private fun updateStintStrip() {
        val s = stint
        val el = stintElapsedMs()
        val started = s.startEpoch > 0L
        val sb = StringBuilder()
        sb.append("STINT ").append(s.number).append(" · ").append(s.driver.uppercase(Locale.getDefault()))
            .append(" · ").append(mmss(el))
        if (s.maxMin > 0) sb.append('/').append(mmss(s.maxMin * 60_000L))
        sb.append(" · V ").append(s.lapsDone)
        if (s.plan > 0) sb.append('/').append(s.plan)
        txtStint.text = sb.toString()
        val color = when {
            s.maxMin > 0 && started && el >= s.maxMin * 60_000L -> COL_RED
            (s.maxMin > 0 && started && el >= (s.maxMin - STINT_WARN_MIN) * 60_000L) ||
                (s.plan > 0 && s.lapsDone >= s.plan) -> COL_AMBER
            s.minMin > 0 && el >= s.minMin * 60_000L -> COL_GREEN
            else -> COL_MUTED
        }
        txtStint.setTextColor(color)
    }

    // ---------- Avisos visuales (sin sonido ni vibración) ----------

    private fun isCharging(): Boolean {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun batteryLevel(): Int {
        val b = batteryPct()
        return if (b in 1..100) b else 100
    }

    /** Devuelve (texto, esRojo) del aviso más importante, o null si no hay ninguno. */
    private fun computeAlert(): Pair<String, Boolean>? {
        val now = SystemClock.elapsedRealtime()
        if (!demoActive) {
            if (port == null || now - lastDataAt > SIGNAL_TIMEOUT_MS) return Pair("SIN ANTENA", true)
            if (now - lastFixAt > SIGNAL_TIMEOUT_MS) return Pair("SIN GPS", true)
        }
        val s = stint
        val el = stintElapsedMs()
        val started = s.startEpoch > 0L
        if (s.maxMin > 0 && started && el >= s.maxMin * 60_000L) {
            return Pair("STINT: LÍMITE DE TIEMPO SUPERADO", true)
        }
        val bat = batteryLevel()
        val charging = isCharging()
        if (!charging && bat <= settings.batCrit) return Pair("BATERÍA CRÍTICA $bat %", true)
        if (s.maxMin > 0 && started && el >= (s.maxMin - STINT_WARN_MIN) * 60_000L) {
            val left = (s.maxMin * 60_000L - el + 59_999L) / 60_000L
            return Pair("STINT: QUEDAN $left MIN PARA EL MÁXIMO", false)
        }
        if (s.plan > 0 && s.lapsDone >= s.plan) return Pair("STINT: VUELTAS PLANIFICADAS COMPLETADAS", false)
        if (!charging && bat <= settings.batWarn) return Pair("BATERÍA BAJA $bat %", false)
        return null
    }

    private fun updateAlerts() {
        val a = computeAlert()
        currentAlert = a?.first
        if (a == null) {
            alertStrip.visibility = View.GONE
            return
        }
        alertStrip.text = a.first
        alertStrip.setBackgroundColor(if (a.second) COL_ALERT_RED else COL_AMBER)
        alertStrip.setTextColor(if (a.second) Color.WHITE else Color.parseColor("#141413"))
        alertStrip.visibility = View.VISIBLE
    }

    // ---------- Motor ----------

    /** Ámbito de las marcas: "" = todo el coche; "p_<piloto>" = el piloto actual. */
    private fun scopeKey(): String =
        if (settings.refScope == "piloto") "p_" + NetSettings.keyOf(stint.driver) else ""

    private fun buildEngine(c: Circuit, withHistory: Boolean): LapEngine {
        val initial = if (withHistory) statsStore.load(c, scopeKey()) else null
        val e = LapEngine(c, initial)
        e.onLap = { r -> handleLap(r) }
        e.onBoundary = { runOnUiThread { onBoundary() } }
        return e
    }

    /** Se llama al cerrar cada vuelta válida (hilo USB, o principal en demo). */
    private fun handleLap(r: LapResult) {
        link?.enqueueLap(lapJson(r))
        val s = stint
        s.lapsDone++
        saveStint()
        if (demoActive) return
        recorder?.onLap(r)
        val c = circuit
        if (c != null) {
            statsStore.update(c, "", r)
            statsStore.update(c, "p_" + NetSettings.keyOf(s.driver), r)
        }
    }

    private fun syncActiveCircuit() {
        val active = store.loadActive()
        if (active != null && active != circuit) selectCircuit(active)
    }

    private fun selectCircuit(c: Circuit) {
        recorder?.end()
        circuit = c
        engine = buildEngine(c, true)
        lastState = null
        store.activeName = c.name
        resetDisplay()
        refreshTop()
    }

    // ---------- Conexión USB ----------

    private fun findDriver(): UsbSerialDriver? =
        UsbSerialProber.getDefaultProber().findAllDrivers(usbManager).firstOrNull()

    private fun connect() {
        if (port != null) return
        val driver = findDriver()
        if (driver == null) {
            if (!demoActive) txtGps.text = "Conecta la antena por USB"
            return
        }
        if (!usbManager.hasPermission(driver.device)) {
            val pi = PendingIntent.getBroadcast(
                this,
                0,
                Intent(ACTION_USB_PERMISSION).setPackage(packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usbManager.requestPermission(driver.device, pi)
            txtGps.text = "Pidiendo permiso USB..."
            return
        }
        openPort()
    }

    private fun openPort() {
        val driver = findDriver()
        if (driver == null) {
            txtGps.text = "Antena no detectada"
            return
        }
        val connection = usbManager.openDevice(driver.device)
        if (connection == null) {
            txtGps.text = "No se pudo abrir el USB"
            return
        }
        val p = driver.ports[0]
        try {
            p.open(connection)
            p.setParameters(BAUD_RATE, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: Exception) {
            txtGps.text = "Error USB: ${e.message}"
            runCatching { p.close() }
            return
        }
        port = p
        ioManager = SerialInputOutputManager(p, this).also { ioExecutor.submit(it) }
        txtGps.text = "Esperando GPS..."
    }

    private fun disconnect() {
        ioManager?.stop()
        ioManager = null
        runCatching { port?.close() }
        port = null
    }

    // ---------- Datos del GPS (hilo de E/S) ----------

    override fun onNewData(data: ByteArray) {
        lastDataAt = SystemClock.elapsedRealtime()
        val text = String(data, Charsets.US_ASCII)
        synchronized(lineBuffer) {
            lineBuffer.append(text)
            var idx = lineBuffer.indexOf("\n")
            while (idx >= 0) {
                val line = lineBuffer.substring(0, idx).trim()
                lineBuffer.delete(0, idx + 1)
                if (line.isNotEmpty()) handleSentence(line)
                idx = lineBuffer.indexOf("\n")
            }
        }
    }

    override fun onRunError(e: Exception) {
        runOnUiThread {
            txtGps.text = "USB desconectado"
            disconnect()
        }
    }

    private fun handleSentence(line: String) {
        when (val ev = parser.parse(line)) {
            is NmeaEvent.Position -> if (!demoActive) onPosition(ev, true)
            is NmeaEvent.Fix -> runOnUiThread {
                sats = ev.sats
                renderGps()
            }
            null -> Unit
        }
    }

    private fun onPosition(ev: NmeaEvent.Position, render: Boolean) {
        lastLat = ev.lat
        lastLon = ev.lon
        lastKmh = ev.speedKmh
        hasFix = true
        if (!demoActive) lastFixAt = SystemClock.elapsedRealtime()
        val c = ev.courseDeg
        if (c != null && ev.speedKmh > 1.5) lastCourse = c

        // El stint empieza a contar cuando el coche se mueve
        val sNow = stint
        if (sNow.startEpoch == 0L && ev.speedKmh > 5.0) {
            sNow.startEpoch = System.currentTimeMillis()
            saveStint()
        }

        val prev = lastRawMs
        if (prev != null) {
            val d = ev.timeMs - prev
            if (d in 1L..1000L) {
                val inst = 1000.0 / d
                hz = if (hz == 0.0) inst else hz * 0.95 + inst * 0.05
            }
        }
        lastRawMs = ev.timeMs

        val st = engine?.onFix(ev.lat, ev.lon, ev.speedKmh, ev.timeMs)
        lastState = st

        if (!demoActive && st != null) {
            val circ = circuit
            val rec = recorder
            if (circ != null && rec != null &&
                rec.onSample(
                    circ, st.gpsTimeMs, ev.lat, ev.lon, ev.speedKmh,
                    stint.driver, stint.number, settings.carName
                )
            ) {
                engine?.resetSession()
            }
        }

        if (!render) return
        runOnUiThread {
            txtSpeed.text = String.format(Locale.US, "%.0f", ev.speedKmh)
            renderGps()
            if (st != null) renderEngine(st)
            updateLock()
            if (!demoActive && !autoLoadDone) {
                autoLoadDone = true
                autoLoad(ev.lat, ev.lon)
            }
        }
    }

    /** Carga el circuito guardado más cercano la primera vez que hay señal (no en mitad de una vuelta). */
    private fun autoLoad(lat: Double, lon: Double) {
        if (reconName != null) return
        if (lastState?.running == true) return
        val near = store.nearest(lat, lon, AUTOLOAD_M) ?: return
        if (near.name != circuit?.name) {
            selectCircuit(near)
            toast("Circuito cargado: ${near.name}")
        }
    }

    // ---------- Pantalla ----------

    private fun renderGps() {
        txtGps.text = when {
            demoActive -> String.format(Locale.US, "DEMO ×%d · GPS simulado %.0f Hz", demoFactor, hz)
            !hasFix -> "GPS sin señal"
            else -> String.format(Locale.US, "GPS %.0f Hz · %d sat", hz, sats)
        }
    }

    private fun renderNet() {
        when {
            !settings.enabled -> {
                txtNet.text = "PIT: desactivado"
                txtNet.setTextColor(COL_MUTED)
            }
            netStatus == NetStatus.OK -> {
                txtNet.text = "PIT: conectado"
                txtNet.setTextColor(COL_GREEN)
            }
            netStatus == NetStatus.ERROR -> {
                txtNet.text = "PIT: sin red"
                txtNet.setTextColor(COL_RED)
            }
            else -> {
                txtNet.text = "PIT: conectando…"
                txtNet.setTextColor(COL_MUTED)
            }
        }
    }

    private fun rangeFraction(): Double = settings.rangePct / 100.0

    private fun renderEngine(st: EngineState) {
        txtLap.text = fmtMs(st.currentLapMs)
        txtLast.text = fmtMs(st.lastLapMs)
        txtBest.text = fmtMs(st.bestLapMs)
        txtOpt.text = fmtMs(st.optimalMs)
        renderChips(chipsRow, st.marks, st.sectorCount, 12f)
        renderChips(chipsRow2, st.marks, st.sectorCount, 24f)

        txtRangeLabel.text = String.format(Locale.US, "±%.1f %% MEJOR VUELTA", settings.rangePct)
        val best = st.bestLapMs
        val range = if (best != null) best * rangeFraction() / 1000.0 else null
        if (range != null) {
            txtRangeNeg.text = String.format(Locale.US, "-%.2f s", range)
            txtRangePos.text = String.format(Locale.US, "+%.2f s", range)
        } else {
            txtRangeNeg.text = String.format(Locale.US, "-%.1f %%", settings.rangePct)
            txtRangePos.text = String.format(Locale.US, "+%.1f %%", settings.rangePct)
        }

        // Delta a 5 Hz: acumula las muestras y muestra su media cada 200 ms
        val d = st.deltaSec
        if (d != null) {
            deltaSum += d
            deltaCount++
        }
        val now = SystemClock.elapsedRealtime()
        if (now - deltaShownAt >= DELTA_UI_MS) {
            deltaShownAt = now
            val avg = if (deltaCount > 0) deltaSum / deltaCount else null
            deltaSum = 0.0
            deltaCount = 0
            renderDelta(avg, range)
        }

        if (reconName == null) {
            val name = circuit?.name ?: ""
            val prefix = if (demoActive) "DEMO ×$demoFactor · " else ""
            txtTop.text = if (st.running) {
                "${prefix}Vuelta ${st.lapNumber} · S${st.sector}/${st.sectorCount} · $name"
            } else {
                "${prefix}$name · cruza la meta para empezar"
            }
        }
    }

    private fun renderDelta(d: Double?, range: Double?) {
        if (d != null && range != null && range > 0.0) {
            val text = String.format(Locale.US, "%+.3f", d)
            val color = if (d <= 0.0) COL_GREEN else COL_RED
            val ratio = (d / range).toFloat()
            txtDelta.text = text
            txtDelta2.text = text
            txtDelta.setTextColor(color)
            txtDelta2.setTextColor(color)
            deltaBar.setRatio(ratio)
            deltaBar2.setRatio(ratio)
        } else {
            txtDelta.text = "—.—"
            txtDelta2.text = "—.—"
            txtDelta.setTextColor(COL_GREEN)
            txtDelta2.setTextColor(COL_GREEN)
            deltaBar.setRatio(0f)
            deltaBar2.setRatio(0f)
        }
    }

    private fun renderChips(row: LinearLayout, marks: List<SectorMark?>, count: Int, textSp: Float) {
        val have = (row.tag as? Int) ?: 0
        if (have != count) {
            row.removeAllViews()
            for (i in 0 until count) {
                val tv = AppCompatTextView(this)
                tv.typeface = Typeface.DEFAULT_BOLD
                tv.gravity = Gravity.CENTER
                tv.maxLines = 1
                TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                    tv, 8, textSp.toInt(), 1, TypedValue.COMPLEX_UNIT_SP
                )
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                if (i > 0) lp.marginStart = dp(6)
                row.addView(tv, lp)
            }
            row.tag = count
        }
        for (i in 0 until count) {
            val tv = row.getChildAt(i) as TextView
            val m = marks.getOrNull(i)
            val bg = GradientDrawable()
            bg.cornerRadius = dp(8).toFloat()
            if (m == null) {
                bg.setColor(COL_NEUTRAL)
                tv.setTextColor(COL_MUTED)
                tv.text = "S${i + 1} --"
            } else {
                val fill: Int
                val fg: Int
                when (m.kind) {
                    MarkKind.NEUTRAL -> { fill = COL_NEUTRAL; fg = Color.WHITE }
                    MarkKind.PURPLE -> { fill = COL_PURPLE; fg = Color.WHITE }
                    MarkKind.GREEN -> { fill = COL_GREEN; fg = COL_DARK }
                    MarkKind.YELLOW -> { fill = COL_YELLOW; fg = COL_DARK }
                }
                bg.setColor(fill)
                tv.setTextColor(fg)
                tv.text = "S${i + 1} " + String.format(Locale.US, "%.2f", m.ms / 1000.0)
            }
            tv.background = bg
        }
    }

    private fun resetDisplay() {
        txtLap.text = "--:--.---"
        txtLast.text = "--:--.---"
        txtBest.text = "--:--.---"
        txtOpt.text = "--:--.---"
        deltaSum = 0.0
        deltaCount = 0
        renderDelta(null, null)
        txtRangeLabel.text = String.format(Locale.US, "±%.1f %% MEJOR VUELTA", settings.rangePct)
        txtRangeNeg.text = String.format(Locale.US, "-%.1f %%", settings.rangePct)
        txtRangePos.text = String.format(Locale.US, "+%.1f %%", settings.rangePct)
        val n = circuit?.sectorCount ?: 3
        renderChips(chipsRow, emptyList(), n, 12f)
        renderChips(chipsRow2, emptyList(), n, 24f)
        updateStintStrip()
    }

    private fun refreshTop() {
        val name = reconName
        txtTop.text = when {
            name != null -> "Reconocimiento «$name» · meta ${if (draftFinish != null) "✔" else "—"} · sectores ${draftSectors.size}"
            demoActive -> "DEMO ×$demoFactor · toca aquí para cambiar la velocidad"
            circuit == null -> "Sin circuito · vuelve a INICIO > CIRCUITOS"
            else -> "${circuit?.name} · cruza la meta para empezar"
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Bloqueo en movimiento ----------

    private fun locked(): Boolean = !demoActive && settings.lockKmh > 0 && lastKmh > settings.lockKmh

    private fun updateLock() {
        val a = if (locked()) 0.4f else 1f
        btnHome.alpha = a
        btnSwapConfirm.alpha = a
    }

    private fun checkUnlocked(): Boolean {
        if (locked()) {
            toast("Bloqueado: vas a más de ${settings.lockKmh} km/h")
            return false
        }
        return true
    }

    // ---------- Banda inferior: reconocimiento, cambio de piloto o mensaje del pit ----------

    private fun showPitMessages(list: List<PitMessage>) {
        if (list.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        for (m in list) activeMsgs.add(ActiveMsg(m.text, m.bg, settings.msgSectors, now))
        renderBottom()
    }

    /** Cada vez que se cruza un sector o la meta, los mensajes pierden un sector de vida. */
    private fun onBoundary() {
        if (activeMsgs.isEmpty()) return
        for (m in activeMsgs) m.remaining--
        activeMsgs.removeAll { it.remaining <= 0 }
        renderBottom()
    }

    private fun pruneMsgs() {
        val now = SystemClock.elapsedRealtime()
        activeMsgs.removeAll { now - it.at > MSG_MAX_MS }
        renderBottom()
    }

    /** Prioridad: reconocimiento > petición de cambio de piloto > mensaje del pit. */
    private fun renderBottom() {
        bannerPit.removeCallbacks(prune)
        val swap = pendingSwap
        val m = activeMsgs.lastOrNull()
        val recon = reconName != null

        reconBar.visibility = if (recon) View.VISIBLE else View.GONE

        val showSwap = !recon && swap != null
        swapBar.visibility = if (showSwap) View.VISIBLE else View.GONE
        if (swap != null) {
            val laps = if (swap.laps > 0) " · ${swap.laps} vueltas" else ""
            txtSwap.text = "PIT PIDE CAMBIO → ${swap.next.uppercase(Locale.getDefault())}$laps"
        }

        val showMsg = !recon && swap == null && m != null
        if (showMsg && m != null) {
            applyMsgStyle(m.bg, m.text)
            bannerPit.visibility = View.VISIBLE
            bannerPit.postDelayed(prune, 30_000L)
        } else {
            bannerPit.visibility = View.GONE
        }

        bottomBar.visibility = if (recon || showSwap || showMsg) View.VISIBLE else View.GONE
    }

    private fun solid(fill: Int, fg: Int, text: String) {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(14).toFloat()
        bannerPit.background = g
        bannerPit.setTextColor(fg)
        bannerPit.text = text
    }

    private fun applyMsgStyle(bg: String, text: String) {
        when (bg) {
            "verde" -> solid(Color.parseColor("#22C55E"), COL_DARK, text)
            "rojo" -> solid(Color.parseColor("#EF4444"), Color.WHITE, text)
            "azul" -> solid(Color.parseColor("#2563EB"), Color.WHITE, text)
            "blanco" -> solid(Color.parseColor("#F2F4F7"), Color.parseColor("#141413"), text)
            "rayas" -> {
                bannerPit.background = StripesDrawable(COL_YELLOW, Color.parseColor("#EF4444"), dp(14).toFloat())
                bannerPit.setTextColor(Color.WHITE)
                val sp = SpannableString(" $text ")
                sp.setSpan(
                    BackgroundColorSpan(Color.parseColor("#E6141413")),
                    0, sp.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                bannerPit.text = sp
            }
            else -> solid(COL_YELLOW, Color.parseColor("#141413"), text)
        }
    }

    /** Confirma en boxes el cambio de piloto pedido desde el panel: cierra el stint y abre el siguiente. */
    private fun confirmSwap() {
        val req = pendingSwap ?: return
        if (!checkUnlocked()) return
        recorder?.end()
        val plan = if (req.laps > 0) req.laps else settings.defPlanLaps
        val mn = if (req.minMin > 0) req.minMin else settings.defMinMin
        val mx = if (req.maxMin > 0) req.maxMin else settings.defMaxMin
        stint = StintState(stint.number + 1, req.next.ifEmpty { "Piloto" }, 0, 0L, plan, mn, mx)
        saveStint()
        val c = circuit
        if (!demoActive && c != null && settings.refScope == "piloto") {
            engine = buildEngine(c, true)
            lastState = null
            resetDisplay()
        } else {
            engine?.resetSession()
        }
        pendingSwap = null
        link?.clearCommandNow()
        renderBottom()
        updateStintStrip()
        toast("Cambio hecho: conduce ${stint.driver}")
    }

    // ---------- Telemetría hacia el pit ----------

    private fun batteryPct(): Int {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun buildTelemetry(): String? {
        if (!hasFix && !demoActive) return null
        val o = JSONObject()
        val s = stint
        o.put("t", System.currentTimeMillis())
        o.put("lat", lastLat)
        o.put("lon", lastLon)
        o.put("kmh", Math.round(lastKmh))
        o.put("car", settings.carName)
        o.put("driver", s.driver)
        o.put("circuito", circuit?.name ?: "")
        o.put("demo", demoActive)
        o.put("bat", batteryPct())
        o.put("v", APP_VERSION)
        o.put("stint", s.number)
        o.put("stintLaps", s.lapsDone)
        o.put("plan", s.plan)
        o.put("stintMs", stintElapsedMs())
        o.put("minMs", s.minMin * 60_000L)
        o.put("maxMs", s.maxMin * 60_000L)
        pendingSwap?.let { o.put("swap", it.next) }
        currentAlert?.let { o.put("alert", it) }
        val st = lastState
        if (st != null) {
            o.put("lap", st.lapNumber)
            o.put("sector", st.sector)
            o.put("sectores", st.sectorCount)
            o.put("run", st.running)
            st.currentLapMs?.let { o.put("cur", it) }
            st.lastLapMs?.let { o.put("last", it) }
            st.bestLapMs?.let { o.put("best", it) }
            st.optimalMs?.let { o.put("opt", it) }
            st.deltaSec?.let { o.put("delta", it) }
        }
        return o.toString()
    }

    private fun lapJson(r: LapResult): String {
        val o = JSONObject()
        o.put("n", r.number)
        o.put("ms", r.lapMs)
        val arr = JSONArray()
        for (sp in r.splits) arr.put(sp)
        o.put("s", arr)
        o.put("t", System.currentTimeMillis())
        o.put("circuito", circuit?.name ?: "")
        o.put("d", stint.driver)
        o.put("st", stint.number)
        o.put("demo", demoActive)
        return o.toString()
    }

    // ---------- Modo demo ----------

    private fun startDemo() {
        if (reconName != null) exitRecon()
        recorder?.end()
        demoActive = true
        stint = StintState(1, "Demo", 0, 0L, settings.defPlanLaps, settings.defMinMin, settings.defMaxMin)
        circuit = DemoCircuit.circuit
        engine = buildEngine(DemoCircuit.circuit, false)
        lastState = null
        hz = 0.0
        lastRawMs = null
        resetDisplay()
        val d = DemoSource(Handler(Looper.getMainLooper())) { ev, render -> onPosition(ev, render) }
        d.factor = demoFactor
        demo = d
        refreshTop()
        d.start()
        toast("Demo: desliza desde arriba y toca la barra para cambiar la velocidad")
    }

    private fun stopDemo() {
        demo?.stop()
        demo = null
        demoActive = false
        stint = loadStint()
        circuit = store.loadActive()
        engine = circuit?.let { buildEngine(it, true) }
        lastState = null
        lastKmh = 0.0
        hz = 0.0
        lastRawMs = null
        resetDisplay()
        refreshTop()
        renderGps()
        updateLock()
    }

    private fun cycleDemoSpeed() {
        demoFactor = when (demoFactor) {
            1 -> 2
            2 -> 4
            else -> 1
        }
        demo?.factor = demoFactor
        showTopBar()
        toast("Demo ×$demoFactor")
    }

    // ---------- Reconocimiento de circuito ----------

    private fun startRecon(name: String) {
        reconName = name
        draftFinish = null
        draftSectors.clear()
        renderBottom()
        refreshTop()
        showTopBar()
    }

    private fun exitRecon() {
        reconName = null
        draftFinish = null
        draftSectors.clear()
        renderBottom()
        refreshTop()
    }

    private fun currentPoint(): GatePoint? {
        val course = lastCourse
        if (!hasFix || course == null) {
            toast("Aún no hay rumbo: avanza o camina unos segundos")
            return null
        }
        return GatePoint(lastLat, lastLon, course)
    }

    private fun markFinish() {
        if (!checkUnlocked()) return
        val p = currentPoint() ?: return
        draftFinish = p
        refreshTop()
        toast("Meta marcada")
    }

    private fun markSector() {
        if (!checkUnlocked()) return
        if (draftFinish == null) {
            toast("Marca primero la meta")
            return
        }
        val p = currentPoint() ?: return
        draftSectors.add(p)
        refreshTop()
        toast("Sector marcado")
    }

    private fun saveCircuit() {
        if (!checkUnlocked()) return
        val name = reconName ?: return
        val finish = draftFinish
        if (finish == null) {
            toast("Marca primero la meta")
            return
        }
        val c = Circuit(name, finish, draftSectors.toList())
        store.save(c)
        exitRecon()
        selectCircuit(c)
        toast("Circuito guardado: ${c.sectorCount} sectores")
    }
}
