package com.ejemplo.laptimer

import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** Ajustes de red, de sesión y estado del stint, guardados en el móvil. */
class NetSettings(context: Context) {
    private val p = context.getSharedPreferences("laptimer_net", Context.MODE_PRIVATE)

    private fun putS(k: String, v: String) = p.edit().putString(k, v).apply()
    private fun putI(k: String, v: Int) = p.edit().putInt(k, v).apply()

    // ---- Red ----
    var enabled: Boolean
        get() = p.getBoolean("enabled", false)
        set(v) {
            p.edit().putBoolean("enabled", v).apply()
        }

    var dbUrl: String
        get() = p.getString("db", "") ?: ""
        set(v) = putS("db", v.trim().trimEnd('/'))

    var room: String
        get() = p.getString("room", "") ?: ""
        set(v) = putS("room", v.trim().uppercase())

    var intervalS: Int
        get() = p.getInt("interval", 10)
        set(v) = putI("interval", v.coerceAtLeast(10))

    var panelUrl: String
        get() = p.getString("panel", "") ?: ""
        set(v) = putS("panel", v.trim())

    var saveTrace: Boolean
        get() = p.getBoolean("trace", true)
        set(v) {
            p.edit().putBoolean("trace", v).apply()
        }

    // ---- Identidad ----
    var carName: String
        get() = p.getString("carName", "Coche 1") ?: "Coche 1"
        set(v) = putS("carName", v.trim().ifEmpty { "Coche 1" })

    var driverName: String
        get() = p.getString("driver", "Piloto 1") ?: "Piloto 1"
        set(v) = putS("driver", v.trim().ifEmpty { "Piloto 1" })

    fun carKey(): String = keyOf(carName)

    // ---- Ajustes de sesión ----
    var lockKmh: Int
        get() = p.getInt("lockKmh", 10)
        set(v) = putI("lockKmh", v.coerceAtLeast(0))

    var rangePct: Float
        get() = p.getFloat("rangePct", 2f)
        set(v) {
            p.edit().putFloat("rangePct", v.coerceIn(0.5f, 10f)).apply()
        }

    var msgSectors: Int
        get() = p.getInt("msgSectors", 2)
        set(v) = putI("msgSectors", v.coerceIn(1, 6))

    var batWarn: Int
        get() = p.getInt("batWarn", 20)
        set(v) = putI("batWarn", v.coerceIn(1, 90))

    var batCrit: Int
        get() = p.getInt("batCrit", 10)
        set(v) = putI("batCrit", v.coerceIn(1, 90))

    /** "coche" = delta y récords de todo el coche; "piloto" = de cada piloto por separado. */
    var refScope: String
        get() = p.getString("refScope", "coche") ?: "coche"
        set(v) = putS("refScope", v)

    // Valores por defecto para stints nuevos (0 = sin límite o sin plan)
    var defPlanLaps: Int
        get() = p.getInt("defPlan", 0)
        set(v) = putI("defPlan", v.coerceAtLeast(0))

    var defMinMin: Int
        get() = p.getInt("defMin", 0)
        set(v) = putI("defMin", v.coerceAtLeast(0))

    var defMaxMin: Int
        get() = p.getInt("defMax", 0)
        set(v) = putI("defMax", v.coerceAtLeast(0))

    // ---- Estado del stint en curso (-1 = usar el valor por defecto) ----
    var stintNumber: Int
        get() = p.getInt("stintNumber", 1)
        set(v) = putI("stintNumber", v)

    var stintLapsDone: Int
        get() = p.getInt("stintLaps", 0)
        set(v) = putI("stintLaps", v)

    var stintStartEpoch: Long
        get() = p.getLong("stintStart", 0L)
        set(v) {
            p.edit().putLong("stintStart", v).apply()
        }

    var stintPlan: Int
        get() = p.getInt("stintPlan", -1)
        set(v) = putI("stintPlan", v)

    var stintMin: Int
        get() = p.getInt("stintMin", -1)
        set(v) = putI("stintMin", v)

    var stintMax: Int
        get() = p.getInt("stintMax", -1)
        set(v) = putI("stintMax", v)

    fun resetStint() {
        stintNumber = 1
        stintLapsDone = 0
        stintStartEpoch = 0L
        stintPlan = -1
        stintMin = -1
        stintMax = -1
    }

    fun ensureRoom(): String {
        var r = room
        if (r.isBlank()) {
            r = newCode()
            room = r
        }
        return r
    }

    companion object {
        fun newCode(): String {
            val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            val rnd = SecureRandom()
            val sb = StringBuilder()
            for (i in 0 until 10) sb.append(alphabet[rnd.nextInt(alphabet.length)])
            return sb.toString()
        }

        /** Clave segura para rutas de Firebase y nombres de archivo. */
        fun keyOf(s: String): String {
            val k = s.trim().lowercase().replace(Regex("[^a-z0-9_-]"), "-").trim('-')
            return if (k.isEmpty()) "x" else k
        }
    }
}

class PitMessage(val key: String, val text: String, val bg: String)

/** Petición de cambio de piloto enviada desde el panel del pit. */
class SwapRequest(val id: String, val next: String, val laps: Int, val minMin: Int, val maxMin: Int)

enum class NetStatus { OFF, OK, ERROR }

/**
 * Conexión con Firebase Realtime Database por su API REST (sin SDK, solo la URL de la base de datos).
 *
 * Estructura en la sala: live/<coche>, laps/<coche>, inbox/<coche> (mensajes) y cmd/<coche> (órdenes).
 * Para ahorrar batería hace un único intercambio cada `intervalS` segundos (mínimo 10):
 *  - sube la telemetría y las vueltas terminadas,
 *  - baja los mensajes nuevos y la orden de cambio de piloto, si la hay.
 * No usa conexión permanente.
 */
class FirebaseRestLink(
    private val settings: NetSettings,
    private val telemetry: () -> String?,
    private val onMessages: (List<PitMessage>) -> Unit,
    private val onCommand: (SwapRequest?) -> Unit,
    private val onStatus: (NetStatus) -> Unit
) {
    private var exec: ScheduledExecutorService? = null
    private val pendingLaps = ConcurrentLinkedQueue<String>()
    private var lastKey: String? = null
    private var lastCmdId: String? = null
    private var first = true

    fun enqueueLap(json: String) {
        pendingLaps.add(json)
        while (pendingLaps.size > 300) pendingLaps.poll()
    }

    fun start() {
        stop()
        if (!settings.enabled || settings.dbUrl.isBlank() || settings.room.isBlank()) {
            onStatus(NetStatus.OFF)
            return
        }
        first = true
        lastKey = null
        lastCmdId = null
        val e = Executors.newSingleThreadScheduledExecutor()
        exec = e
        val period = settings.intervalS.toLong().coerceAtLeast(10L)
        e.scheduleWithFixedDelay({ cycle() }, 0L, period, TimeUnit.SECONDS)
    }

    fun stop() {
        exec?.shutdownNow()
        exec = null
    }

    /** Borra la orden de cambio en Firebase tras confirmarla en boxes. */
    fun clearCommandNow() {
        val car = settings.carKey()
        Thread {
            try {
                request("PUT", "cmd/$car", "null", "")
            } catch (e: Exception) {
                // se reintentará en el siguiente intercambio si la orden sigue ahí
            }
        }.start()
    }

    private fun cycle() {
        try {
            val car = settings.carKey()
            val t = telemetry()
            if (t != null) request("PUT", "live/$car", t, "")
            while (true) {
                val lap = pendingLaps.peek() ?: break
                request("POST", "laps/$car", lap, "")
                pendingLaps.poll()
            }
            fetchMessages(car)
            fetchCommand(car)
            onStatus(NetStatus.OK)
        } catch (e: Exception) {
            onStatus(NetStatus.ERROR)
        }
    }

    private fun fetchMessages(car: String) {
        val txt = request("GET", "inbox/$car", null, "?orderBy=%22%24key%22&limitToLast=5").trim()
        val keys: List<String>
        var o: JSONObject? = null
        if (txt.isEmpty() || txt == "null") {
            keys = emptyList()
        } else {
            val obj = JSONObject(txt)
            o = obj
            val list = ArrayList<String>()
            val it = obj.keys()
            while (it.hasNext()) list.add(it.next())
            list.sort()
            keys = list
        }
        if (first) {
            lastKey = keys.lastOrNull()
            first = false
            return
        }
        val seen = lastKey
        val fresh = keys.filter { seen == null || it > seen }
        if (fresh.isEmpty() || o == null) return
        lastKey = fresh.last()
        val msgs = ArrayList<PitMessage>()
        for (k in fresh) {
            val m = o.getJSONObject(k)
            val text = m.optString("text", "")
            val bg = m.optString("bg", "amarillo")
            if (text.isNotBlank()) msgs.add(PitMessage(k, text, bg))
        }
        if (msgs.isNotEmpty()) onMessages(msgs)
    }

    private fun fetchCommand(car: String) {
        val txt = request("GET", "cmd/$car", null, "").trim()
        if (txt.isEmpty() || txt == "null") {
            if (lastCmdId != null) {
                lastCmdId = null
                onCommand(null)
            }
            return
        }
        val o = JSONObject(txt)
        val id = o.optString("id", "")
        if (id != lastCmdId) {
            lastCmdId = id
            onCommand(
                SwapRequest(
                    id, o.optString("next", ""), o.optInt("laps", 0),
                    o.optInt("min", 0), o.optInt("max", 0)
                )
            )
        }
    }

    private fun request(method: String, path: String, body: String?, query: String): String {
        val url = URL(settings.dbUrl + "/rooms/" + settings.room + "/" + path + ".json" + query)
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 6000
            c.readTimeout = 6000
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code")
            return text
        } finally {
            c.disconnect()
        }
    }
}
