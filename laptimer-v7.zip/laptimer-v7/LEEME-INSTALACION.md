# Actualizar de la 0.6 a la 0.7

La 0.6 ya lleva la firma fija, así que la 0.7 se instala **encima** y se conservan circuitos, sesiones y ajustes.

## 1. App
1. En tu repositorio privado: **Add file > Upload files** y sube `laptimer-v7.zip` sin descomprimir. Commit.
   El flujo usa siempre el zip con el número más alto.
2. **Actions**: espera al ✓ verde (3 a 5 minutos). Después **Releases > APK más reciente > laptimer.apk**, en tu Android.
3. Instálala encima de la 0.6. Si Android dice que hay un conflicto con otra app, avísame antes de desinstalar nada.
4. Si sale en rojo, copia el error del paso "Compilar APK" y pégalo en el chat.

## 2. Panel web
1. En el repositorio público `panel-pit`: **Add file > Upload files**, sube el `index.html` nuevo y **Commit changes**.
2. Espera 1 o 2 minutos. Si no cambia, añade `?v=7` al final de la dirección.
3. **Las reglas de Firebase no cambian.**
4. Los datos antiguos de la 0.6 (`live`, `laps`, `msgs` en la raíz de la sala) quedan sin usar. Para limpiarlos:
   Firebase > Realtime Database > Datos, abre `rooms` y borra los nodos viejos.

## 3. Configurar cada móvil
**INICIO > AJUSTES Y PIT CREW**: pon un **nombre de coche distinto** en cada móvil y el **piloto actual**.
El panel muestra una tarjeta por coche. Los mensajes se envían a todos o a uno.

## 4. Cambio de piloto (carreras de resistencia)
1. En el panel, en la tarjeta del coche: **Pedir cambio de piloto**. Escribe quién entra y, si quieres, las vueltas
   planificadas y los tiempos mínimo y máximo del siguiente stint (con 0 se usan los de la app).
2. En el móvil aparece en la parte baja **PIT PIDE CAMBIO → NOMBRE**.
3. En boxes, con el coche parado, toca **CONFIRMAR CAMBIO**. Se cierra el stint y la sesión del piloto que sale,
   y empieza un stint nuevo. El tiempo del stint empieza a contar cuando el coche se mueve.
4. El pit puede cancelar la petición desde el panel antes de que se confirme.

## 5. Ajustes de sesión
**INICIO > AJUSTES DE SESIÓN**: bloqueo en movimiento (km/h), rango de la barra del delta, duración de los
mensajes en sectores, umbrales de batería, ámbito del delta y los récords (coche o cada piloto), y valores por defecto
del stint. También reinicia los contadores de stint al empezar una carrera nueva.

## 6. Copia de seguridad
**INICIO > COPIA DE SEGURIDAD**: crea un zip con circuitos, marcas, sesiones y ajustes (con o sin trazas GPS) y lo
comparte. Restaurar añade lo que falte y sustituye lo que tenga el mismo nombre. La copia incluye el código de sala:
guárdala en privado.

## 7. Probar en casa
1. **MODO DEMO**, y abre el panel: verás el coche "Demo" con su stint.
2. Pide un cambio de piloto desde el panel y confírmalo en la app (en demo no hay bloqueo).
3. Prueba los avisos: desconecta la antena y verás una franja roja "SIN ANTENA".

## Salir de la sesión
El botón "atrás" y **INICIO** piden doble confirmación, y se bloquean por encima del límite de velocidad.
