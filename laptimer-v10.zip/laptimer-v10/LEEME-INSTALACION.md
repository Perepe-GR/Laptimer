# Actualizar de la 0.9 a la 0.10

La firma es la misma de siempre: la 0.10 se instala **encima** y se conservan circuitos, sesiones y ajustes.
Haz antes una copia en **INICIO > COPIA DE SEGURIDAD**.

## 1. App
1. En tu repositorio privado: **Add file > Upload files** y sube `laptimer-v10.zip` sin descomprimir. Commit.
2. **Actions**: espera al ✓ verde. Después **Releases > APK más reciente > laptimer.apk**, en tu Android.
3. Instálala encima de la 0.9. Si falla la compilación, copia el error del paso "Compilar APK" y pégalo en el chat.

## 2. Panel web
Descomprime `panel-pit-v10.zip`, sube el `index.html` al repositorio público `panel-pit` y espera 1 o 2 minutos
(si no cambia, añade `?v=10` a la dirección). Las reglas de Firebase no cambian.
Después, en el panel: **ajustes > Limpiar sala** (con la app apagada borra todo lo que quede).

## 3. Cosas que cambian y conviene revisar
- **Nombre del car**: si nunca lo cambiaste, el nombre por defecto pasa de "Coche 1" a "Car 1". Ponlo en
  **AJUSTES Y PIT CREW** y limpia la sala una vez.
- **Drivers (endurance)**: escribe la lista en **CONFIGURAR ENDURANCE**; en **EDITAR ESTRATEGIA POR STINT** elige el driver de
  cada stint. Un stint sin driver obliga al PIT a enviarlo desde el panel (**Pedir cambio de driver**).
  En el demo, para probar el cambio, define el driver de cada stint en la estrategia.
- **Sprint**: **MODO DE RACE > Sprint**, escribe laps totales y/o duración y **GUARDAR SPRINT**.
- **OUT LAP / IN LAP**: **AJUSTES DE SESIÓN**. Solo funcionan con carril de PIT (PIT IN y PIT OUT) en el circuito.
- **PADDOCK**: **CIRCUITOS > editar en el mapa > + PADDOCK**: toca los vértices (mínimo 3), **LISTO**, **GUARDAR**.
  Pulsación larga en la pantalla amarilla la cierra a mano (no vuelve a salir hasta que salgas de la zona).

## 4. Probar en casa con el demo
1. **MODO DE RACE > Sprint** con 5 laps (o 3 min) y **MODO DEMO**: el contador "LAP n / 5" avanza, sale **FINAL LAP** en la
   última lap y al terminar aparece **RACE FINISHED**; el resumen queda en **RACE SUMMARIES** y en el panel.
2. **Endurance** con estrategia de 2 o 3 laps por stint, driver definido en cada stint y mínimo de PIT de 40 s.
3. Con ×2 o ×4 la cuenta atrás y los cronómetros van a la misma velocidad que el car.
