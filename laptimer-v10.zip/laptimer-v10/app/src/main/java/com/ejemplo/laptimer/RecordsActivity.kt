package com.ejemplo.laptimer

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Récords por circuito (del coche o de un piloto) y evolución de la mejor vuelta por sesión. */
class RecordsActivity : AppCompatActivity() {

    private var sessions: List<SessionRecord> = emptyList()
    private var circuits: List<String> = emptyList()
    private var drivers: List<String> = emptyList()
    private lateinit var spCircuit: Spinner
    private lateinit var spScope: Spinner
    private lateinit var txtInfo: TextView
    private lateinit var chart: LineChartView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessions = SessionStore(this).list()
        circuits = sessions.map { it.circuitName }.distinct().sorted()

        val pad = (14 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0B0D10.toInt())
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "Récords y evolución"
        title.textSize = 20f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        root.addView(title)

        if (circuits.isEmpty()) {
            val t = TextView(this)
            t.text = "Aún no hay sesiones guardadas. Los récords salen de las sesiones reales (no de la demo)."
            t.setTextColor(0xFF9AA3AE.toInt())
            t.setPadding(0, pad, 0, 0)
            root.addView(t)
            setContentView(root)
            return
        }

        spCircuit = Spinner(this)
        spCircuit.adapter = adapter(circuits)
        spScope = Spinner(this)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(spCircuit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(spScope, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row)

        txtInfo = TextView(this)
        txtInfo.setTextColor(Color.WHITE)
        txtInfo.textSize = 14f
        txtInfo.setPadding(0, pad / 2, 0, pad / 2)
        root.addView(txtInfo)

        val lbl = TextView(this)
        lbl.text = "BEST LAP POR SESIÓN (s): verde = cada sesión, blanca = mejor hasta entonces"
        lbl.textSize = 12f
        lbl.typeface = Typeface.DEFAULT_BOLD
        lbl.setTextColor(0xFF9AA3AE.toInt())
        root.addView(lbl)

        chart = LineChartView(this)
        root.addView(chart, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        spCircuit.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                loadScopes()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        spScope.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                refresh()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        loadScopes()
    }

    private fun adapter(items: List<String>): ArrayAdapter<String> {
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        return ad
    }

    private fun loadScopes() {
        val c = circuits[spCircuit.selectedItemPosition]
        drivers = sessions.filter { it.circuitName == c && it.driver.isNotEmpty() }
            .map { it.driver }.distinct().sorted()
        val labels = ArrayList<String>()
        labels.add("Car (todos los drivers)")
        for (d in drivers) labels.add("Driver: $d")
        spScope.adapter = adapter(labels)
        spScope.setSelection(0)
        refresh()
    }

    private fun refresh() {
        val c = circuits[spCircuit.selectedItemPosition]
        val idx = spScope.selectedItemPosition
        val driver: String? = if (idx > 0 && idx - 1 < drivers.size) drivers[idx - 1] else null
        val list = sessions.filter { it.circuitName == c && (driver == null || it.driver == driver) }
            .sortedBy { it.startEpochMs }
        if (list.isEmpty()) {
            txtInfo.text = "Sin sesiones para esta selección."
            chart.clear()
            return
        }
        val date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val nSectors = list.last().sectorCount
        var bestMs = Long.MAX_VALUE
        var bestSession: SessionRecord? = null
        val bestSectors = LongArray(nSectors) { Long.MAX_VALUE }
        var laps = 0
        for (s in list) {
            laps += s.laps.size
            for (l in s.laps) {
                if (l.lapMs < bestMs) {
                    bestMs = l.lapMs
                    bestSession = s
                }
                if (s.sectorCount == nSectors) {
                    for (i in l.splits.indices) {
                        if (i < nSectors && l.splits[i] < bestSectors[i]) bestSectors[i] = l.splits[i]
                    }
                }
            }
        }
        val sb = StringBuilder()
        sb.append("Sesiones: ").append(list.size).append(" · Laps: ").append(laps).append('\n')
        if (bestSession != null) {
            sb.append("BEST LAP: ").append(fmtMs(bestMs)).append("  (")
                .append(date.format(Date(bestSession.startEpochMs)))
                .append(driverTag(bestSession)).append(")\n")
        }
        if (bestSectors.all { it != Long.MAX_VALUE }) {
            sb.append("BEST sectors: ")
            for (i in 0 until nSectors) {
                sb.append("S").append(i + 1).append(' ')
                    .append(String.format(Locale.US, "%.2f", bestSectors[i] / 1000.0)).append("   ")
            }
            sb.append("\nÓptima: ").append(fmtMs(bestSectors.sum()))
        }
        txtInfo.text = sb.toString()

        val perSession = ArrayList<Double>()
        val soFar = ArrayList<Double>()
        var running = Double.MAX_VALUE
        for (s in list) {
            val b = s.bestLap() ?: continue
            val sec = b.lapMs / 1000.0
            if (sec < running) running = sec
            perSession.add(sec)
            soFar.add(running)
        }
        if (perSession.size < 2) {
            chart.clear()
            txtInfo.text = txtInfo.text.toString() + "\n(Hacen falta al menos 2 sesiones para la gráfica)"
            return
        }
        val xs = DoubleArray(perSession.size) { (it + 1).toDouble() }
        chart.setData(
            xs,
            listOf(perSession.toDoubleArray(), soFar.toDoubleArray()),
            intArrayOf(0xFFC6F432.toInt(), Color.WHITE),
            false,
            " ses."
        )
    }
}
