package com.ejemplo.laptimer

import android.os.Handler
import java.util.Random
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.sin

/**
 * Circuito demo: un óvalo tipo kartódromo de unos 714 m (dos rectas de 200 m y dos curvas de 50 m
 * de radio) con meta en la recta inferior y 3 sectores. Se recorre en sentido antihorario.
 */
object DemoCircuit {
    const val NAME = "Circuito Demo"
    private const val STRAIGHT = 200.0
    private const val R = 50.0
    private val ARC = Math.PI * R
    val LENGTH: Double = 2 * STRAIGHT + 2 * ARC
    val frame = LocalFrame(41.0, 1.0)

    private fun wrap(s: Double): Double = ((s % LENGTH) + LENGTH) % LENGTH
    private fun norm(a: Double): Double = ((a % 360.0) + 360.0) % 360.0

    /** Posición (x, y en metros) y rumbo (grados) en la distancia s a lo largo del circuito. */
    fun pose(sIn: Double): DoubleArray {
        val s = wrap(sIn)
        return when {
            s < STRAIGHT -> doubleArrayOf(s, 0.0, 90.0)
            s < STRAIGHT + ARC -> {
                val phi = -Math.PI / 2 + (s - STRAIGHT) / R
                doubleArrayOf(STRAIGHT + R * cos(phi), R + R * sin(phi), norm(-Math.toDegrees(phi)))
            }
            s < 2 * STRAIGHT + ARC -> {
                val d = s - STRAIGHT - ARC
                doubleArrayOf(STRAIGHT - d, 2 * R, 270.0)
            }
            else -> {
                val phi = Math.PI / 2 + (s - 2 * STRAIGHT - ARC) / R
                doubleArrayOf(R * cos(phi), R + R * sin(phi), norm(-Math.toDegrees(phi)))
            }
        }
    }

    /** Velocidad de un piloto virtual: lento en curva, rápido en recta, con rampas. */
    fun speedMs(sIn: Double): Double {
        val s = wrap(sIn)
        val edge = when {
            s < STRAIGHT -> min(s, STRAIGHT - s)
            s in (STRAIGHT + ARC)..(2 * STRAIGHT + ARC) -> {
                val d = s - STRAIGHT - ARC
                min(d, STRAIGHT - d)
            }
            else -> 0.0
        }
        return 12.5 + 12.5 * min(1.0, edge / 60.0)
    }

    val circuit: Circuit by lazy {
        fun gp(s: Double): GatePoint {
            val p = pose(s)
            return GatePoint(frame.lat(p[1]), frame.lon(p[0]), p[2])
        }
        // Carril de boxes de prueba: entra en la última curva y sale antes de la meta
        Circuit(NAME, gp(100.0), listOf(gp(LENGTH / 3), gp(2 * LENGTH / 3)), gp(640.0), gp(60.0))
    }
}

/**
 * Piloto virtual: genera posiciones a 25 Hz sobre el circuito demo, con ritmo distinto en cada
 * vuelta (±1-2 %) y algo de ruido de GPS. Permite acelerar la simulación (x1, x2, x4).
 */
class DemoSource(
    private val handler: Handler,
    private val sink: (NmeaEvent.Position, Boolean) -> Unit
) {
    @Volatile
    var factor = 1
    private var running = false
    private var sTotal = -30.0
    private var lapIdx = -1
    private var pace = 1.0
    private var clockMs = 12 * 3_600_000L
    private val rnd = Random(7)

    // Paradas en boxes: el piloto virtual entra, frena hasta el box, espera y sale (todo en tiempo simulado)
    @Volatile private var pitReq = false
    @Volatile private var pitPhase = 0 // 0 normal, 1 hacia el box, 2 parado, 3 saliendo
    private var stopSimMs = 10_000L
    private var stoppedMs = 0L
    private var pitBoxS = 0.0
    private var pitV = 0.0
    private var rampV = 99.0

    /** Hay una parada pedida o en curso. */
    val pitBusy: Boolean get() = pitReq || pitPhase != 0

    /** Está dentro del carril de boxes (entrando, parado o saliendo). */
    val inPitLane: Boolean get() = pitPhase != 0

    /** Pide una parada en la próxima vuelta; stopMs es el tiempo que estará parado, en tiempo simulado. */
    fun requestPit(stopMs: Long) {
        stopSimMs = stopMs
        pitReq = true
    }

    private companion object {
        const val PIT_V = 8.0 // velocidad en el carril de boxes (m/s, unos 29 km/h)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val f = factor
            for (i in 0 until f) step(i == f - 1)
            handler.postDelayed(this, 40)
        }
    }

    fun start() {
        running = true
        handler.post(tick)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tick)
    }

    private fun step(render: Boolean) {
        val idx = floor(sTotal / DemoCircuit.LENGTH).toInt()
        if (idx != lapIdx) {
            lapIdx = idx
            pace = 1.0 + (rnd.nextGaussian() * 0.012).coerceIn(-0.03, 0.03)
        }
        val lapBase = floor(sTotal / DemoCircuit.LENGTH) * DemoCircuit.LENGTH
        val local = sTotal - lapBase
        var v = DemoCircuit.speedMs(sTotal) * pace
        when (pitPhase) {
            0 -> {
                if (pitReq && local >= 600.0 && local < 690.0) {
                    pitPhase = 1
                    pitBoxS = lapBase + 695.0
                    pitV = v
                } else if (rampV < 90.0) {
                    rampV += 3.0 * 0.04
                    if (rampV >= v) rampV = 99.0 else v = rampV
                }
            }
            1 -> {
                val d = pitBoxS - sTotal
                val vStop = sqrt(2.0 * 3.0 * max(d, 0.0))
                val target = min(PIT_V, vStop)
                pitV = if (pitV > target) max(target, pitV - 4.0 * 0.04) else min(target, pitV + 2.0 * 0.04)
                v = pitV
                if (d <= 0.3) {
                    v = 0.0
                    pitV = 0.0
                    stoppedMs = 0L
                    pitPhase = 2
                }
            }
            2 -> {
                v = 0.0
                stoppedMs += 40L
                if (stoppedMs >= stopSimMs) {
                    pitV = 0.0
                    pitPhase = 3
                }
            }
            else -> {
                pitV = min(PIT_V, pitV + 2.5 * 0.04)
                v = pitV
                if (sTotal >= pitBoxS + (DemoCircuit.LENGTH - 695.0) + 80.0) {
                    pitPhase = 0
                    pitReq = false
                    rampV = pitV
                }
            }
        }
        sTotal += v * 0.04
        clockMs += 40
        val p = DemoCircuit.pose(sTotal)
        val x = p[0] + rnd.nextGaussian() * 0.4
        val y = p[1] + rnd.nextGaussian() * 0.4
        val course = (((p[2] + rnd.nextGaussian()) % 360.0) + 360.0) % 360.0
        val ev = NmeaEvent.Position(
            lat = DemoCircuit.frame.lat(y),
            lon = DemoCircuit.frame.lon(x),
            speedKmh = v * 3.6 + rnd.nextGaussian() * 0.3,
            courseDeg = course,
            timeMs = clockMs
        )
        sink(ev, render)
    }
}
