package com.ejemplo.laptimer

import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import java.net.URLEncoder
import java.util.Locale

private fun mmssOf(ms: Long): String {
    val t = ms / 1000
    return String.format(Locale.US, "%d:%02d", t / 60, t % 60)
}

/** Modo de carrera: track day, sprint o resistencia. */
class ModePageActivity : PageActivity() {
    override val pageTitle: String = "Modo de race"

    override fun build() {
        val settings = NetSettings(this)
        val modes = listOf(
            Triple("trackday", "Track day", "Modo libre: sin límite de laps ni de tiempo. En PIT, pantalla amarilla sin cuenta atrás."),
            Triple(
                "sprint", "Sprint",
                "Race con laps totales y/o duración: termina la primera que se cumpla. Aviso FINAL LAP y resumen al terminar."
            ),
            Triple(
                "resistencia", "Endurance",
                "Stint, estrategia, cambio de driver y cuenta atrás del tiempo mínimo en PIT. La duración total se define en la estrategia."
            )
        )
        for ((key, name, desc) in modes) {
            optionCard(name, desc, settings.raceMode == key) {
                settings.raceMode = key
                toast("Modo: $name")
                rebuild()
            }
        }
        val cs = card("Sprint")
        val etLaps = numField(cs, "Laps totales (0 = sin definir)", settings.sprintLaps.toString())
        val etMin = numField(cs, "Duración total (min; 0 = sin definir)", settings.sprintMin.toString())
        note(cs, "Si defines las dos, la race termina con la primera que se cumpla.")
        addFooter(
            button("CONFIGURAR ENDURANCE") {
                startActivity(Intent(this, EnduranceActivity::class.java))
            },
            button("GUARDAR SPRINT", true) {
                settings.sprintLaps = etLaps.text.toString().toIntOrNull() ?: 0
                settings.sprintMin = etMin.text.toString().toIntOrNull() ?: 0
                toast("Sprint guardado")
            }
        )
    }
}

/** Ajustes de sesión: bloqueo, delta, mensajes, batería, referencia y demo. */
class SessionSettingsActivity : PageActivity() {
    override val pageTitle: String = "Ajustes de sesión"

    override fun build() {
        val settings = NetSettings(this)

        val c1 = card("Pantalla y bloqueo")
        val etLock = numField(c1, "Bloqueo de INICIO y botones por encima de (km/h; 0 = sin bloqueo)", settings.lockKmh.toString())
        val etRange = numField(
            c1, "Rango de la barra del delta (% de la BEST LAP)",
            String.format(Locale.US, "%.1f", settings.rangePct), true
        )
        val etMsg = numField(c1, "Duración de los mensajes del pit (sectores)", settings.msgSectors.toString())
        val etSum = numField(c1, "Resumen al cruzar FINISH: segundos en pantalla (3 a 6)", settings.lapSummarySec.toString())

        val c2 = card("Batería")
        val etWarn = newNum(settings.batWarn.toString())
        val etCrit = newNum(settings.batCrit.toString())
        rowOf(c2, block("Aviso batería baja (%)", etWarn), block("Aviso batería crítica (%)", etCrit))

        val c3 = card("Delta de referencia y récords")
        val scope = choice(
            c3,
            listOf("coche" to "Del car (todos los drivers juntos)", "piloto" to "De cada driver por separado"),
            if (settings.refScope == "piloto") "piloto" else "coche"
        )

        val c3b = card("OUT LAP / IN LAP")
        val cbOut = check(c3b, "La OUT LAP (de PIT OUT a FINISH) cuenta como lap numerada", settings.outlapCounts)
        val cbIn = check(c3b, "La IN LAP (de FINISH a PIT IN) cuenta como lap numerada", settings.inlapCounts)
        note(
            c3b,
            "Los sectores se muestran siempre en la OUT LAP y en la IN LAP. Sea cual sea el ajuste, esas laps son parciales: " +
                "nunca entran en BEST, récords ni mejores sectores. Si no cuentan, solo se ven como OUT LAP / IN LAP."
        )

        val c4 = card("Modo demo")
        val etDemo = numField(c4, "Segundos parado en PIT (0 = alterna pit stop incumplido y cumplido)", settings.demoStopSec.toString())
        note(c4, "En demo el car virtual para solo cuando toca: por la estrategia o por una petición del panel.")

        addFooter(
            button("CANCELAR") { finish() },
            button("GUARDAR", true) {
                settings.lockKmh = etLock.text.toString().toIntOrNull() ?: 10
                settings.rangePct = etRange.text.toString().toFloatOrNull() ?: 2f
                settings.msgSectors = etMsg.text.toString().toIntOrNull() ?: 2
                settings.lapSummarySec = etSum.text.toString().toIntOrNull() ?: 4
                settings.batWarn = etWarn.text.toString().toIntOrNull() ?: 20
                settings.batCrit = etCrit.text.toString().toIntOrNull() ?: 10
                settings.refScope = scope()
                settings.outlapCounts = cbOut.isChecked
                settings.inlapCounts = cbIn.isChecked
                settings.demoStopSec = etDemo.text.toString().toIntOrNull() ?: 0
                toast("Ajustes guardados")
                finish()
            }
        )
    }
}

/** Ajustes y pit crew: conexión con Firebase, coche, piloto y panel. */
class PitSettingsActivity : PageActivity() {
    override val pageTitle: String = "Ajustes y pit crew"

    override fun build() {
        val settings = NetSettings(this)

        val c1 = card("Conexión con el pit")
        val swEnabled = check(c1, "Activar conexión con el pit", settings.enabled)
        val etDb = textField(
            c1, "URL de Firebase Realtime Database", settings.dbUrl,
            "https://tu-proyecto-default-rtdb.firebaseio.com",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        )
        val etRoom = textField(
            c1, "Código de sala (10 caracteres; el mismo en el panel del pit)", settings.ensureRoom(), "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        )
        addButton(c1, button("GENERAR CÓDIGO NUEVO") { etRoom.setText(NetSettings.newCode()) })
        val etInt = numField(c1, "Intervalo de envío en segundos (mínimo 10; más alto = menos batería)", settings.intervalS.toString())
        val etPanel = textField(
            c1, "URL del panel del pit (para compartir el enlace)", settings.panelUrl,
            "https://usuario.github.io/panel-pit/",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        )

        val c2 = card("Car y driver")
        val etCar = textField(c2, "Nombre del car (distinto en cada móvil de la sala)", settings.carName)
        val etDriver = textField(c2, "Driver actual", settings.driverName)

        val c3 = card("Datos")
        val swTrace = check(c3, "Guardar la traza GPS completa de las sesiones", settings.saveTrace)

        fun saveAll() {
            settings.enabled = swEnabled.isChecked
            settings.carName = etCar.text.toString()
            settings.driverName = etDriver.text.toString()
            settings.dbUrl = etDb.text.toString()
            settings.room = etRoom.text.toString()
            settings.intervalS = etInt.text.toString().toIntOrNull() ?: 10
            settings.panelUrl = etPanel.text.toString()
            settings.saveTrace = swTrace.isChecked
        }

        addFooter(
            button("CANCELAR") { finish() },
            button("COMPARTIR ENLACE") {
                saveAll()
                shareLink(settings)
            },
            button("GUARDAR", true) {
                saveAll()
                toast("Ajustes guardados")
                finish()
            }
        )
    }

    private fun shareLink(settings: NetSettings) {
        val panel = settings.panelUrl
        if (panel.isBlank() || settings.dbUrl.isBlank()) {
            toast("Falta la URL del panel o la de Firebase")
            return
        }
        val sep = if (panel.contains("?")) "&" else "?"
        val url = panel + sep + "db=" + URLEncoder.encode(settings.dbUrl, "UTF-8") + "&room=" + settings.room
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, url)
        startActivity(Intent.createChooser(i, "Compartir enlace del pit"))
    }
}

/** Configuración previa de la carrera de resistencia: pilotos, boxes, estrategia y paradas registradas. */
class EnduranceActivity : PageActivity() {
    override val pageTitle: String = "Endurance"

    override fun build() {
        val settings = NetSettings(this)

        val c0 = card("Ahora")
        val next = settings.plannedDriver(settings.stintNumber + 1)
        note(
            c0,
            "Conduce: " + settings.driverName + " · stint " + settings.stintNumber +
                (if (next != null) "\nSiguiente: $next" else "\nSiguiente: sin definir (lo pone el PIT desde el panel)")
        )

        val c1 = card("Drivers")
        val etRoster = textField(
            c1, "Lista de drivers, uno por línea. El orden no define el relevo: quién conduce cada stint se elige en la estrategia.",
            settings.roster().joinToString("\n"), "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        )
        etRoster.minLines = 3
        etRoster.gravity = Gravity.TOP or Gravity.START

        val c2 = card("PIT")
        val etPit = numField(
            c2, "Tiempo mínimo de pit stop en PIT (s; 0 = sin cuenta atrás). El PIT puede cambiarlo en cada pit stop.",
            settings.pitMinSec.toString()
        )

        val c3 = card("Estrategia por stint")
        val n = settings.strategy().size
        note(
            c3,
            if (n == 0) "Sin estrategia: todos los stints usan los valores por defecto de abajo."
            else "$n stints definidos. Los siguientes usan los valores por defecto."
        )
        addButton(c3, button("EDITAR ESTRATEGIA POR STINT") {
            startActivity(Intent(this, StrategyActivity::class.java))
        })

        val c4 = card("Valores por defecto (stints sin estrategia)")
        val etPlan = numField(c4, "Laps planificadas (0 = sin plan)", settings.defPlanLaps.toString())
        val etMin = newNum(settings.defMinMin.toString())
        val etMax = newNum(settings.defMaxMin.toString())
        rowOf(c4, block("Tiempo mínimo (min)", etMin), block("Tiempo máximo (min)", etMax))

        val c5 = card("Pit stops registrados")
        val log = settings.pitLog().takeLast(8).reversed()
        if (log.isEmpty()) {
            note(c5, "Todavía no hay pit stops.")
        } else {
            note(c5, "Total: ${settings.pitStops} · incumplidas: ${settings.pitFails}")
            for (line in log) {
                val f = line.split('|')
                if (f.size >= 4) {
                    val dur = f[1].toLongOrNull() ?: 0L
                    val min = f[2].toIntOrNull() ?: 0
                    val ok = f[3] == "1"
                    val minTxt = if (min > 0) " (mínimo ${mmssOf(min * 1000L)})" else ""
                    val t = note(c5, "Stint ${f[0]} · ${mmssOf(dur)}$minTxt · " + (if (ok) "cumplida" else "INCUMPLIDA"))
                    t.setTextColor(if (ok) colText else colRed)
                }
            }
        }

        val c6 = card("Empezar")
        val cbReset = check(
            c6, "Empezar de cero: stint 1 con el primer driver y sin pit stops registrados",
            settings.stintNumber == 1 && settings.stintLapsDone == 0
        )

        addFooter(
            button("CANCELAR") { finish() },
            button("GUARDAR", true) {
                settings.rosterText = etRoster.text.toString().lines().map { it.trim() }
                    .filter { it.isNotEmpty() }.joinToString("\n")
                settings.pitMinSec = etPit.text.toString().toIntOrNull() ?: 0
                settings.defPlanLaps = etPlan.text.toString().toIntOrNull() ?: 0
                settings.defMinMin = etMin.text.toString().toIntOrNull() ?: 0
                settings.defMaxMin = etMax.text.toString().toIntOrNull() ?: 0
                if (cbReset.isChecked) {
                    settings.resetStint()
                    val first = settings.strategy().firstOrNull()?.driver?.takeIf { it.isNotBlank() }
                        ?: settings.roster().firstOrNull()
                    if (first != null) settings.driverName = first
                }
                toast(
                    "Endurance guardada" +
                        (if (settings.isEndurance()) "" else " (actívala en MODO DE RACE)")
                )
                finish()
            }
        )
    }

    override fun onRestart() {
        super.onRestart()
        rebuild()
    }
}

/** Estrategia: un objetivo por stint (no tienen que ser iguales). */
class StrategyActivity : PageActivity() {
    override val pageTitle: String = "Estrategia por stint"

    private class Row(
        val driver: () -> String,
        val minMin: android.widget.EditText,
        val minLaps: android.widget.EditText,
        val maxMin: android.widget.EditText,
        val maxLaps: android.widget.EditText,
        val planLaps: android.widget.EditText,
        val planMin: android.widget.EditText,
        val pitSec: android.widget.EditText
    )

    private lateinit var settings: NetSettings
    private val rows = ArrayList<Row>()
    private var etRace: android.widget.EditText? = null
    private var pending: List<StintTarget>? = null
    private var pendingRace = -1

    override fun build() {
        settings = NetSettings(this)
        val list = pending ?: settings.strategy()
        val raceVal = if (pendingRace >= 0) pendingRace else settings.raceMin
        pending = null
        pendingRace = -1
        rows.clear()

        val c0 = card("Race")
        val er = numField(c0, "Duración total de la race (min; 0 = sin definir)", raceVal.toString())
        etRace = er
        val planLapsSum = list.sumOf { it.planLaps }
        val planMinSum = list.sumOf { it.planMin }
        note(
            c0,
            "${list.size} stints · planificado: $planLapsSum laps" +
                (if (planMinSum > 0) " y $planMinSum min por tiempo" else "")
        )
        note(
            c0,
            "Cada stint tiene mínimo y máximo (en tiempo y en laps) y un objetivo. En el stint, rojo si entrar a " +
                "PIT incumpliría los límites, verde dentro de ellos y lila si coincide con el objetivo."
        )

        for ((i, t) in list.withIndex()) {
            val c = card("Stint ${i + 1}")
            label(c, "Driver de este stint")
            val opts = ArrayList<Pair<String, String>>()
            opts.add("" to "Sin definir (lo pone el PIT desde el panel)")
            val names = settings.roster().toMutableList()
            if (t.driver.isNotBlank() && names.none { it.equals(t.driver, ignoreCase = true) }) names.add(t.driver)
            for (nm in names) opts.add(nm to nm)
            val selKey = names.firstOrNull { it.equals(t.driver, ignoreCase = true) } ?: ""
            val drv = choice(c, opts, selKey)
            val mm = newNum(t.minMin.toString())
            val ml = newNum(t.minLaps.toString())
            val xm = newNum(t.maxMin.toString())
            val xl = newNum(t.maxLaps.toString())
            rowOf(c, block("Mín. minutos", mm), block("Mín. laps", ml), block("Máx. minutos", xm), block("Máx. laps", xl))
            val pl = newNum(t.planLaps.toString())
            val pm = newNum(t.planMin.toString())
            val ps = newNum(t.pitSec.toString())
            rowOf(c, block("Objetivo laps", pl), block("Objetivo minutos", pm), block("Mín. PIT al cerrar (s)", ps))
            rows.add(Row(drv, mm, ml, xm, xl, pl, pm, ps))
            val idx = i
            addButton(c, button("BORRAR ESTE STINT") {
                val cur = collect().toMutableList()
                if (idx in cur.indices) cur.removeAt(idx)
                pending = cur
                pendingRace = raceNow()
                rebuild()
            })
        }

        addFooter(
            button("CANCELAR") { finish() },
            button("+ STINT") {
                val cur = collect().toMutableList()
                cur.add(if (cur.isNotEmpty()) cur.last().copy(driver = "") else StintTarget())
                pending = cur
                pendingRace = raceNow()
                rebuild()
            },
            button("GUARDAR", true) {
                settings.saveStrategy(collect())
                settings.raceMin = raceNow()
                toast("Estrategia guardada")
                finish()
            }
        )
    }

    private fun raceNow(): Int = etRace?.text?.toString()?.toIntOrNull() ?: 0

    private fun collect(): List<StintTarget> = rows.map { r ->
        fun n(e: android.widget.EditText) = e.text.toString().toIntOrNull() ?: 0
        StintTarget(
            r.driver().trim(),
            n(r.minMin), n(r.minLaps), n(r.maxMin), n(r.maxLaps), n(r.planLaps), n(r.planMin), n(r.pitSec)
        )
    }
}

/** Copia de seguridad: crear (con o sin trazas) y restaurar. */
class BackupActivity : PageActivity() {
    override val pageTitle: String = "Copia de seguridad"

    private val restoreLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) doRestore(uri)
        }

    override fun build() {
        val c0 = card()
        note(c0, "La copia incluye circuitos, marcas, sesiones y ajustes, también tu código de sala: guárdala en privado.")
        optionCard("Crear copia con trazas GPS", "Incluye todo; pesa más.", false) { makeBackup(true) }
        optionCard("Crear copia sin trazas GPS", "Más ligera: sin las posiciones de cada sesión.", false) { makeBackup(false) }
        optionCard("Restaurar una copia", "Elige un archivo de copia guardado.", false) {
            restoreLauncher.launch(arrayOf("*/*"))
        }
    }

    private fun makeBackup(traces: Boolean) {
        try {
            val f = Backup.create(this, traces)
            Export.shareFile(this, f, "application/zip")
        } catch (e: Exception) {
            toast("No se pudo crear la copia: ${e.message}")
        }
    }

    private fun doRestore(uri: Uri) {
        try {
            val n = Backup.restore(this, uri)
            toast("Copia restaurada: $n archivos")
        } catch (e: Exception) {
            toast("No se pudo restaurar: ${e.message}")
        }
    }
}

/** Circuitos: elegir, crear, editar, borrar, importar y exportar. */
class CircuitsActivity : PageActivity() {
    override val pageTitle: String = "Circuitos"

    private lateinit var store: CircuitStore
    private lateinit var statsStore: StatsStore

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importCircuit(uri)
        }

    override fun build() {
        store = CircuitStore(this)
        statsStore = StatsStore(this)
        val active = store.loadActive()

        val c0 = card("Circuito activo")
        note(c0, active?.name ?: "Ninguno")
        if (active != null) {
            val boxes = if (active.hasPitLane) " · con PIT" else ""
            note(c0, "${active.sectorCount} sectores$boxes").setTextColor(colMuted)
        }

        val list = store.list()
        val c1 = card("Mis circuitos")
        if (list.isEmpty()) {
            note(c1, "No hay circuitos guardados.")
        } else {
            for (c in list) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(0, dp(8), 0, 0)
                val isActive = c.name == active?.name
                val name = TextView(this)
                name.text = c.name + (if (c.hasPitLane) "  · PIT" else "")
                name.textSize = 16f
                name.setTextColor(if (isActive) colLime else colText)
                row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                if (!isActive) {
                    row.addView(button("ELEGIR") {
                        store.activeName = c.name
                        toast("Circuito activo: ${c.name}")
                        rebuild()
                    })
                }
                val del = button("BORRAR") { confirmDelete(c) }
                val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                dlp.marginStart = dp(8)
                row.addView(del, dlp)
                c1.addView(row)
            }
        }

        val c2 = card("Nuevo circuito")
        val etName = textField(c2, "Nombre", "", "Nombre del circuito")
        rowOf(
            c2,
            button("EN EL MAPA", true) { newCircuit(etName.text.toString().trim(), true) },
            button("POR RECONOCIMIENTO") { newCircuit(etName.text.toString().trim(), false) }
        )

        val c3 = card("Circuito activo: acciones")
        addButton(c3, button("EDITAR EN EL MAPA (ancho de líneas, PIT y PADDOCK)") { editOnMap() })
        addButton(c3, button("EXPORTAR") { exportCircuit() })
        addButton(c3, button("IMPORTAR UN CIRCUITO") { importLauncher.launch(arrayOf("*/*")) })
    }

    override fun onRestart() {
        super.onRestart()
        rebuild()
    }

    private fun newCircuit(name: String, onMap: Boolean) {
        if (name.isEmpty()) {
            toast("Escribe un nombre")
            return
        }
        if (onMap) {
            openMapEditor(name, true)
        } else {
            val i = Intent(this, MainActivity::class.java)
            i.putExtra("recon", name)
            startActivity(i)
        }
    }

    private fun openMapEditor(name: String, isNew: Boolean) {
        val i = Intent(this, MapEditorActivity::class.java)
        i.putExtra("name", name)
        i.putExtra("new", isNew)
        val pos = store.lastPosition()
        if (pos != null) {
            i.putExtra("lat", pos.first)
            i.putExtra("lon", pos.second)
        }
        startActivity(i)
    }

    private fun editOnMap() {
        val c = store.loadActive()
        if (c == null) {
            toast("No hay circuito activo")
            return
        }
        openMapEditor(c.name, false)
    }

    private fun confirmDelete(c: Circuit) {
        AlertDialog.Builder(this)
            .setTitle("Borrar «${c.name}»")
            .setMessage("También se borran sus marcas de referencia y récords. Las sesiones guardadas no se tocan.")
            .setPositiveButton("Borrar") { _, _ ->
                store.delete(c.name)
                statsStore.clear(c.name)
                if (store.activeName == c.name) store.activeName = null
                toast("Circuito borrado")
                rebuild()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun exportCircuit() {
        val c = store.loadActive()
        if (c == null) {
            toast("No hay circuito activo")
            return
        }
        Export.share(this, c.name + ".json", c.toJson(), "application/json")
    }

    private fun importCircuit(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalStateException("archivo vacío")
            val c = Circuit.fromJson(text)
            store.save(c)
            store.activeName = c.name
            toast("Circuito importado: ${c.name}")
            rebuild()
        } catch (e: Exception) {
            toast("No se pudo importar: ${e.message}")
        }
    }
}


/** Resúmenes de carrera guardados: tiempos por lap, driver y stint (sin sectores). */
class RacesActivity : PageActivity() {
    override val pageTitle: String = "Race summaries"

    private lateinit var races: RaceStore

    override fun build() {
        races = RaceStore(this)
        val list = races.list()
        if (list.isEmpty()) {
            val c = card()
            note(c, "Todavía no hay resúmenes. Se guardan solos al terminar una race o al cerrar la sesión.")
            return
        }
        val df = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        for (r in list) {
            val title = df.format(java.util.Date(r.startEpoch)) + " · " + r.circuit
            val c = card(title)
            val mode = when (r.mode) {
                "sprint" -> "SPRINT"
                "resistencia" -> "ENDURANCE"
                else -> "TRACK DAY"
            }
            val end = if (r.reason == "target") "terminada por objetivo" else "sesión cerrada"
            note(
                c,
                mode + " · LAPS " + r.counted() + " · BEST " + fmtMs(r.bestMs()) +
                    " · TIME " + mmssOf(r.durMs) + "\n" + end
            )
            val detail = note(c, lapLines(r))
            detail.visibility = android.view.View.GONE
            detail.typeface = android.graphics.Typeface.MONOSPACE
            addButton(c, button("VER / OCULTAR LAPS") {
                detail.visibility = if (detail.visibility == android.view.View.GONE) android.view.View.VISIBLE
                else android.view.View.GONE
            })
            addButton(c, button("BORRAR") {
                AlertDialog.Builder(this)
                    .setTitle("¿Borrar este resumen?")
                    .setNegativeButton("No", null)
                    .setPositiveButton("Borrar") { _, _ ->
                        races.delete(r.id)
                        rebuild()
                    }
                    .show()
            })
        }
    }

    private fun lapLines(r: RaceRecord): String {
        val sb = StringBuilder()
        val best = r.bestMs()
        for (l in r.laps) {
            val tag = when (l.kind) {
                1 -> "OUT"
                2 -> "IN "
                else -> if (l.n > 0) String.format(Locale.US, "%3d", l.n) else "   "
            }
            sb.append("LAP ").append(tag).append("  ").append(fmtMs(l.ms))
            if (l.kind == 0 && best != null && l.ms == best) sb.append("  BEST")
            if (l.driver.isNotBlank()) sb.append("  ").append(l.driver)
            if (l.stint > 0) sb.append(" S").append(l.stint)
            sb.append('\n')
        }
        return sb.toString().trimEnd()
    }
}
