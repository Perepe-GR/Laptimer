package com.ejemplo.laptimer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** Ajustes de red, de sesión y estado del stint, guardados en el móvil. */
class NetSettings(context: Context) {
    private val p = context.getSharedPreferences("laptimer_net", Context.MODE_PRIVATE)

    private fun putS(k: String, v: String) = p.edit().putString(k, v).apply()
    private fun putI(k: String, v: Int) = p.edit().putInt(k, v).apply()

    // ---- Red ----
    var enabled: Boolean
        get() = p.getBoolean("enabled", false)
        set(v) {
            p.edit().putBoolean("enabled", v).apply()
        }

    var dbUrl: String
        get() = p.getString("db", "") ?: ""
        set(v) = putS("db", v.trim().trimEnd('/'))

    var room: String
        get() = p.getString("room", "") ?: ""
        set(v) = putS("room", v.trim().uppercase())

    var intervalS: Int
        get() = p.getInt("interval", 10)
        set(v) = putI("interval", v.coerceAtLeast(10))

    var panelUrl: String
        get() = p.getString("panel", "") ?: ""
        set(v) = putS("panel", v.trim())

    var saveTrace: Boolean
        get() = p.getBoolean("trace", true)
        set(v) {
            p.edit().putBoolean("trace", v).apply()
        }

    // ---- Identidad ----
    var carName: String
        get() = p.getString("carName", "Car 1") ?: "Car 1"
        set(v) = putS("carName", v.trim().ifEmpty { "Car 1" })

    var driverName: String
        get() = p.getString("driver", "Driver 1") ?: "Driver 1"
        set(v) = putS("driver", v.trim().ifEmpty { "Driver 1" })

    fun carKey(): String = keyOf(carName)

    // ---- Ajustes de sesión ----
    var lockKmh: Int
        get() = p.getInt("lockKmh", 10)
        set(v) = putI("lockKmh", v.coerceAtLeast(0))

    var rangePct: Float
        get() = p.getFloat("rangePct", 2f)
        set(v) {
            p.edit().putFloat("rangePct", v.coerceIn(0.5f, 10f)).apply()
        }

    var msgSectors: Int
        get() = p.getInt("msgSectors", 2)
        set(v) = putI("msgSectors", v.coerceIn(1, 6))

    var batWarn: Int
        get() = p.getInt("batWarn", 20)
        set(v) = putI("batWarn", v.coerceIn(1, 90))

    var batCrit: Int
        get() = p.getInt("batCrit", 10)
        set(v) = putI("batCrit", v.coerceIn(1, 90))

    // ---- Modo de carrera ----
    /** "trackday", "sprint" o "resistencia". Track day y sprint son iguales por ahora. */
    var raceMode: String
        get() = p.getString("raceMode", "trackday") ?: "trackday"
        set(v) = putS("raceMode", v)

    fun isEndurance(): Boolean = raceMode == "resistencia"
    fun isSprint(): Boolean = raceMode == "sprint"
    fun isTrackDay(): Boolean = raceMode != "sprint" && raceMode != "resistencia"

    /** Sprint: vueltas totales (0 = sin definir) y duración (min, 0 = sin definir). Termina la primera que se cumpla. */
    var sprintLaps: Int
        get() = p.getInt("sprintLaps", 0)
        set(v) = putI("sprintLaps", v.coerceAtLeast(0))

    var sprintMin: Int
        get() = p.getInt("sprintMin", 0)
        set(v) = putI("sprintMin", v.coerceAtLeast(0))

    /** Si la OUT LAP / IN LAP cuentan como vuelta numerada (nunca entran en BEST ni en récords). */
    var outlapCounts: Boolean
        get() = p.getBoolean("outlapCounts", false)
        set(v) = p.edit().putBoolean("outlapCounts", v).apply()

    var inlapCounts: Boolean
        get() = p.getBoolean("inlapCounts", false)
        set(v) = p.edit().putBoolean("inlapCounts", v).apply()

    fun raceModeLabel(): String = when (raceMode) {
        "sprint" -> "Sprint"
        "resistencia" -> "Endurance"
        else -> "Track day"
    }

    /** Segundos que se ve el resumen al cruzar la meta (3 a 6). */
    var lapSummarySec: Int
        get() = p.getInt("lapSummarySec", 4)
        set(v) = putI("lapSummarySec", v.coerceIn(3, 6))

    // ---- Carrera de resistencia: pilotos y boxes ----
    /** Tiempo mínimo de parada en boxes (s). 0 = sin cuenta atrás. Solo se usa en resistencia. */
    var pitMinSec: Int
        get() = p.getInt("pitMinSec", 0)
        set(v) = putI("pitMinSec", v.coerceAtLeast(0))

    /** Lista de drivers de la carrera (uno por línea). El orden NO define el relevo: eso se elige en la estrategia. */
    var rosterText: String
        get() = p.getString("roster", "") ?: ""
        set(v) = putS("roster", v)

    fun roster(): List<String> = rosterText.split('\n').map { it.trim() }.filter { it.isNotEmpty() }


    var pitStops: Int
        get() = p.getInt("pitStops", 0)
        set(v) = putI("pitStops", v)

    var pitFails: Int
        get() = p.getInt("pitFails", 0)
        set(v) = putI("pitFails", v)

    /** Registro de paradas: "stint|duración ms|mínimo s|cumplida 1/0|hora". Se conservan las últimas 60. */
    fun pitLog(): List<String> =
        (p.getString("pitLog", "") ?: "").split('\n').filter { it.isNotBlank() }

    fun addPitLog(stintNo: Int, durMs: Long, minSec: Int, ok: Boolean) {
        val l = pitLog().toMutableList()
        l.add("$stintNo|$durMs|$minSec|${if (ok) 1 else 0}|${System.currentTimeMillis()}")
        putS("pitLog", l.takeLast(60).joinToString("\n"))
    }

    var pitLastMs: Long
        get() = p.getLong("pitLastMs", 0L)
        set(v) {
            p.edit().putLong("pitLastMs", v).apply()
        }

    /** "coche" = delta y récords de todo el coche; "piloto" = de cada piloto por separado. */
    var refScope: String
        get() = p.getString("refScope", "coche") ?: "coche"
        set(v) = putS("refScope", v)

    // Valores por defecto para stints nuevos (0 = sin límite o sin plan)
    var defPlanLaps: Int
        get() = p.getInt("defPlan", 0)
        set(v) = putI("defPlan", v.coerceAtLeast(0))

    var defMinMin: Int
        get() = p.getInt("defMin", 0)
        set(v) = putI("defMin", v.coerceAtLeast(0))

    var defMaxMin: Int
        get() = p.getInt("defMax", 0)
        set(v) = putI("defMax", v.coerceAtLeast(0))

    // ---- Estado del stint en curso (-1 = usar el valor por defecto) ----
    var stintNumber: Int
        get() = p.getInt("stintNumber", 1)
        set(v) = putI("stintNumber", v)

    var stintLapsDone: Int
        get() = p.getInt("stintLaps", 0)
        set(v) = putI("stintLaps", v)

    var stintStartEpoch: Long
        get() = p.getLong("stintStart", 0L)
        set(v) {
            p.edit().putLong("stintStart", v).apply()
        }

    var stintPlan: Int
        get() = p.getInt("stintPlan", -1)
        set(v) = putI("stintPlan", v)

    var stintMin: Int
        get() = p.getInt("stintMin", -1)
        set(v) = putI("stintMin", v)

    var stintMax: Int
        get() = p.getInt("stintMax", -1)
        set(v) = putI("stintMax", v)

    var stintMinLaps: Int
        get() = p.getInt("stintMinLaps", -1)
        set(v) = putI("stintMinLaps", v)

    var stintMaxLaps: Int
        get() = p.getInt("stintMaxLaps", -1)
        set(v) = putI("stintMaxLaps", v)

    var stintPlanMin: Int
        get() = p.getInt("stintPlanMin", -1)
        set(v) = putI("stintPlanMin", v)

    // ---- Estrategia de resistencia: un objetivo por stint ----
    /** Duración total de la carrera (min); 0 = sin definir. */
    var raceMin: Int
        get() = p.getInt("raceMin", 0)
        set(v) = putI("raceMin", v.coerceAtLeast(0))

    /** Segundos parado en boxes en el modo demo (0 = alterna parada incumplida y cumplida). */
    var demoStopSec: Int
        get() = p.getInt("demoStopSec", 0)
        set(v) = putI("demoStopSec", v.coerceAtLeast(0))

    var strategyJson: String
        get() = p.getString("strategy", "[]") ?: "[]"
        set(v) = putS("strategy", v)

    fun strategy(): List<StintTarget> {
        return try {
            val arr = JSONArray(strategyJson)
            (0 until arr.length()).map { StintTarget.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveStrategy(list: List<StintTarget>) {
        val arr = JSONArray()
        for (t in list) arr.put(t.toJson())
        strategyJson = arr.toString()
    }

    /** Objetivo del stint n (empieza en 1): el de la estrategia o, si no hay, los valores por defecto. */
    fun targetFor(n: Int): StintTarget {
        val list = strategy()
        if (n >= 1 && n <= list.size) return list[n - 1]
        return StintTarget(minMin = defMinMin, maxMin = defMaxMin, planLaps = defPlanLaps)
    }

    /** Driver que conduce el stint n según la estrategia, o null si no está definido (lo pone el pit desde el panel). */
    fun plannedDriver(n: Int): String? {
        val list = strategy()
        if (n >= 1 && n <= list.size && list[n - 1].driver.isNotBlank()) return list[n - 1].driver
        return null
    }

    fun resetStint() {
        stintNumber = 1
        stintLapsDone = 0
        stintStartEpoch = 0L
        stintPlan = -1
        stintMin = -1
        stintMax = -1
        stintMinLaps = -1
        stintMaxLaps = -1
        stintPlanMin = -1
        pitStops = 0
        pitFails = 0
        pitLastMs = 0L
        putS("pitLog", "")
    }

    fun ensureRoom(): String {
        var r = room
        if (r.isBlank()) {
            r = newCode()
            room = r
        }
        return r
    }

    companion object {
        fun newCode(): String {
            val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            val rnd = SecureRandom()
            val sb = StringBuilder()
            for (i in 0 until 10) sb.append(alphabet[rnd.nextInt(alphabet.length)])
            return sb.toString()
        }

        /** Clave segura para rutas de Firebase y nombres de archivo. */
        fun keyOf(s: String): String {
            val k = s.trim().lowercase().replace(Regex("[^a-z0-9_-]"), "-").trim('-')
            return if (k.isEmpty()) "x" else k
        }
    }
}

class PitMessage(val key: String, val text: String, val bg: String)

/** Petición de cambio de piloto enviada desde el panel del pit. */
class SwapRequest(
    val id: String,
    val next: String,
    val laps: Int,
    val minMin: Int,
    val maxMin: Int,
    /** Tiempo mínimo de boxes de esta parada (s); 0 = el de la configuración de la carrera. */
    val pitSec: Int = 0,
    /** El pit ha confirmado el cambio desde el panel (solo vale si el coche está en boxes). */
    val confirmed: Boolean = false
)

enum class NetStatus { OFF, OK, ERROR }

/**
 * Conexión con Firebase Realtime Database por su API REST (sin SDK, solo la URL de la base de datos).
 *
 * Estructura en la sala: live/<coche>, laps/<coche>, inbox/<coche> (mensajes) y cmd/<coche> (órdenes).
 * Para ahorrar batería hace un único intercambio cada `intervalS` segundos (mínimo 10):
 *  - sube la telemetría y las vueltas terminadas,
 *  - baja los mensajes nuevos y la orden de cambio de piloto, si la hay.
 * No usa conexión permanente.
 */
private const val INBOX_KEEP = 20

/**
 * Objetivo de un stint de la estrategia (0 = sin definir). Hay un mínimo y un máximo en tiempo y en vueltas,
 * y un objetivo planificado en vueltas o en tiempo; pitSec es el mínimo de boxes de la parada que cierra el stint.
 */
data class StintTarget(
    val driver: String = "",
    val minMin: Int = 0,
    val minLaps: Int = 0,
    val maxMin: Int = 0,
    val maxLaps: Int = 0,
    val planLaps: Int = 0,
    val planMin: Int = 0,
    val pitSec: Int = 0
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("driver", driver)
        o.put("minMin", minMin)
        o.put("minLaps", minLaps)
        o.put("maxMin", maxMin)
        o.put("maxLaps", maxLaps)
        o.put("planLaps", planLaps)
        o.put("planMin", planMin)
        o.put("pitSec", pitSec)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject) = StintTarget(
            o.optString("driver", ""),
            o.optInt("minMin", 0), o.optInt("minLaps", 0),
            o.optInt("maxMin", 0), o.optInt("maxLaps", 0),
            o.optInt("planLaps", 0), o.optInt("planMin", 0),
            o.optInt("pitSec", 0)
        )
    }
}

class FirebaseRestLink(
    private val settings: NetSettings,
    private val telemetry: () -> String?,
    private val onMessages: (List<PitMessage>) -> Unit,
    private val onCommand: (SwapRequest?) -> Unit,
    private val onStatus: (NetStatus) -> Unit
) {
    private var exec: ScheduledExecutorService? = null
    private val pendingLaps = ConcurrentLinkedQueue<String>()
    private var lastKey: String? = null
    private var lastCmdId: String? = null
    private var first = true
    private var purged = false

    fun enqueueLap(json: String) {
        pendingLaps.add(json)
        while (pendingLaps.size > 300) pendingLaps.poll()
    }

    fun start() {
        stop()
        if (!settings.enabled || settings.dbUrl.isBlank() || settings.room.isBlank()) {
            onStatus(NetStatus.OFF)
            return
        }
        first = true
        purged = false
        lastKey = null
        lastCmdId = null
        val e = Executors.newSingleThreadScheduledExecutor()
        exec = e
        val period = settings.intervalS.toLong().coerceAtLeast(10L)
        e.scheduleWithFixedDelay({ cycle() }, 0L, period, TimeUnit.SECONDS)
    }

    fun stop() {
        exec?.shutdownNow()
        exec = null
    }

    /** Sube el resumen de una carrera terminada a races/<coche>/<id>. Inmediato, en su propio hilo. */
    fun uploadRaceNow(id: String, json: String) {
        if (!settings.enabled || settings.dbUrl.isBlank() || settings.room.isBlank()) return
        val car = settings.carKey()
        Thread {
            try {
                request("PUT", "races/$car/$id", json, "")
            } catch (e: Exception) {
                // el resumen queda guardado en la app
            }
        }.start()
    }

    /** Borra la orden de cambio en Firebase tras confirmarla en el PIT. */
    fun clearCommandNow() {
        val car = settings.carKey()
        Thread {
            try {
                request("PUT", "cmd/$car", "null", "")
            } catch (e: Exception) {
                // se reintentará en el siguiente intercambio si la orden sigue ahí
            }
        }.start()
    }

    private fun cycle() {
        try {
            val car = settings.carKey()
            val t = telemetry()
            if (t != null) request("PUT", "live/$car", t, "")
            while (true) {
                val lap = pendingLaps.peek() ?: break
                // Clave fija por vuelta: si la respuesta se pierde y se reenvía, se sobrescribe y no se duplica
                val key = "L" + JSONObject(lap).optLong("t", System.currentTimeMillis())
                request("PUT", "laps/$car/$key", lap, "")
                pendingLaps.poll()
            }
            fetchMessages(car)
            fetchCommand(car)
            if (first.not() && !purged) purgeInbox(car)
            onStatus(NetStatus.OK)
        } catch (e: Exception) {
            onStatus(NetStatus.ERROR)
        }
    }

    private fun fetchMessages(car: String) {
        val txt = request("GET", "inbox/$car", null, "?orderBy=%22%24key%22&limitToLast=5").trim()
        val keys: List<String>
        var o: JSONObject? = null
        if (txt.isEmpty() || txt == "null") {
            keys = emptyList()
        } else {
            val obj = JSONObject(txt)
            o = obj
            val list = ArrayList<String>()
            val it = obj.keys()
            while (it.hasNext()) list.add(it.next())
            list.sort()
            keys = list
        }
        if (first) {
            lastKey = keys.lastOrNull()
            first = false
            return
        }
        val seen = lastKey
        val fresh = keys.filter { seen == null || it > seen }
        if (fresh.isEmpty() || o == null) return
        lastKey = fresh.last()
        val msgs = ArrayList<PitMessage>()
        for (k in fresh) {
            val m = o.getJSONObject(k)
            val text = m.optString("text", "")
            val bg = m.optString("bg", "amarillo")
            if (text.isNotBlank()) msgs.add(PitMessage(k, text, bg))
        }
        if (msgs.isNotEmpty()) onMessages(msgs)
    }

    /**
     * Limpieza automática: conserva solo los últimos mensajes del buzón de este coche y borra los
     * antiguos, para que no se acumulen ni consuman cuota. Se hace una vez al conectar.
     */
    private fun purgeInbox(car: String) {
        purged = true
        val txt = request("GET", "inbox/$car", null, "?shallow=true").trim()
        if (txt.isEmpty() || txt == "null") return
        val obj = JSONObject(txt)
        val keys = ArrayList<String>()
        val it = obj.keys()
        while (it.hasNext()) keys.add(it.next())
        if (keys.size <= INBOX_KEEP) return
        keys.sort()
        // Se borran de uno en uno (como máximo 60 por conexión) con PUT null
        val old = keys.subList(0, keys.size - INBOX_KEEP).take(60)
        for (k in old) request("PUT", "inbox/$car/$k", "null", "")
    }

    private fun fetchCommand(car: String) {
        val txt = request("GET", "cmd/$car", null, "").trim()
        if (txt.isEmpty() || txt == "null") {
            if (lastCmdId != null) {
                lastCmdId = null
                onCommand(null)
            }
            return
        }
        val o = JSONObject(txt)
        val id = o.optString("id", "")
        val conf = o.optBoolean("conf", false)
        val key = if (conf) "$id!" else id
        if (key != lastCmdId) {
            lastCmdId = key
            onCommand(
                SwapRequest(
                    id, o.optString("next", ""), o.optInt("laps", 0),
                    o.optInt("min", 0), o.optInt("max", 0), o.optInt("pit", 0), conf
                )
            )
        }
    }

    private fun request(method: String, path: String, body: String?, query: String): String {
        val url = URL(settings.dbUrl + "/rooms/" + settings.room + "/" + path + ".json" + query)
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 6000
            c.readTimeout = 6000
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code")
            return text
        } finally {
            c.disconnect()
        }
    }
}
