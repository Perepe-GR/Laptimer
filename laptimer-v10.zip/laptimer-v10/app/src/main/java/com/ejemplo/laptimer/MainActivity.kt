package com.ejemplo.laptimer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Spannable
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.TextViewCompat
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Pantalla de sesión (se abre desde el menú de inicio).
 * Dos vistas (completa y simplificada), barra superior y banda inferior ocultas hasta que hacen falta,
 * stint con piloto y avisos visuales. Salir exige doble confirmación.
 */
class MainActivity : AppCompatActivity(), SerialInputOutputManager.Listener {

    companion object {
        /** Si la app se reabre en menos de este tiempo, la carrera a medias continúa. */
        const val RACE_RESUME_MS = 30 * 60_000L
        private const val ACTION_USB_PERMISSION = "com.ejemplo.laptimer.USB_PERMISSION"
        private const val BAUD_RATE = 115200
        private const val DELTA_UI_MS = 200L          // el delta se refresca a 5 Hz
        private const val MSG_MAX_MS = 600_000L       // tope de seguridad de un mensaje: 10 minutos
        private const val TOPBAR_MS = 5_000L          // la barra superior se oculta sola a los 5 s
        private const val AUTOLOAD_M = 3000.0         // radio de carga automática de circuito
        private const val SIGNAL_TIMEOUT_MS = 3_000L  // sin datos de antena o de GPS durante este tiempo = aviso
        private const val STINT_WARN_MIN = 5          // aviso ámbar cuando faltan estos minutos para el máximo
        private const val PIT_BLINK_MS = 450L         // parpadeo de la pantalla de boxes
        private const val PIT_MAX_MS = 900_000L       // seguridad: la pantalla de boxes se cierra sola a los 15 min
        private const val PIT_FAIL_NOTICE_MS = 15_000L // aviso de parada incumplida tras salir de boxes
        private val PIT_YELLOW_A = Color.parseColor("#FFE23A")
        private val PIT_YELLOW_B = Color.parseColor("#CA8A04")
        private val PIT_GREEN_A = Color.parseColor("#4ADE80")
        private val PIT_GREEN_B = Color.parseColor("#16A34A")
        private val COL_STINT_PURPLE = Color.parseColor("#A855F7")
        private const val DEMO_LANE_TRAVEL_MS = 19_000L // lo que tarda el coche virtual en recorrer el carril sin parar
        private const val APP_VERSION = "0.9"
        private val COL_GREEN = Color.parseColor("#C6F432")
        private val COL_RED = Color.parseColor("#FF5A5F")
        private val COL_ALERT_RED = Color.parseColor("#EF4444")
        private val COL_AMBER = Color.parseColor("#F5A524")
        private val COL_PURPLE = Color.parseColor("#A855F7")
        private val COL_YELLOW = Color.parseColor("#FACC15")
        private val COL_NEUTRAL = Color.parseColor("#1E242B")
        private val COL_MUTED = Color.parseColor("#9AA3AE")
        private val COL_DARK = Color.parseColor("#0B0D10")
    }

    // ---- Carrera en curso (resumen que se guarda al terminar) ----
    private lateinit var raceStore: RaceStore
    private var race: RaceRecord? = null
    private var raceStartClock = 0L
    private var raceEnded = false
    private var raceTimeUp = false
    private var raceLapsDone = 0

    private class ActiveMsg(val text: String, val bg: String, var remaining: Int, val at: Long)

    private class StintState(
        var number: Int,
        var driver: String,
        var lapsDone: Int,
        var startEpoch: Long,
        var plan: Int,
        var minMin: Int,
        var maxMin: Int,
        var minLaps: Int = 0,
        var maxLaps: Int = 0,
        var planMin: Int = 0,
        /** Vueltas hechas cuando se alcanzó por primera vez el tiempo planificado (0 = aún no). */
        var planHitLaps: Int = 0
    )

    private enum class StintHealth { NONE, RED, GREEN, PURPLE }

    private lateinit var topBar: View
    private lateinit var txtTop: TextView
    private lateinit var btnHome: Button
    private lateinit var txtLapLabel: TextView
    private lateinit var progLaps: android.widget.ProgressBar
    private lateinit var txtNet: TextView
    private lateinit var txtGps: TextView
    private lateinit var alertStrip: TextView
    private lateinit var viewMain: View
    private lateinit var viewSimple: View
    private lateinit var viewMap: View
    private lateinit var trackMap: TrackMapView
    private lateinit var txtDelta3: TextView
    private lateinit var txtLap3: TextView
    private lateinit var txtInfo3: TextView
    private lateinit var txtStint3: TextView
    private lateinit var chipsRow3: LinearLayout
    private lateinit var txtDelta: TextView
    private lateinit var deltaBar: DeltaBarView
    private lateinit var txtRangeNeg: TextView
    private lateinit var txtRangePos: TextView
    private lateinit var txtRangeLabel: TextView
    private lateinit var txtLap: TextView
    private lateinit var chipsRow: LinearLayout
    private lateinit var txtBest: TextView
    private lateinit var txtLast: TextView
    private lateinit var txtOpt: TextView
    private lateinit var txtStint: TextView
    private lateinit var txtSpeed: TextView
    private lateinit var txtSpeedCorner: TextView
    private lateinit var stintBar: View
    private lateinit var txtDelta2: TextView
    private lateinit var deltaBar2: DeltaBarView
    private lateinit var chipsRow2: LinearLayout
    private lateinit var bottomBar: View
    private lateinit var bannerPit: TextView
    private lateinit var reconBar: View
    private lateinit var swapBar: View
    private lateinit var txtSwap: TextView
    private lateinit var btnSwapConfirm: Button
    private lateinit var btnMarkFinish: Button
    private lateinit var btnMarkSector: Button
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button
    private lateinit var lapOverlay: View
    private lateinit var txtSumTitle: TextView
    private lateinit var txtSumTime: TextView
    private lateinit var txtSumDelta: TextView
    private lateinit var chipsRowSum: LinearLayout
    private lateinit var txtSumStint: TextView
    private lateinit var pitOverlay: View
    private lateinit var txtPitTitle: TextView
    private lateinit var txtPitCount: TextView
    private lateinit var txtPitSub: TextView
    private lateinit var pitSwapBox: View
    private lateinit var txtPitSwap: TextView
    private lateinit var btnPitSwapConfirm: Button

    private val usbManager by lazy { getSystemService(Context.USB_SERVICE) as UsbManager }
    private val parser = NmeaParser()
    private val lineBuffer = StringBuilder()
    private val ioExecutor: ExecutorService = Executors.newCachedThreadPool()
    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null

    private lateinit var store: CircuitStore
    private lateinit var statsStore: StatsStore
    private lateinit var sessionStore: SessionStore
    private lateinit var settings: NetSettings
    @Volatile private var recorder: SessionRecorder? = null
    @Volatile private var link: FirebaseRestLink? = null

    @Volatile private var circuit: Circuit? = null
    @Volatile private var engine: LapEngine? = null
    @Volatile private var lastState: EngineState? = null
    @Volatile private var stint = StintState(1, "Driver 1", 0, 0L, 0, 0, 0)

    // Última posición conocida (hilo USB -> UI)
    @Volatile private var hasFix = false
    @Volatile private var lastLat = 0.0
    @Volatile private var lastLon = 0.0
    @Volatile private var lastKmh = 0.0
    @Volatile private var lastCourse: Double? = null
    @Volatile private var lastDataAt = 0L
    @Volatile private var lastFixAt = 0L
    @Volatile private var currentAlert: String? = null
    private var hz = 0.0
    private var lastRawMs: Long? = null
    private var sats = 0
    private var autoLoadDone = false

    // Modo demo
    @Volatile private var demoActive = false
    private var demo: DemoSource? = null
    private var demoFactor = 1

    // Reconocimiento de circuito (borrador)
    private var reconName: String? = null
    private var draftFinish: GatePoint? = null
    private val draftSectors = mutableListOf<GatePoint>()

    private var netStatus = NetStatus.OFF

    // Delta filtrado a 5 Hz: se muestra la media de cada ventana de 200 ms
    private var deltaSum = 0.0
    private var deltaCount = 0
    private var deltaShownAt = 0L

    // Vistas y gestos
    private var viewIndex = 0   // 0 = completa, 1 = simplificada, 2 = mapa
    private var downX = 0f
    private var downY = 0f
    private var tracking = false
    private val hideTop = Runnable { topBar.visibility = View.GONE }

    // Mensajes del pit y petición de cambio de piloto
    private val activeMsgs = ArrayList<ActiveMsg>()
    private val prune = Runnable { pruneMsgs() }
    @Volatile private var pendingSwap: SwapRequest? = null

    // Reloj de la sesión: en demo sigue el reloj simulado (así respeta ×2 y ×4); en real, el del móvil
    @Volatile private var simNowMs = 0L
    private fun clockNow(): Long = if (demoActive) simNowMs else System.currentTimeMillis()

    // Demo: control automático de las paradas en boxes
    private var demoLapsSincePit = 0
    private var demoStops = 0
    private var lastFinalShown = false

    // Carril de boxes (solo se toca desde el hilo principal)
    private var inPit = false

    /** El coche está dentro de la zona PADDOCK del circuito (pantalla amarilla "PADDOCK"). */
    private var inPaddock = false
    private var paddockDismissed = false
    private var pitStartAt = 0L
    private var pitBlinkOn = false
    private var pitSecOverride = 0   // tiempo mínimo de esta parada fijado por el pit, que sigue valiendo tras confirmar el cambio
    private var pitFailUntil = 0L
    private var pitFailText = ""
    private val pitBlink = object : Runnable {
        override fun run() {
            if (!inPit && !inPaddock) return
            pitBlinkOn = !pitBlinkOn
            updatePitOverlay()
            pitOverlay.postDelayed(this, PIT_BLINK_MS)
        }
    }
    private val hideLapSummary = Runnable { lapOverlay.visibility = View.GONE }

    // Reloj de 1 s: franja de stint y avisos
    private val tickHandler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateStintStrip()
            updateAlerts()
            if (inPit && clockNow() - pitStartAt > PIT_MAX_MS) exitPit()
            ensureProgrammedSwap()
            maybeRequestDemoPit()
            checkRaceTime()
            updateLapHeader()
            val fin = (isFinalLap() || isRaceFinalLap()) && !inPit
            if (fin != lastFinalShown) {
                lastFinalShown = fin
                renderBottom()
            }
            tickHandler.postDelayed(this, 1000L)
        }
    }

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                openPort()
            } else {
                toast("Permiso USB denegado")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        bindViews()
        store = CircuitStore(this)
        statsStore = StatsStore(this)
        sessionStore = SessionStore(this)
        raceStore = RaceStore(this)
        settings = NetSettings(this)
        recorder = SessionRecorder(sessionStore) { settings.saveTrace }
        stint = loadStint()
        resumeRace()

        circuit = store.loadActive()
        engine = circuit?.let { buildEngine(it, true) }

        link = FirebaseRestLink(
            settings,
            { buildTelemetry() },
            { msgs -> runOnUiThread { showPitMessages(msgs) } },
            { req -> runOnUiThread { onPanelCommand(req) } },
            { st -> runOnUiThread { netStatus = st; renderNet() } }
        )

        btnHome.setOnClickListener { askExit() }
        btnMarkFinish.setOnClickListener { markFinish() }
        btnMarkSector.setOnClickListener { markSector() }
        btnSave.setOnClickListener { saveCircuit() }
        btnCancel.setOnClickListener { exitRecon() }
        btnSwapConfirm.setOnClickListener { confirmSwap() }
        btnPitSwapConfirm.setOnClickListener { confirmSwap() }
        lapOverlay.setOnClickListener { hideLapSummaryNow() }
        // Salida de emergencia si la pantalla de boxes se quedara puesta: pulsación larga
        pitOverlay.setOnLongClickListener {
            if (inPit) exitPit()
            if (inPaddock) {
                // Cerrada a mano: no vuelve a salir hasta que el coche salga de la zona PADDOCK
                paddockDismissed = true
                inPaddock = false
                pitOverlay.removeCallbacks(pitBlink)
                pitOverlay.visibility = View.GONE
            }
            toast("Pantalla de PIT cerrada")
            true
        }
        txtTop.setOnClickListener { if (demoActive) cycleDemoSpeed() }

        // Salir con el botón "atrás" exige doble confirmación
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                askExit()
            }
        })

        ContextCompat.registerReceiver(
            this,
            permissionReceiver,
            IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        resetDisplay()
        refreshTop()
        renderNet()
        renderBottom()

        val recon = intent.getStringExtra("recon")
        if (recon != null) startRecon(recon)
        if (intent.getBooleanExtra("demo", false)) startDemo()

        showTopBar() // se ve 5 s al entrar para consultar el estado y luego se oculta
    }

    private fun bindViews() {
        topBar = findViewById(R.id.topBar)
        txtTop = findViewById(R.id.txtTop)
        btnHome = findViewById(R.id.btnHome)
        txtLapLabel = findViewById(R.id.txtLapLabel)
        progLaps = findViewById(R.id.progLaps)
        txtNet = findViewById(R.id.txtNet)
        txtGps = findViewById(R.id.txtGps)
        alertStrip = findViewById(R.id.alertStrip)
        viewMain = findViewById(R.id.viewMain)
        viewSimple = findViewById(R.id.viewSimple)
        viewMap = findViewById(R.id.viewMap)
        trackMap = findViewById(R.id.trackMap)
        txtDelta3 = findViewById(R.id.txtDelta3)
        txtLap3 = findViewById(R.id.txtLap3)
        txtInfo3 = findViewById(R.id.txtInfo3)
        txtStint3 = findViewById(R.id.txtStint3)
        chipsRow3 = findViewById(R.id.chipsRow3)
        txtDelta = findViewById(R.id.txtDelta)
        deltaBar = findViewById(R.id.deltaBar)
        txtRangeNeg = findViewById(R.id.txtRangeNeg)
        txtRangePos = findViewById(R.id.txtRangePos)
        txtRangeLabel = findViewById(R.id.txtRangeLabel)
        txtLap = findViewById(R.id.txtLap)
        chipsRow = findViewById(R.id.chipsRow)
        txtBest = findViewById(R.id.txtBest)
        txtLast = findViewById(R.id.txtLast)
        txtOpt = findViewById(R.id.txtOpt)
        txtStint = findViewById(R.id.txtStint)
        txtSpeed = findViewById(R.id.txtSpeed)
        txtSpeedCorner = findViewById(R.id.txtSpeedCorner)
        stintBar = findViewById(R.id.stintBar)
        txtDelta2 = findViewById(R.id.txtDelta2)
        deltaBar2 = findViewById(R.id.deltaBar2)
        chipsRow2 = findViewById(R.id.chipsRow2)
        bottomBar = findViewById(R.id.bottomBar)
        bannerPit = findViewById(R.id.bannerPit)
        reconBar = findViewById(R.id.reconBar)
        swapBar = findViewById(R.id.swapBar)
        txtSwap = findViewById(R.id.txtSwap)
        btnSwapConfirm = findViewById(R.id.btnSwapConfirm)
        btnMarkFinish = findViewById(R.id.btnMarkFinish)
        btnMarkSector = findViewById(R.id.btnMarkSector)
        btnSave = findViewById(R.id.btnSave)
        btnCancel = findViewById(R.id.btnCancel)
        lapOverlay = findViewById(R.id.lapOverlay)
        txtSumTitle = findViewById(R.id.txtSumTitle)
        txtSumTime = findViewById(R.id.txtSumTime)
        txtSumDelta = findViewById(R.id.txtSumDelta)
        chipsRowSum = findViewById(R.id.chipsRowSum)
        txtSumStint = findViewById(R.id.txtSumStint)
        pitOverlay = findViewById(R.id.pitOverlay)
        txtPitTitle = findViewById(R.id.txtPitTitle)
        txtPitCount = findViewById(R.id.txtPitCount)
        txtPitSub = findViewById(R.id.txtPitSub)
        pitSwapBox = findViewById(R.id.pitSwapBox)
        txtPitSwap = findViewById(R.id.txtPitSwap)
        btnPitSwapConfirm = findViewById(R.id.btnPitSwapConfirm)
    }

    override fun onResume() {
        super.onResume()
        if (!demoActive) {
            stint = loadStint()
            syncActiveCircuit()
        }
        engine?.outlapCounts = settings.outlapCounts
        engine?.inlapCounts = settings.inlapCounts
        connect()
        link?.start()
        renderNet()
        tickHandler.post(tick)
    }

    override fun onPause() {
        tickHandler.removeCallbacks(tick)
        link?.stop()
        if (demoActive) stopDemo()
        if (hasFix && !demoActive) store.saveLastPosition(lastLat, lastLon)
        disconnect()
        super.onPause()
    }

    override fun onDestroy() {
        if (isFinishing) endRace("closed")
        demo?.stop()
        recorder?.end()
        unregisterReceiver(permissionReceiver)
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    // ---------- Salir con doble confirmación ----------

    private fun askExit() {
        if (!checkUnlocked()) return
        AlertDialog.Builder(this)
            .setTitle("¿Cerrar la sesión?")
            .setMessage("Se dejará de cronometrar.")
            .setNegativeButton("Seguir", null)
            .setPositiveButton("Cerrar") { _, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Confirma otra vez")
                    .setMessage("¿Seguro que quieres cerrar la sesión?")
                    .setNegativeButton("No, seguir", null)
                    .setPositiveButton("SÍ, CERRAR") { _, _ -> finish() }
                    .show()
            }
            .show()
    }

    // ---------- Gestos ----------

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
                tracking = true
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL -> tracking = false
            MotionEvent.ACTION_UP -> {
                if (tracking) {
                    tracking = false
                    handleSwipe(downX, downY, ev.rawX, ev.rawY)
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun handleSwipe(x0: Float, y0: Float, x1: Float, y1: Float) {
        val dm = resources.displayMetrics
        val dx = x1 - x0
        val dy = y1 - y0
        val min = 70f * dm.density
        val w = dm.widthPixels
        val h = dm.heightPixels
        val vertical = abs(dy) > abs(dx) * 1.5f
        val horizontal = abs(dx) > abs(dy) * 1.5f
        if (vertical && dy > min && y0 < h * 0.35f) {
            showTopBar()
        } else if (vertical && dy < -min && topBar.visibility == View.VISIBLE) {
            hideTopBarNow()
        } else if (horizontal && abs(dx) > min * 1.4f && x0 > w * 0.25f && x0 < w * 0.75f) {
            toggleView(dx < 0)
        }
    }

    private fun showTopBar() {
        topBar.visibility = View.VISIBLE
        topBar.removeCallbacks(hideTop)
        topBar.postDelayed(hideTop, TOPBAR_MS)
    }

    private fun hideTopBarNow() {
        topBar.removeCallbacks(hideTop)
        topBar.visibility = View.GONE
    }

    /** Desliza a la izquierda: siguiente vista; a la derecha: anterior (completa, simplificada, mapa). */
    private fun toggleView(next: Boolean) {
        viewIndex = (viewIndex + (if (next) 1 else 2)) % 3
        viewMain.visibility = if (viewIndex == 0) View.VISIBLE else View.GONE
        viewSimple.visibility = if (viewIndex == 1) View.VISIBLE else View.GONE
        viewMap.visibility = if (viewIndex == 2) View.VISIBLE else View.GONE
    }

    // ---------- Stint ----------

    private fun loadStint(): StintState {
        val n = settings.stintNumber
        val t = settings.targetFor(n)
        fun pick(v: Int, d: Int) = if (v >= 0) v else d
        return StintState(
            n,
            settings.driverName,
            settings.stintLapsDone,
            settings.stintStartEpoch,
            pick(settings.stintPlan, t.planLaps),
            pick(settings.stintMin, t.minMin),
            pick(settings.stintMax, t.maxMin),
            pick(settings.stintMinLaps, t.minLaps),
            pick(settings.stintMaxLaps, t.maxLaps),
            pick(settings.stintPlanMin, t.planMin)
        )
    }

    /** En modo demo el stint es temporal y no toca el estado guardado. */
    private fun saveStint() {
        if (demoActive) return
        val s = stint
        settings.stintNumber = s.number
        settings.stintLapsDone = s.lapsDone
        settings.stintStartEpoch = s.startEpoch
        settings.stintPlan = s.plan
        settings.stintMin = s.minMin
        settings.stintMax = s.maxMin
        settings.stintMinLaps = s.minLaps
        settings.stintMaxLaps = s.maxLaps
        settings.stintPlanMin = s.planMin
        settings.driverName = s.driver
    }

    private fun stintElapsedMs(): Long {
        val s = stint
        return if (s.startEpoch > 0L) clockNow() - s.startEpoch else 0L
    }

    private fun mmss(ms: Long): String {
        val t = ms / 1000
        return String.format(Locale.US, "%d:%02d", t / 60, t % 60)
    }

    private fun updateStintStrip() {
        if (!settings.isEndurance()) {
            stintBar.visibility = View.GONE
            txtSpeedCorner.visibility = View.VISIBLE
            return
        }
        stintBar.visibility = View.VISIBLE
        txtSpeedCorner.visibility = View.GONE
        val s = stint
        val el = stintElapsedMs()
        val started = s.startEpoch > 0L
        val sb = StringBuilder()
        sb.append("STINT ").append(s.number).append(" · ").append(s.driver.uppercase(Locale.getDefault()))
            .append(" · ").append(mmss(el))
        if (s.maxMin > 0) sb.append('/').append(mmss(s.maxMin * 60_000L))
        sb.append(" · LAP ").append(s.lapsDone)
        if (s.plan > 0) sb.append('/').append(s.plan)
        txtStint.text = sb.toString()
        val color = when (stintHealth()) {
            StintHealth.RED -> COL_RED
            StintHealth.GREEN -> COL_GREEN
            StintHealth.PURPLE -> COL_STINT_PURPLE
            StintHealth.NONE -> COL_MUTED
        }
        txtStint.setTextColor(color)
    }

    /**
     * Estado del stint: rojo si ahora mismo entrar a boxes incumpliría los límites (antes del mínimo o pasado el
     * máximo, en tiempo o en vueltas), verde dentro de los límites, lila si coincide con el objetivo exacto.
     */
    private fun stintHealth(): StintHealth {
        val s = stint
        val el = stintElapsedMs()
        val hasLimits = s.minMin > 0 || s.minLaps > 0 || s.maxMin > 0 || s.maxLaps > 0
        val tooShort = (s.minMin > 0 && el < s.minMin * 60_000L) || (s.minLaps > 0 && s.lapsDone < s.minLaps)
        val tooLong = (s.maxMin > 0 && el > s.maxMin * 60_000L) || (s.maxLaps > 0 && s.lapsDone > s.maxLaps)
        val onTarget = (s.plan > 0 && s.lapsDone == s.plan) ||
            (s.planMin > 0 && s.planHitLaps > 0 && s.lapsDone == s.planHitLaps)
        return when {
            tooShort || tooLong -> StintHealth.RED
            onTarget -> StintHealth.PURPLE
            hasLimits -> StintHealth.GREEN
            else -> StintHealth.NONE
        }
    }

    /** Última vuelta planificada del stint: hay que entrar a boxes en esta vuelta. */
    private fun isFinalLap(): Boolean {
        if (!settings.isEndurance() || reconName != null) return false
        val s = stint
        if (s.plan > 0 && s.lapsDone == s.plan - 1) return true
        if (s.planMin > 0 && s.planHitLaps == 0 && s.startEpoch > 0L) {
            val ref = lastState?.lastLapMs ?: lastState?.bestLapMs ?: 0L
            if (ref > 0L && stintElapsedMs() + ref >= s.planMin * 60_000L) return true
        }
        return false
    }

    /** Cambio programado por la estrategia: se crea al empezar la última vuelta si el pit no ha pedido otro. */
    private fun ensureProgrammedSwap() {
        if (!settings.isEndurance() || pendingSwap != null) return
        val cur = stint
        val planDone = (cur.plan > 0 && cur.lapsDone >= cur.plan) || (cur.planMin > 0 && cur.planHitLaps > 0)
        if (!isFinalLap() && !planDone) return
        val n = cur.number + 1
        val next = settings.targetFor(n)
        pendingSwap = SwapRequest(
            "prog-" + cur.number, settings.plannedDriver(n) ?: "",
            next.planLaps, next.minMin, next.maxMin, settings.targetFor(cur.number).pitSec
        )
    }

    // ---------- Avisos visuales (sin sonido ni vibración) ----------

    private fun isCharging(): Boolean {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun batteryLevel(): Int {
        val b = batteryPct()
        return if (b in 1..100) b else 100
    }

    /** Devuelve (texto, esRojo) del aviso más importante, o null si no hay ninguno. */
    private fun computeAlert(): Pair<String, Boolean>? {
        val now = SystemClock.elapsedRealtime()
        if (!demoActive) {
            if (port == null || now - lastDataAt > SIGNAL_TIMEOUT_MS) return Pair("SIN ANTENA", true)
            if (now - lastFixAt > SIGNAL_TIMEOUT_MS) return Pair("SIN GPS", true)
        }
        val s = stint
        val el = stintElapsedMs()
        val started = s.startEpoch > 0L
        val endurance = settings.isEndurance()
        if (endurance && s.maxMin > 0 && started && el >= s.maxMin * 60_000L) {
            return Pair("STINT: LÍMITE DE TIEMPO SUPERADO", true)
        }
        if (endurance && s.maxLaps > 0 && s.lapsDone > s.maxLaps) {
            return Pair("STINT: LÍMITE DE LAPS SUPERADO", true)
        }
        if (now < pitFailUntil) return Pair(pitFailText, true)
        val bat = batteryLevel()
        val charging = isCharging()
        if (!charging && bat <= settings.batCrit) return Pair("BATERÍA CRÍTICA $bat %", true)
        if (endurance && s.maxMin > 0 && started && el >= (s.maxMin - STINT_WARN_MIN) * 60_000L) {
            val left = (s.maxMin * 60_000L - el + 59_999L) / 60_000L
            return Pair("STINT: QUEDAN $left MIN PARA EL MÁXIMO", false)
        }
        if (endurance && s.plan > 0 && s.lapsDone >= s.plan) {
            return Pair("STINT: LAPS PLANIFICADAS COMPLETADAS", false)
        }
        if (!charging && bat <= settings.batWarn) return Pair("BATERÍA BAJA $bat %", false)
        return null
    }

    private fun updateAlerts() {
        val a = computeAlert()
        currentAlert = a?.first
        if (a == null) {
            alertStrip.visibility = View.GONE
            return
        }
        alertStrip.text = a.first
        alertStrip.setBackgroundColor(if (a.second) COL_ALERT_RED else COL_AMBER)
        alertStrip.setTextColor(if (a.second) Color.WHITE else Color.parseColor("#141413"))
        alertStrip.visibility = View.VISIBLE
    }

    // ---------- Motor ----------

    /** Ámbito de las marcas: "" = todo el coche; "p_<piloto>" = el piloto actual. */
    private fun scopeKey(): String =
        if (settings.refScope == "piloto") "p_" + NetSettings.keyOf(stint.driver) else ""

    private fun buildEngine(c: Circuit, withHistory: Boolean): LapEngine {
        val initial = if (withHistory) statsStore.load(c, scopeKey()) else null
        val e = LapEngine(c, initial)
        e.onLap = { r -> handleLap(r) }
        e.onBoundary = { runOnUiThread { onBoundary() } }
        e.onPitIn = { runOnUiThread { enterPit() } }
        e.onPitOut = { runOnUiThread { exitPit() } }
        e.outlapCounts = settings.outlapCounts
        e.inlapCounts = settings.inlapCounts
        e.setInPit(inPit)
        return e
    }

    /** Se llama al cerrar cada vuelta válida (hilo USB, o principal en demo). */
    private fun handleLap(r: LapResult) {
        link?.enqueueLap(lapJson(r))
        val s = stint
        // La OUT LAP / IN LAP solo suman a las vueltas del stint si están configuradas como vuelta numerada
        if (r.number > 0) s.lapsDone++
        if (s.planMin > 0 && s.planHitLaps == 0 && stintElapsedMs() >= s.planMin * 60_000L) s.planHitLaps = s.lapsDone
        saveStint()
        runOnUiThread {
            showLapSummary(r)
            trackMap.onLapDone(r.kind, r.marks)
            onRaceLap(r)
        }
        if (demoActive) {
            if (r.number > 0) demoLapsSincePit++
            return
        }
        // Solo las vueltas normales entran en la sesión grabada, los récords y las estadísticas
        if (r.kind != 0) return
        recorder?.onLap(r)
        val c = circuit
        if (c != null) {
            statsStore.update(c, "", r)
            statsStore.update(c, "p_" + NetSettings.keyOf(s.driver), r)
        }
    }

    private fun syncActiveCircuit() {
        val active = store.loadActive()
        if (active != null && active != circuit) selectCircuit(active)
    }

    private fun selectCircuit(c: Circuit) {
        endRace("closed")
        raceEnded = false
        recorder?.end()
        resetPitUi()
        circuit = c
        engine = buildEngine(c, true)
        lastState = null
        store.activeName = c.name
        resetDisplay()
        refreshTop()
    }

    // ---------- Conexión USB ----------

    private fun findDriver(): UsbSerialDriver? =
        UsbSerialProber.getDefaultProber().findAllDrivers(usbManager).firstOrNull()

    private fun connect() {
        if (port != null) return
        val driver = findDriver()
        if (driver == null) {
            if (!demoActive) txtGps.text = "Conecta la antena por USB"
            return
        }
        if (!usbManager.hasPermission(driver.device)) {
            val pi = PendingIntent.getBroadcast(
                this,
                0,
                Intent(ACTION_USB_PERMISSION).setPackage(packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usbManager.requestPermission(driver.device, pi)
            txtGps.text = "Pidiendo permiso USB..."
            return
        }
        openPort()
    }

    private fun openPort() {
        val driver = findDriver()
        if (driver == null) {
            txtGps.text = "Antena no detectada"
            return
        }
        val connection = usbManager.openDevice(driver.device)
        if (connection == null) {
            txtGps.text = "No se pudo abrir el USB"
            return
        }
        val p = driver.ports[0]
        try {
            p.open(connection)
            p.setParameters(BAUD_RATE, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: Exception) {
            txtGps.text = "Error USB: ${e.message}"
            runCatching { p.close() }
            return
        }
        port = p
        ioManager = SerialInputOutputManager(p, this).also { ioExecutor.submit(it) }
        txtGps.text = "Esperando GPS..."
    }

    private fun disconnect() {
        ioManager?.stop()
        ioManager = null
        runCatching { port?.close() }
        port = null
    }

    // ---------- Datos del GPS (hilo de E/S) ----------

    override fun onNewData(data: ByteArray) {
        lastDataAt = SystemClock.elapsedRealtime()
        val text = String(data, Charsets.US_ASCII)
        synchronized(lineBuffer) {
            lineBuffer.append(text)
            var idx = lineBuffer.indexOf("\n")
            while (idx >= 0) {
                val line = lineBuffer.substring(0, idx).trim()
                lineBuffer.delete(0, idx + 1)
                if (line.isNotEmpty()) handleSentence(line)
                idx = lineBuffer.indexOf("\n")
            }
        }
    }

    override fun onRunError(e: Exception) {
        runOnUiThread {
            txtGps.text = "USB desconectado"
            disconnect()
        }
    }

    private fun handleSentence(line: String) {
        when (val ev = parser.parse(line)) {
            is NmeaEvent.Position -> if (!demoActive) onPosition(ev, true)
            is NmeaEvent.Fix -> runOnUiThread {
                sats = ev.sats
                renderGps()
            }
            null -> Unit
        }
    }

    private fun onPosition(ev: NmeaEvent.Position, render: Boolean) {
        lastLat = ev.lat
        lastLon = ev.lon
        lastKmh = ev.speedKmh
        hasFix = true
        if (!demoActive) lastFixAt = SystemClock.elapsedRealtime()
        val c = ev.courseDeg
        if (c != null && ev.speedKmh > 1.5) lastCourse = c

        if (demoActive) simNowMs = ev.timeMs

        // El stint empieza a contar al cruzar la salida del PIT (exitPit); fuera del PIT, cuando el coche se mueve
        val sNow = stint
        circuit?.let { if (it.hasPaddock && reconName == null) updatePaddock(it.inPaddock(ev.lat, ev.lon)) }
        if (race == null && !raceEnded && ev.speedKmh > 5.0) ensureRace()
        if (sNow.startEpoch == 0L && !inPit && !inPaddock && ev.speedKmh > 5.0) {
            sNow.startEpoch = clockNow()
            saveStint()
        }

        val prev = lastRawMs
        if (prev != null) {
            val d = ev.timeMs - prev
            if (d in 1L..1000L) {
                val inst = 1000.0 / d
                hz = if (hz == 0.0) inst else hz * 0.95 + inst * 0.05
            }
        }
        lastRawMs = ev.timeMs

        val st = engine?.onFix(ev.lat, ev.lon, ev.speedKmh, ev.timeMs)
        lastState = st

        if (!demoActive && st != null) {
            val circ = circuit
            val rec = recorder
            if (circ != null && rec != null &&
                rec.onSample(
                    circ, st.gpsTimeMs, ev.lat, ev.lon, ev.speedKmh,
                    stint.driver, stint.number, settings.carName
                )
            ) {
                engine?.resetSession()
            }
        }

        if (!render) return
        runOnUiThread {
            val kmhText = String.format(Locale.US, "%.0f", ev.speedKmh)
            txtSpeed.text = kmhText
            txtSpeedCorner.text = "$kmhText km/h"
            renderGps()
            if (st != null) renderEngine(st)
            updateLock()
            if (!demoActive && !autoLoadDone) {
                autoLoadDone = true
                autoLoad(ev.lat, ev.lon)
            }
        }
    }

    /** Carga el circuito guardado más cercano la primera vez que hay señal (no en mitad de una vuelta). */
    private fun autoLoad(lat: Double, lon: Double) {
        if (reconName != null) return
        if (lastState?.running == true) return
        val near = store.nearest(lat, lon, AUTOLOAD_M) ?: return
        if (near.name != circuit?.name) {
            selectCircuit(near)
            toast("Circuito cargado: ${near.name}")
        }
    }

    // ---------- Pantalla ----------

    private fun renderGps() {
        txtGps.text = when {
            demoActive -> String.format(Locale.US, "DEMO ×%d · GPS simulado %.0f Hz", demoFactor, hz)
            !hasFix -> "GPS sin señal"
            else -> String.format(Locale.US, "GPS %.0f Hz · %d sat", hz, sats)
        }
    }

    private fun renderNet() {
        when {
            !settings.enabled -> {
                txtNet.text = "PIT: desactivado"
                txtNet.setTextColor(COL_MUTED)
            }
            netStatus == NetStatus.OK -> {
                txtNet.text = "PIT: conectado"
                txtNet.setTextColor(COL_GREEN)
            }
            netStatus == NetStatus.ERROR -> {
                txtNet.text = "PIT: sin red"
                txtNet.setTextColor(COL_RED)
            }
            else -> {
                txtNet.text = "PIT: conectando…"
                txtNet.setTextColor(COL_MUTED)
            }
        }
    }

    private fun rangeFraction(): Double = settings.rangePct / 100.0

    private fun renderEngine(st: EngineState) {
        txtLap.text = fmtMs(st.currentLapMs)
        txtLap3.text = fmtMs(st.currentLapMs)
        circuit?.let {
            if (trackMap.circuit !== it) trackMap.setCircuit(it)
            trackMap.onPosition(lastLat, lastLon, (st.sector - 1).coerceAtLeast(0), st.running)
        }
        txtLast.text = fmtMs(st.lastLapMs)
        txtBest.text = fmtMs(st.bestLapMs)
        txtOpt.text = fmtMs(st.optimalMs)
        renderChips(chipsRow, st.marks, st.sectorCount, 12f)
        renderChips(chipsRow2, st.marks, st.sectorCount, 24f)
        renderChips(chipsRow3, st.marks, st.sectorCount, 20f)

        txtRangeLabel.text = String.format(Locale.US, "±%.1f %% BEST LAP", settings.rangePct)
        val best = st.bestLapMs
        val range = if (best != null) best * rangeFraction() / 1000.0 else null
        if (range != null) {
            txtRangeNeg.text = String.format(Locale.US, "-%.2f s", range)
            txtRangePos.text = String.format(Locale.US, "+%.2f s", range)
        } else {
            txtRangeNeg.text = String.format(Locale.US, "-%.1f %%", settings.rangePct)
            txtRangePos.text = String.format(Locale.US, "+%.1f %%", settings.rangePct)
        }

        // Delta a 5 Hz: acumula las muestras y muestra su media cada 200 ms
        val d = st.deltaSec
        if (d != null) {
            deltaSum += d
            deltaCount++
        }
        val now = SystemClock.elapsedRealtime()
        if (now - deltaShownAt >= DELTA_UI_MS) {
            deltaShownAt = now
            val avg = if (deltaCount > 0) deltaSum / deltaCount else null
            deltaSum = 0.0
            deltaCount = 0
            renderDelta(avg, range)
        }

        if (reconName == null) {
            val name = circuit?.name ?: ""
            val prefix = if (demoActive) "DEMO ×$demoFactor · " else ""
            txtTop.text = if (st.running) {
                "${prefix}LAP ${st.lapNumber} · S${st.sector}/${st.sectorCount} · $name"
            } else {
                "${prefix}$name · cruza FINISH para empezar"
            }
        }
    }

    private fun renderDelta(d: Double?, range: Double?) {
        if (d != null && range != null && range > 0.0) {
            val text = String.format(Locale.US, "%+.3f", d)
            val color = if (d <= 0.0) COL_GREEN else COL_RED
            val ratio = (d / range).toFloat()
            txtDelta.text = text
            txtDelta2.text = text
            txtDelta3.text = text
            txtDelta.setTextColor(color)
            txtDelta2.setTextColor(color)
            txtDelta3.setTextColor(color)
            deltaBar.setRatio(ratio)
            deltaBar2.setRatio(ratio)
        } else {
            txtDelta.text = "—.—"
            txtDelta2.text = "—.—"
            txtDelta3.text = "—.—"
            txtDelta.setTextColor(COL_GREEN)
            txtDelta2.setTextColor(COL_GREEN)
            txtDelta3.setTextColor(COL_GREEN)
            deltaBar.setRatio(0f)
            deltaBar2.setRatio(0f)
        }
    }

    private fun renderChips(row: LinearLayout, marks: List<SectorMark?>, count: Int, textSp: Float) {
        val have = (row.tag as? Int) ?: 0
        if (have != count) {
            row.removeAllViews()
            for (i in 0 until count) {
                val tv = AppCompatTextView(this)
                tv.typeface = Typeface.DEFAULT_BOLD
                tv.gravity = Gravity.CENTER
                tv.maxLines = 1
                TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                    tv, 8, textSp.toInt(), 1, TypedValue.COMPLEX_UNIT_SP
                )
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                if (i > 0) lp.marginStart = dp(6)
                row.addView(tv, lp)
            }
            row.tag = count
        }
        for (i in 0 until count) {
            val tv = row.getChildAt(i) as TextView
            val m = marks.getOrNull(i)
            val bg = GradientDrawable()
            bg.cornerRadius = dp(8).toFloat()
            if (m == null) {
                bg.setColor(COL_NEUTRAL)
                tv.setTextColor(COL_MUTED)
                tv.text = "S${i + 1} --"
            } else {
                val fill: Int
                val fg: Int
                when (m.kind) {
                    MarkKind.NEUTRAL -> { fill = COL_NEUTRAL; fg = Color.WHITE }
                    MarkKind.PURPLE -> { fill = COL_PURPLE; fg = Color.WHITE }
                    MarkKind.GREEN -> { fill = COL_GREEN; fg = COL_DARK }
                    MarkKind.YELLOW -> { fill = COL_YELLOW; fg = COL_DARK }
                }
                bg.setColor(fill)
                tv.setTextColor(fg)
                tv.text = "S${i + 1} " + String.format(Locale.US, "%.2f", m.ms / 1000.0)
            }
            tv.background = bg
        }
    }

    private fun resetDisplay() {
        txtLap.text = "--:--.---"
        txtLast.text = "--:--.---"
        txtBest.text = "--:--.---"
        txtOpt.text = "--:--.---"
        deltaSum = 0.0
        deltaCount = 0
        renderDelta(null, null)
        txtRangeLabel.text = String.format(Locale.US, "±%.1f %% BEST LAP", settings.rangePct)
        txtRangeNeg.text = String.format(Locale.US, "-%.1f %%", settings.rangePct)
        txtRangePos.text = String.format(Locale.US, "+%.1f %%", settings.rangePct)
        val n = circuit?.sectorCount ?: 3
        renderChips(chipsRow, emptyList(), n, 12f)
        renderChips(chipsRow2, emptyList(), n, 24f)
        renderChips(chipsRow3, emptyList(), n, 20f)
        txtLap3.text = "--:--.---"
        updateStintStrip()
    }

    private fun refreshTop() {
        val name = reconName
        txtTop.text = when {
            name != null -> "Reconocimiento «$name» · FINISH ${if (draftFinish != null) "✔" else "—"} · sectores ${draftSectors.size}"
            demoActive -> "DEMO ×$demoFactor · toca aquí para cambiar la velocidad"
            circuit == null -> "Sin circuito · vuelve a INICIO > CIRCUITOS"
            else -> "${circuit?.name} · cruza FINISH para empezar"
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Bloqueo en movimiento ----------

    private fun locked(): Boolean = !demoActive && settings.lockKmh > 0 && lastKmh > settings.lockKmh

    /** Confirmar un cambio de piloto exige ir parado, también en demo. */
    private fun swapLocked(): Boolean = settings.lockKmh > 0 && lastKmh > settings.lockKmh

    private fun updateLock() {
        btnHome.alpha = if (locked()) 0.4f else 1f
        val sa = if (swapLocked()) 0.4f else 1f
        btnSwapConfirm.alpha = sa
        btnPitSwapConfirm.alpha = sa
    }

    private fun checkUnlocked(): Boolean {
        if (locked()) {
            toast("Bloqueado: vas a más de ${settings.lockKmh} km/h")
            return false
        }
        return true
    }

    // ---------- Banda inferior: reconocimiento, cambio de piloto o mensaje del pit ----------

    private fun showPitMessages(list: List<PitMessage>) {
        if (list.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        for (m in list) activeMsgs.add(ActiveMsg(m.text, m.bg, settings.msgSectors, now))
        renderBottom()
    }

    /** Cada vez que se cruza un sector o la meta, los mensajes pierden un sector de vida. */
    private fun onBoundary() {
        if (activeMsgs.isEmpty()) return
        for (m in activeMsgs) m.remaining--
        activeMsgs.removeAll { it.remaining <= 0 }
        renderBottom()
    }

    private fun pruneMsgs() {
        val now = SystemClock.elapsedRealtime()
        activeMsgs.removeAll { now - it.at > MSG_MAX_MS }
        renderBottom()
    }

    /**
     * Prioridad: reconocimiento > petición de cambio del pit > final de stint > mensaje del pit.
     * El cambio programado por la estrategia solo sale aquí en circuitos sin carril de boxes y una vez pasada
     * la última vuelta; con carril de boxes se confirma en la pantalla de boxes.
     */
    private fun renderBottom() {
        bannerPit.removeCallbacks(prune)
        val raw = if (settings.isEndurance()) pendingSwap else null
        val prog = raw != null && raw.id.startsWith("prog-")
        val pitLane = circuit?.hasPitLane == true
        val raceFinal = isRaceFinalLap() && !inPit
        val finalLap = raceFinal || (isFinalLap() && !inPit)
        val m = activeMsgs.lastOrNull()
        val recon = reconName != null

        reconBar.visibility = if (recon) View.VISIBLE else View.GONE

        val realSwap = if (raw != null && !prog) raw else null
        val progBar = raw != null && prog && !pitLane && !finalLap
        val showSwap = !recon && (realSwap != null || progBar)
        val showFinal = !recon && finalLap && realSwap == null
        swapBar.visibility = if (showSwap) View.VISIBLE else View.GONE
        // Con carril de boxes definido el cambio se confirma en la pantalla de boxes; sin él, aquí
        btnSwapConfirm.visibility = if (pitLane) View.GONE else View.VISIBLE
        if (showSwap && raw != null) {
            val laps = if (raw.laps > 0) " · ${raw.laps} laps" else ""
            val tail = if (pitLane) " · CONFIRMA EN PIT" else ""
            val head = if (prog) "CAMBIO PROGRAMADO" else "PIT PIDE CAMBIO"
            txtSwap.text = if (raw.next.isBlank()) "NO DRIVER - ASK PIT"
            else "$head → ${raw.next.uppercase(Locale.getDefault())}$laps$tail"
            btnSwapConfirm.alpha = if (raw.next.isBlank()) 0.35f else 1f
        }

        val showMsg = !recon && !showSwap && !showFinal && m != null
        if (showFinal) {
            solid(COL_AMBER, COL_DARK, if (raceFinal) "FINAL LAP" else "FINAL STINT - BOX this lap")
            bannerPit.visibility = View.VISIBLE
        } else if (showMsg && m != null) {
            applyMsgStyle(m.bg, m.text)
            bannerPit.visibility = View.VISIBLE
            bannerPit.postDelayed(prune, 30_000L)
        } else {
            bannerPit.visibility = View.GONE
        }

        bottomBar.visibility = if (recon || showSwap || showFinal || showMsg) View.VISIBLE else View.GONE
    }

    private fun solid(fill: Int, fg: Int, text: String) {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = dp(14).toFloat()
        bannerPit.background = g
        bannerPit.setTextColor(fg)
        bannerPit.text = text
    }

    private fun applyMsgStyle(bg: String, text: String) {
        when (bg) {
            "verde" -> solid(Color.parseColor("#22C55E"), COL_DARK, text)
            "rojo" -> solid(Color.parseColor("#EF4444"), Color.WHITE, text)
            "azul" -> solid(Color.parseColor("#2563EB"), Color.WHITE, text)
            "blanco" -> solid(Color.parseColor("#F2F4F7"), Color.parseColor("#141413"), text)
            "rayas" -> {
                bannerPit.background = StripesDrawable(COL_YELLOW, Color.parseColor("#EF4444"), dp(14).toFloat())
                bannerPit.setTextColor(Color.WHITE)
                val sp = SpannableString(" $text ")
                sp.setSpan(
                    BackgroundColorSpan(Color.parseColor("#E6141413")),
                    0, sp.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                bannerPit.text = sp
            }
            else -> solid(COL_YELLOW, Color.parseColor("#141413"), text)
        }
    }

    /** Confirma en la app el cambio de piloto (pedido por el panel o programado): hay que ir parado. */
    private fun confirmSwap() {
        val req = pendingSwap ?: return
        if (req.next.isBlank()) {
            toast("Falta el driver: pídelo al PIT desde el panel")
            return
        }
        if (swapLocked()) {
            toast("Bloqueado: vas a más de ${settings.lockKmh} km/h")
            return
        }
        applySwap(req)
    }

    /** Cierra el stint y abre el siguiente con los objetivos de la estrategia (el pit puede cambiar algunos). */
    private fun applySwap(req: SwapRequest) {
        recorder?.end()
        val n = stint.number + 1
        val t = settings.targetFor(n)
        val plan = if (req.laps > 0) req.laps else t.planLaps
        val mn = if (req.minMin > 0) req.minMin else t.minMin
        val mx = if (req.maxMin > 0) req.maxMin else t.maxMin
        stint = StintState(n, req.next.ifEmpty { "Driver" }, 0, 0L, plan, mn, mx, t.minLaps, t.maxLaps, t.planMin)
        saveStint()
        val c = circuit
        if (!demoActive && c != null && settings.refScope == "piloto") {
            engine = buildEngine(c, true)
            lastState = null
            resetDisplay()
        } else {
            engine?.resetSession()
        }
        if (inPit && req.pitSec > 0) pitSecOverride = req.pitSec
        pendingSwap = null
        if (!req.id.startsWith("prog-")) link?.clearCommandNow()
        lastFinalShown = false
        renderBottom()
        updateStintStrip()
        updatePitOverlay()
        toast("Cambio hecho: conduce ${stint.driver}")
    }

    /** Orden del panel: el cambio puede venir ya confirmado, y entonces solo vale con el coche en boxes. */
    private fun onPanelCommand(req: SwapRequest?) {
        pendingSwap = req
        if (req != null && req.confirmed && inPit && settings.isEndurance()) {
            applySwap(req)
            return
        }
        renderBottom()
        updatePitOverlay()
    }

    // ---------- Carrera: resumen, final por objetivo y cierre ----------

    private fun raceTargetLaps(): Int = if (settings.isSprint()) settings.sprintLaps else 0

    private fun raceTargetMin(): Int = when {
        settings.isSprint() -> settings.sprintMin
        settings.isEndurance() -> settings.raceMin
        else -> 0
    }

    /** Continúa la carrera si la app se cerró hace poco (fallo o reinicio); si no, archiva la que quedó a medias. */
    private fun resumeRace() {
        val cur = raceStore.loadCurrent() ?: return
        val now = System.currentTimeMillis()
        if (cur.laps.isNotEmpty() && now - cur.endEpoch < RACE_RESUME_MS) {
            race = cur
            raceStartClock = clockNow() - (now - cur.startEpoch)
            raceLapsDone = cur.laps.maxOfOrNull { it.n } ?: 0
        } else if (cur.laps.isNotEmpty()) {
            cur.reason = "closed"
            raceStore.archive(cur)
            link?.uploadRaceNow(cur.id, cur.toJson().toString())
        } else {
            raceStore.clearCurrent()
        }
    }

    private fun ensureRace() {
        if (race != null || raceEnded || reconName != null) return
        val c = circuit ?: return
        val now = System.currentTimeMillis()
        race = RaceRecord(
            SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(now)),
            settings.raceMode, if (demoActive) "DEMO" else c.name, settings.carName, now,
            targetLaps = raceTargetLaps(), targetMin = raceTargetMin()
        )
        raceStartClock = clockNow()
        raceTimeUp = false
        raceLapsDone = 0
    }

    private fun onRaceLap(r: LapResult) {
        if (raceEnded) return
        ensureRace()
        val rc = race ?: return
        rc.laps.add(RaceLap(r.number, r.lapMs, r.kind, stint.driver, stint.number))
        rc.endEpoch = System.currentTimeMillis()
        raceStore.saveCurrent(rc)
        if (r.number > raceLapsDone) raceLapsDone = r.number
        updateLapHeader()
        // Termina con la primera vuelta que cierre tras cumplirse el objetivo (vueltas o tiempo, lo que llegue antes)
        val byLaps = rc.targetLaps > 0 && raceLapsDone >= rc.targetLaps
        if (byLaps || raceTimeUp) endRace("target")
    }

    /**
     * Cabecera de la tarjeta del tiempo: "LAP n" y, en sprint con vueltas definidas, "LAP n/total" con una barra.
     * En sprint solo por tiempo la barra avanza con el tiempo. Track day y endurance muestran solo "LAP n"
     * (no hay total de laps de carrera; las laps del stint están en la franja de stint).
     */
    private fun updateLapHeader() {
        val rc = race
        val n = if (rc != null) raceLapsDone + 1 else (lastState?.lapNumber ?: 1)
        val totalLaps = if (settings.isSprint()) settings.sprintLaps else 0
        val totalMin = if (settings.isSprint()) settings.sprintMin else 0
        val sb = StringBuilder("LAP ").append(n)
        if (totalLaps > 0) sb.append(" / ").append(totalLaps)
        txtLapLabel.text = sb.toString()
        var frac = -1.0
        if (totalLaps > 0) frac = (n - 1).toDouble() / totalLaps
        if (totalMin > 0 && rc != null) {
            val f = (clockNow() - raceStartClock).toDouble() / (totalMin * 60_000.0)
            frac = if (frac < 0) f else maxOf(frac, f)
        }
        val best = lastState?.bestLapMs
        txtInfo3.text = sb.toString() + (if (best != null) "  ·  BEST " + fmtMs(best) else "")
        txtStint3.text = txtStint.text
        txtStint3.setTextColor(txtStint.currentTextColor)
        txtStint3.visibility = if (settings.isEndurance()) View.VISIBLE else View.GONE
        if (frac < 0) {
            progLaps.visibility = View.GONE
        } else {
            progLaps.visibility = View.VISIBLE
            progLaps.progress = (frac.coerceIn(0.0, 1.0) * 1000).toInt()
        }
    }

    /** Marca que el tiempo de la carrera se ha cumplido: la carrera acaba al cerrar la vuelta en curso. */
    private fun checkRaceTime() {
        val rc = race ?: return
        if (raceEnded || raceTimeUp || rc.targetMin <= 0) return
        if (clockNow() - raceStartClock >= rc.targetMin * 60_000L) {
            raceTimeUp = true
            renderBottom()
        }
    }

    /** Última vuelta de la carrera: por vueltas (la anterior a la meta) o porque el tiempo ya se cumplió. */
    private fun isRaceFinalLap(): Boolean {
        val rc = race ?: return false
        if (raceEnded || reconName != null) return false
        if (raceTimeUp) return true
        return rc.targetLaps > 0 && raceLapsDone == rc.targetLaps - 1
    }

    /** Cierra y guarda la carrera en curso (reason: "target" o "closed") y la sube a Firebase. */
    private fun endRace(reason: String) {
        val rc = race
        race = null
        raceTimeUp = false
        raceLapsDone = 0
        if (rc == null) return
        if (rc.laps.isEmpty()) {
            raceStore.clearCurrent()
            return
        }
        rc.endEpoch = System.currentTimeMillis()
        rc.durMs = clockNow() - raceStartClock
        rc.reason = reason
        raceStore.archive(rc)
        link?.uploadRaceNow(rc.id, rc.toJson().toString())
        if (reason == "target") {
            raceEnded = true
            showRaceFinished(rc)
        }
    }

    private fun showRaceFinished(rc: RaceRecord) {
        val msg = "LAPS: ${rc.counted()}\nBEST: ${fmtMs(rc.bestMs())}\nTIME: ${mmss(rc.durMs)}"
        AlertDialog.Builder(this, R.style.Theme_LapTimer_Dialog)
            .setTitle("RACE FINISHED")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .setNeutralButton("VER RESUMEN") { _, _ -> startActivity(Intent(this, RacesActivity::class.java)) }
            .show()
    }

    // ---------- Resumen al cruzar la meta ----------

    private fun showLapSummary(r: LapResult) {
        if (inPit || reconName != null) return
        val title = StringBuilder()
        when (r.kind) {
            1 -> title.append("OUT LAP")
            2 -> title.append("IN LAP")
            else -> title.append("LAP ").append(r.number)
        }
        if (r.kind != 0 && r.number > 0) title.append(" · LAP ").append(r.number)
        if (r.isBest) title.append(" · BEST LAP")
        txtSumTitle.text = title.toString()
        txtSumTime.text = fmtMs(r.lapMs)
        val d = r.deltaMs
        if (r.kind != 0) {
            txtSumDelta.text = "—"
            txtSumDelta.setTextColor(COL_MUTED)
        } else if (d == null) {
            txtSumDelta.text = "FIRST LAP"
            txtSumDelta.setTextColor(COL_MUTED)
        } else {
            txtSumDelta.text = String.format(Locale.US, "%+.3f", d / 1000.0)
            txtSumDelta.setTextColor(if (d <= 0L) COL_GREEN else COL_RED)
        }
        renderChips(chipsRowSum, r.marks, r.marks.size, 20f)
        if (settings.isEndurance()) {
            val s = stint
            val sb = StringBuilder("STINT ").append(s.number).append(" · ")
                .append(s.driver.uppercase(Locale.getDefault())).append(" · LAP ").append(s.lapsDone)
            if (s.plan > 0) sb.append('/').append(s.plan)
            txtSumStint.text = sb.toString()
            txtSumStint.visibility = View.VISIBLE
        } else {
            txtSumStint.visibility = View.GONE
        }
        lapOverlay.visibility = View.VISIBLE
        lapOverlay.removeCallbacks(hideLapSummary)
        lapOverlay.postDelayed(hideLapSummary, settings.lapSummarySec * 1000L)
    }

    private fun hideLapSummaryNow() {
        lapOverlay.removeCallbacks(hideLapSummary)
        lapOverlay.visibility = View.GONE
    }

    // ---------- Carril de boxes ----------

    /** Tiempo mínimo de parada (s): solo en resistencia; la petición del pit puede cambiarlo para esta parada. */
    private fun minPitSec(): Int {
        if (!settings.isEndurance()) return 0
        if (pitSecOverride > 0) return pitSecOverride
        val sw = pendingSwap
        return if (sw != null && sw.pitSec > 0) sw.pitSec else settings.pitMinSec
    }

    /** Entrar o salir de la zona PADDOCK: muestra o cierra la pantalla amarilla (sin cuenta atrás ni parada registrada). */
    private fun updatePaddock(inside: Boolean) {
        if (!inside) paddockDismissed = false
        val now = inside && !paddockDismissed
        if (now == inPaddock) return
        inPaddock = now
        runOnUiThread {
            if (now) {
                // Si hay carril de PIT, salir del paddock por PIT OUT cuenta como OUT LAP
                if (circuit?.hasPitLane == true) engine?.setInPit(true)
                showPaddockOverlay()
            } else if (!inPit) {
                pitOverlay.removeCallbacks(pitBlink)
                pitOverlay.visibility = View.GONE
            }
        }
    }

    private fun showPaddockOverlay() {
        if (reconName != null) return
        hideLapSummaryNow()
        pitOverlay.visibility = View.VISIBLE
        pitOverlay.removeCallbacks(pitBlink)
        pitBlink.run()
    }

    private fun enterPit() {
        if (reconName != null || inPit) return
        // En demo solo se entra en boxes cuando el piloto virtual está en modo parada
        if (demoActive && demo?.inPitLane != true) return
        inPit = true
        pitStartAt = clockNow()
        pitBlinkOn = false
        hideLapSummaryNow()
        pitOverlay.visibility = View.VISIBLE
        pitOverlay.removeCallbacks(pitBlink)
        pitBlink.run()
        ensureProgrammedSwap()
        // Si el pit ya había confirmado el cambio desde el panel, se aplica al entrar
        val sw = pendingSwap
        if (sw != null && sw.confirmed && settings.isEndurance()) applySwap(sw)
    }

    private fun exitPit() {
        // El tiempo de conducción del stint empieza al cruzar PIT OUT (también si venías del PADDOCK)
        if (stint.startEpoch == 0L) {
            stint.startEpoch = clockNow()
            saveStint()
        }
        if (!inPit) return
        val dur = clockNow() - pitStartAt
        val min = minPitSec()
        inPit = false
        pitSecOverride = 0
        pitOverlay.removeCallbacks(pitBlink)
        pitOverlay.visibility = View.GONE
        if (inPaddock) showPaddockOverlay()
        val ok = !(min > 0 && dur < min * 1000L)
        if (!demoActive) {
            settings.pitStops = settings.pitStops + 1
            settings.pitLastMs = dur
            if (!ok) settings.pitFails = settings.pitFails + 1
            settings.addPitLog(stint.number, dur, min, ok)
        }
        if (!ok) {
            pitFailText = "PIT STOP INCUMPLIDO: ${dur / 1000} s DE $min s"
            pitFailUntil = SystemClock.elapsedRealtime() + PIT_FAIL_NOTICE_MS
            updateAlerts()
        }
        renderBottom()
    }

    /** Cierra la pantalla de boxes sin registrar parada (cambio de circuito, modo demo). */
    private fun resetPitUi() {
        inPaddock = false
        inPit = false
        pitSecOverride = 0
        pitOverlay.removeCallbacks(pitBlink)
        pitOverlay.visibility = View.GONE
    }

    private fun updatePitOverlay() {
        if (!inPit && !inPaddock) return
        val paddockOnly = inPaddock && !inPit
        val min = if (paddockOnly) 0 else minPitSec()
        val elapsed = if (paddockOnly) 0L else clockNow() - pitStartAt
        val remaining = min * 1000L - elapsed
        val ready = min > 0 && remaining <= 0L
        val bg = when {
            ready -> if (pitBlinkOn) PIT_GREEN_A else PIT_GREEN_B
            else -> if (pitBlinkOn) PIT_YELLOW_A else PIT_YELLOW_B
        }
        pitOverlay.setBackgroundColor(bg)
        if (paddockOnly) {
            txtPitTitle.text = "PADDOCK"
            txtPitCount.text = "PADDOCK"
        } else if (min <= 0) {
            txtPitTitle.text = if (inPaddock) "PIT · PADDOCK" else "PIT LANE"
            txtPitCount.text = "PIT"
        } else if (ready) {
            txtPitTitle.text = "TIEMPO MÍNIMO CUMPLIDO"
            txtPitCount.text = "GO, GO, GO!!!!"
        } else {
            txtPitTitle.text = (if (inPaddock) "PADDOCK" else "PIT") + " · TIEMPO MÍNIMO"
            txtPitCount.text = mmss(((remaining + 999L) / 1000L) * 1000L)
        }
        // El tiempo total en PIT se cuenta siempre, cumpla o no el mínimo
        txtPitSub.text = if (paddockOnly) "" else "EN PIT " + mmss(elapsed)
        val swap = if (settings.isEndurance()) pendingSwap else null
        if (swap != null) {
            val laps = if (swap.laps > 0) " · ${swap.laps} laps" else ""
            val prog = if (swap.id.startsWith("prog-")) " (programado)" else ""
            val missing = swap.next.isBlank()
            txtPitSwap.text = if (missing) "NO DRIVER - ASK PIT\nAhora: ${stint.driver}"
            else "CAMBIO → ${swap.next.uppercase(Locale.getDefault())}$laps$prog\nAhora: ${stint.driver}"
            btnPitSwapConfirm.visibility = View.VISIBLE
            btnPitSwapConfirm.alpha = if (missing) 0.35f else 1f
            pitSwapBox.visibility = View.VISIBLE
        } else if (settings.isEndurance()) {
            txtPitSwap.text = "DRIVER: ${stint.driver.uppercase(Locale.getDefault())} · STINT ${stint.number}"
            btnPitSwapConfirm.visibility = View.GONE
            pitSwapBox.visibility = View.VISIBLE
        } else {
            pitSwapBox.visibility = View.GONE
        }
    }

    // ---------- Demo: paradas en boxes automáticas (el piloto virtual no tiene botones) ----------

    /**
     * Tiempo parado (simulado) en el próximo box. Con el ajuste de demo, exactamente ese. Sin él, alterna paradas
     * cuyo tiempo TOTAL en el carril es el 60 % y el 140 % del mínimo, para probar parada incumplida y cumplida.
     */
    private fun demoStopMs(): Long {
        val set = settings.demoStopSec
        if (set > 0) return set * 1000L
        val min = minPitSec()
        if (min <= 0) return 8_000L
        demoStops++
        val target = if (demoStops % 2 == 1) min * 600L else min * 1400L
        return maxOf(1_000L, target - DEMO_LANE_TRAVEL_MS)
    }

    private fun maybeRequestDemoPit() {
        val d = demo ?: return
        if (!demoActive || d.pitBusy) return
        val want = if (settings.isEndurance()) (pendingSwap != null || isFinalLap()) else demoLapsSincePit >= 3
        if (!want) return
        demoLapsSincePit = 0
        d.requestPit(demoStopMs())
    }

    // ---------- Telemetría hacia el pit ----------

    private fun batteryPct(): Int {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun buildTelemetry(): String? {
        if (!hasFix && !demoActive) return null
        val o = JSONObject()
        val s = stint
        o.put("t", System.currentTimeMillis())
        o.put("lat", lastLat)
        o.put("lon", lastLon)
        o.put("kmh", Math.round(lastKmh))
        o.put("car", settings.carName)
        o.put("driver", s.driver)
        o.put("circuito", circuit?.name ?: "")
        o.put("demo", demoActive)
        o.put("bat", batteryPct())
        o.put("v", APP_VERSION)
        o.put("stint", s.number)
        o.put("stintLaps", s.lapsDone)
        o.put("plan", s.plan)
        o.put("stintMs", stintElapsedMs())
        o.put("minMs", s.minMin * 60_000L)
        o.put("maxMs", s.maxMin * 60_000L)
        o.put("mode", settings.raceMode)
        race?.startEpoch?.let { o.put("raceStart", it) }
        o.put("lastLap", isFinalLap())
        o.put("health", stintHealth().name.lowercase())
        o.put("minLaps", s.minLaps)
        o.put("maxLaps", s.maxLaps)
        o.put("planMin", s.planMin)
        o.put("pitMinSec", minPitSec())
        if (inPit) o.put("inPitMs", clockNow() - pitStartAt)
        settings.plannedDriver(s.number + 1)?.let { o.put("next", it) }
        if (pendingSwap?.next?.isBlank() == true) o.put("needDriver", true)
        o.put("pitStops", settings.pitStops)
        o.put("pitFails", settings.pitFails)
        o.put("pitLastMs", settings.pitLastMs)
        o.put("inPit", inPit)
        pendingSwap?.let {
            o.put("swap", it.next)
            o.put("swapProg", it.id.startsWith("prog-"))
        }
        currentAlert?.let { o.put("alert", it) }
        val st = lastState
        if (st != null) {
            o.put("lap", st.lapNumber)
            o.put("sector", st.sector)
            o.put("sectores", st.sectorCount)
            o.put("run", st.running)
            st.currentLapMs?.let { o.put("cur", it) }
            st.lastLapMs?.let { o.put("last", it) }
            st.bestLapMs?.let { o.put("best", it) }
            st.optimalMs?.let { o.put("opt", it) }
            st.deltaSec?.let { o.put("delta", it) }
        }
        return o.toString()
    }

    private fun lapJson(r: LapResult): String {
        val o = JSONObject()
        o.put("n", r.number)
        o.put("ms", r.lapMs)
        val arr = JSONArray()
        for (sp in r.splits) arr.put(sp)
        o.put("s", arr)
        o.put("t", System.currentTimeMillis())
        o.put("circuito", circuit?.name ?: "")
        o.put("d", stint.driver)
        o.put("st", stint.number)
        o.put("k", r.kind)
        o.put("demo", demoActive)
        return o.toString()
    }

    // ---------- Modo demo ----------

    private fun startDemo() {
        if (reconName != null) exitRecon()
        endRace("closed")
        raceEnded = false
        recorder?.end()
        demoActive = true
        resetPitUi()
        val t1 = settings.targetFor(1)
        stint = StintState(
            1, "Demo", 0, 0L, t1.planLaps, t1.minMin, t1.maxMin, t1.minLaps, t1.maxLaps, t1.planMin
        )
        demoLapsSincePit = 0
        demoStops = 0
        lastFinalShown = false
        simNowMs = 0L
        pendingSwap = null
        circuit = DemoCircuit.circuit
        engine = buildEngine(DemoCircuit.circuit, false)
        lastState = null
        hz = 0.0
        lastRawMs = null
        resetDisplay()
        val d = DemoSource(Handler(Looper.getMainLooper())) { ev, render -> onPosition(ev, render) }
        d.factor = demoFactor
        demo = d
        refreshTop()
        d.start()
        toast("Demo: desliza desde arriba y toca la barra para cambiar la velocidad")
    }

    private fun stopDemo() {
        endRace("closed")
        raceEnded = false
        demo?.stop()
        demo = null
        demoActive = false
        resetPitUi()
        pendingSwap = null
        stint = loadStint()
        circuit = store.loadActive()
        engine = circuit?.let { buildEngine(it, true) }
        lastState = null
        lastKmh = 0.0
        hz = 0.0
        lastRawMs = null
        resetDisplay()
        refreshTop()
        renderGps()
        updateLock()
    }

    private fun cycleDemoSpeed() {
        demoFactor = when (demoFactor) {
            1 -> 2
            2 -> 4
            else -> 1
        }
        demo?.factor = demoFactor
        showTopBar()
        toast("Demo ×$demoFactor")
    }

    // ---------- Reconocimiento de circuito ----------

    private fun startRecon(name: String) {
        reconName = name
        draftFinish = null
        draftSectors.clear()
        renderBottom()
        refreshTop()
        showTopBar()
    }

    private fun exitRecon() {
        reconName = null
        draftFinish = null
        draftSectors.clear()
        renderBottom()
        refreshTop()
    }

    private fun currentPoint(): GatePoint? {
        val course = lastCourse
        if (!hasFix || course == null) {
            toast("Aún no hay rumbo: avanza o camina unos segundos")
            return null
        }
        return GatePoint(lastLat, lastLon, course)
    }

    private fun markFinish() {
        if (!checkUnlocked()) return
        val p = currentPoint() ?: return
        draftFinish = p
        refreshTop()
        toast("FINISH marcado")
    }

    private fun markSector() {
        if (!checkUnlocked()) return
        if (draftFinish == null) {
            toast("Marca primero FINISH")
            return
        }
        val p = currentPoint() ?: return
        draftSectors.add(p)
        refreshTop()
        toast("Sector marcado")
    }

    private fun saveCircuit() {
        if (!checkUnlocked()) return
        val name = reconName ?: return
        val finish = draftFinish
        if (finish == null) {
            toast("Marca primero FINISH")
            return
        }
        val c = Circuit(name, finish, draftSectors.toList())
        store.save(c)
        exitRecon()
        selectCircuit(c)
        toast("Circuito guardado: ${c.sectorCount} sectores")
    }
}
