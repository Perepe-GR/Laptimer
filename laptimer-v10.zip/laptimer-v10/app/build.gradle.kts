plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ejemplo.laptimer"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ejemplo.laptimer"
        minSdk = 24
        targetSdk = 34
        versionCode = 10
        versionName = "0.10"
    }

    signingConfigs {
        // Firma fija: así cada versión nueva se instala encima de la anterior sin perder los datos.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.github.mik3y:usb-serial-for-android:3.7.3")
    implementation("org.osmdroid:osmdroid-android:6.1.20")
}
