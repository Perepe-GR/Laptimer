# Instrucciones para Copilot

## Qué es este proyecto
App Android (Kotlin, vistas XML, sin Compose) de cronometraje de vueltas para pilotos, versión 0.10.
Lee un receptor GPS u-blox externo de 25 Hz por USB (NMEA a 115200) con `usb-serial-for-android`.
Pantalla en horizontal pensada para ir montada en el vehículo.

## Idioma
Interfaz, comentarios y mensajes de commit en español.

## Estructura (app/src/main/java/com/ejemplo/laptimer)
- `NmeaParser.kt`, `Geo.kt`: lectura NMEA y utilidades geográficas.
- `Circuit.kt`: circuito = meta + sectores + carril de boxes opcional (entrada y salida), con ancho izquierdo y derecho por línea (JSON). `Stats.kt`: mejores marcas y traza de referencia por circuito.
- `LapEngine.kt`: cruce de meta/sectores/boxes con interpolación, delta en vivo por posición, óptima, colores de sector F1.
- `DemoSource.kt`: circuito demo y piloto virtual a 25 Hz.
- `Sessions.kt`: sesiones y traza GPS en binario. `Analysis.kt`: cálculo y gráficas. `Export.kt`: CSV/GPX.
- `PitLink.kt`: ajustes (`NetSettings`) y Firebase Realtime Database por REST (sin SDK), un intercambio cada 10 s o más.
  Rutas de la sala: `live/<coche>`, `laps/<coche>`, `inbox/<coche>` (mensajes) y `cmd/<coche>` (cambio de piloto).
- `HomeActivity.kt`: menú de inicio (circuitos, historial, demo, modo de carrera, configuración de resistencia, ajustes).
  `MainActivity.kt`: pantalla de sesión con dos vistas, barra superior oculta, mensajes del pit con colores
  (`StripesDrawable.kt` para las rayas), resumen al cruzar la meta y pantalla de boxes parpadeante.
  Modos: `NetSettings.raceMode` = trackday | sprint | resistencia (los dos primeros son iguales por ahora).
- `Backup.kt` (copia de seguridad en zip), `RecordsActivity.kt` (récords y evolución).
- `MapEditorActivity.kt` (osmdroid), `HistoryActivity.kt`, `SessionActivity.kt`, `AnalysisActivity.kt`.
- `pit-panel/index.html`: panel web del pit (se publica en un repositorio público aparte con GitHub Pages).

## Reglas
- Mantén `minSdk 24`, el `applicationId` y las versiones de Gradle/AGP/Kotlin salvo que se pida otra cosa.
- No añadas dependencias nuevas sin necesidad. No uses el SDK de Firebase: la conexión es REST.
- Sin sonido, voz ni vibración en la app, en ningún caso.
- Las reglas de Firebase no deben cambiar: no uses nodos nuevos con validaciones propias.
- Cambios mínimos y localizados. Diseño y colores: `docs/DISENO.md`; no los cambies sin que se pida.

- El APK se firma con `app/debug.keystore` (fija) para que las actualizaciones se instalen encima. No la cambies.

## Compilación
La compila GitHub Actions (workflow "Build APK", `gradle assembleDebug`). Si falla: lee el log del paso
"Compilar APK", corrige solo lo necesario y abre un Pull Request. Este código nunca se ha compilado en local.

## Novedades de la 0.9
- `PageActivity.kt`: base de las pantallas de menú a pantalla completa; `Pages.kt` las contiene (modo, ajustes de sesión,
  pit crew, resistencia, estrategia, copia de seguridad, circuitos). Los menús ya no son diálogos.
- `PitLink.kt`: `StintTarget` y `NetSettings.strategy()/targetFor()` (objetivo por stint), registro de paradas (`pitLog`).
- `MainActivity.kt`: `stintHealth()` (rojo, verde, lila), `isFinalLap()`, cambio programado (`SwapRequest` con id `prog-N`),
  `clockNow()` (reloj simulado en demo) y pantalla de boxes con cuenta atrás y "GO, GO, GO!!!!".
- `DemoSource.kt`: el piloto virtual entra en boxes, para y sale (`requestPit`, `pitBusy`, `inPitLane`).

## Novedades de la 0.10
- `Races.kt`: `RaceRecord`/`RaceStore` (resumen de race, sin sectores). `MainActivity.kt`: `ensureRace()`, `onRaceLap()`,
  `endRace()`, `isRaceFinalLap()`, `updateLapHeader()`, `updatePaddock()`. `PitLink.kt`: `sprintLaps`, `sprintMin`,
  `outlapCounts`, `inlapCounts`, `plannedDriver(n)` (sin lista de relevos) y `uploadRaceNow()`.
- `LapEngine.kt`: `startOutLap()`/`endInLap()`, `LapResult.kind` (0 normal, 1 OUT LAP, 2 IN LAP); las laps parciales no entran en BEST.
- `Circuit.kt`: `paddock` (polígono `LatLon`), `inPaddock()`. `MapEditorActivity.kt`: + PADDOCK.
- Interfaz en inglés para los términos de circuito (LAP, BEST, LAST, OPTIMAL, PIT, PADDOCK, DRIVER, FINISH, RACE, CAR).
