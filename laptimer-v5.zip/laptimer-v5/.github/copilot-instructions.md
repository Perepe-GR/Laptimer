# Instrucciones para Copilot

## Qué es este proyecto
App Android (Kotlin, vistas XML, sin Compose) de cronometraje de vueltas para pilotos, versión 0.5.
Lee un receptor GPS u-blox externo de 25 Hz por USB (NMEA a 115200) con `usb-serial-for-android`.
Pantalla en horizontal pensada para ir montada en el vehículo.

## Idioma
Interfaz, comentarios y mensajes de commit en español.

## Estructura (app/src/main/java/com/ejemplo/laptimer)
- `NmeaParser.kt`, `Geo.kt`: lectura NMEA y utilidades geográficas.
- `Circuit.kt`: circuito = meta + sectores (JSON). `Stats.kt`: mejores marcas y traza de referencia por circuito.
- `LapEngine.kt`: cruce de meta/sectores con interpolación, delta en vivo por posición, óptima, colores de sector F1.
- `DemoSource.kt`: circuito demo y piloto virtual a 25 Hz.
- `Sessions.kt`: sesiones y traza GPS en binario. `Analysis.kt`: cálculo y gráficas. `Export.kt`: CSV/GPX.
- `PitLink.kt`: Firebase Realtime Database por REST (sin SDK), un intercambio cada 10 s o más.
- `MainActivity.kt`, `MapEditorActivity.kt` (osmdroid), `HistoryActivity.kt`, `SessionActivity.kt`, `AnalysisActivity.kt`.
- `pit-panel/index.html`: panel web del pit (se publica en un repositorio público aparte con GitHub Pages).

## Reglas
- Mantén `minSdk 24`, el `applicationId` y las versiones de Gradle/AGP/Kotlin salvo que se pida otra cosa.
- No añadas dependencias nuevas sin necesidad. No uses el SDK de Firebase: la conexión es REST.
- Sin sonido, voz ni vibración en la app, en ningún caso.
- Cambios mínimos y localizados. Diseño y colores: `docs/DISENO.md`; no los cambies sin que se pida.

## Compilación
La compila GitHub Actions (workflow "Build APK", `gradle assembleDebug`). Si falla: lee el log del paso
"Compilar APK", corrige solo lo necesario y abre un Pull Request. Este código nunca se ha compilado en local.
