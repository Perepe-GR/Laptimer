package com.ejemplo.laptimer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbManager
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), SerialInputOutputManager.Listener {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.ejemplo.laptimer.USB_PERMISSION"
        private const val BAUD_RATE = 115200
        private const val DELTA_RANGE_FRACTION = 0.02 // la barra cubre ±2 % de la mejor vuelta
        private const val LOCK_KMH = 10.0             // por encima se bloquean menús y botones
        private const val MSG_SHOW_MS = 120_000L      // un mensaje del pit se ve 2 minutos
        private const val AUTOLOAD_M = 3000.0         // radio de carga automática de circuito
        private const val APP_VERSION = "0.5"
        private val COL_GREEN = Color.parseColor("#C6F432")
        private val COL_RED = Color.parseColor("#FF5A5F")
        private val COL_PURPLE = Color.parseColor("#A855F7")
        private val COL_YELLOW = Color.parseColor("#FACC15")
        private val COL_NEUTRAL = Color.parseColor("#1E242B")
        private val COL_MUTED = Color.parseColor("#9AA3AE")
        private val COL_DARK = Color.parseColor("#0B0D10")
    }

    private lateinit var txtTop: TextView
    private lateinit var btnMenu: Button
    private lateinit var txtNet: TextView
    private lateinit var txtGps: TextView
    private lateinit var txtDelta: TextView
    private lateinit var deltaBar: DeltaBarView
    private lateinit var txtRangeNeg: TextView
    private lateinit var txtRangePos: TextView
    private lateinit var txtLap: TextView
    private lateinit var chipsRow: LinearLayout
    private lateinit var txtBest: TextView
    private lateinit var txtLast: TextView
    private lateinit var txtOpt: TextView
    private lateinit var txtSpeed: TextView
    private lateinit var bannerPit: TextView
    private lateinit var reconBar: View
    private lateinit var btnMarkFinish: Button
    private lateinit var btnMarkSector: Button
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button

    private val usbManager by lazy { getSystemService(Context.USB_SERVICE) as UsbManager }
    private val parser = NmeaParser()
    private val lineBuffer = StringBuilder()
    private val ioExecutor: ExecutorService = Executors.newCachedThreadPool()
    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null

    private lateinit var store: CircuitStore
    private lateinit var statsStore: StatsStore
    private lateinit var sessionStore: SessionStore
    private lateinit var settings: NetSettings
    @Volatile private var recorder: SessionRecorder? = null
    @Volatile private var link: FirebaseRestLink? = null

    @Volatile private var circuit: Circuit? = null
    @Volatile private var engine: LapEngine? = null
    @Volatile private var lastState: EngineState? = null

    // Última posición conocida (hilo USB -> UI)
    @Volatile private var hasFix = false
    @Volatile private var lastLat = 0.0
    @Volatile private var lastLon = 0.0
    @Volatile private var lastKmh = 0.0
    @Volatile private var lastCourse: Double? = null
    private var hz = 0.0
    private var lastRawMs: Long? = null
    private var sats = 0
    private var autoLoadDone = false

    // Modo demo
    @Volatile private var demoActive = false
    private var demo: DemoSource? = null
    private var demoFactor = 1
    private var savedCircuit: Circuit? = null

    // Reconocimiento de circuito (borrador)
    private var reconName: String? = null
    private var draftFinish: GatePoint? = null
    private val draftSectors = mutableListOf<GatePoint>()

    private var netStatus = NetStatus.OFF
    private var chipCount = 0
    private val clearMsg = Runnable { clearPitMessage() }

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importCircuit(uri)
        }

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                openPort()
            } else {
                toast("Permiso USB denegado")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        bindViews()
        store = CircuitStore(this)
        statsStore = StatsStore(this)
        sessionStore = SessionStore(this)
        settings = NetSettings(this)
        recorder = SessionRecorder(sessionStore) { settings.saveTrace }

        circuit = store.loadActive()
        engine = circuit?.let { buildEngine(it, true) }

        link = FirebaseRestLink(
            settings,
            { buildTelemetry() },
            { msgs -> runOnUiThread { showPitMessages(msgs) } },
            { st -> runOnUiThread { netStatus = st; renderNet() } }
        )

        btnMenu.setOnClickListener { showMenu() }
        btnMarkFinish.setOnClickListener { markFinish() }
        btnMarkSector.setOnClickListener { markSector() }
        btnSave.setOnClickListener { saveCircuit() }
        btnCancel.setOnClickListener { exitRecon() }
        txtTop.setOnClickListener { if (demoActive) cycleDemoSpeed() }

        ContextCompat.registerReceiver(
            this,
            permissionReceiver,
            IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        resetDisplay()
        refreshTop()
        renderNet()
    }

    private fun bindViews() {
        txtTop = findViewById(R.id.txtTop)
        btnMenu = findViewById(R.id.btnMenu)
        txtNet = findViewById(R.id.txtNet)
        txtGps = findViewById(R.id.txtGps)
        txtDelta = findViewById(R.id.txtDelta)
        deltaBar = findViewById(R.id.deltaBar)
        txtRangeNeg = findViewById(R.id.txtRangeNeg)
        txtRangePos = findViewById(R.id.txtRangePos)
        txtLap = findViewById(R.id.txtLap)
        chipsRow = findViewById(R.id.chipsRow)
        txtBest = findViewById(R.id.txtBest)
        txtLast = findViewById(R.id.txtLast)
        txtOpt = findViewById(R.id.txtOpt)
        txtSpeed = findViewById(R.id.txtSpeed)
        bannerPit = findViewById(R.id.bannerPit)
        reconBar = findViewById(R.id.reconBar)
        btnMarkFinish = findViewById(R.id.btnMarkFinish)
        btnMarkSector = findViewById(R.id.btnMarkSector)
        btnSave = findViewById(R.id.btnSave)
        btnCancel = findViewById(R.id.btnCancel)
    }

    override fun onResume() {
        super.onResume()
        if (!demoActive) syncActiveCircuit()
        connect()
        link?.start()
        renderNet()
    }

    override fun onPause() {
        link?.stop()
        if (demoActive) stopDemo()
        disconnect()
        super.onPause()
    }

    override fun onDestroy() {
        demo?.stop()
        recorder?.end()
        unregisterReceiver(permissionReceiver)
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    // ---------- Motor ----------

    private fun buildEngine(c: Circuit, withHistory: Boolean): LapEngine {
        val initial = if (withHistory) statsStore.load(c) else null
        val e = LapEngine(c, initial)
        e.onLap = { r -> handleLap(r) }
        return e
    }

    /** Se llama al cerrar cada vuelta válida (hilo USB, o principal en demo). */
    private fun handleLap(r: LapResult) {
        link?.enqueueLap(lapJson(r))
        if (demoActive) return
        recorder?.onLap(r)
        val c = circuit
        val e = engine
        if (c != null && e != null) {
            val d = e.persistData()
            statsStore.save(c, CircuitStats(c.signature(), d.bestLapMs, d.bestSectors), d.ref)
        }
    }

    private fun syncActiveCircuit() {
        val active = store.loadActive()
        if (active != null && active != circuit) selectCircuit(active)
    }

    private fun selectCircuit(c: Circuit) {
        recorder?.end()
        circuit = c
        engine = buildEngine(c, true)
        lastState = null
        store.activeName = c.name
        resetDisplay()
        refreshTop()
    }

    // ---------- Conexión USB ----------

    private fun findDriver(): UsbSerialDriver? =
        UsbSerialProber.getDefaultProber().findAllDrivers(usbManager).firstOrNull()

    private fun connect() {
        if (port != null) return
        val driver = findDriver()
        if (driver == null) {
            if (!demoActive) txtGps.text = "Conecta la antena por USB"
            return
        }
        if (!usbManager.hasPermission(driver.device)) {
            val pi = PendingIntent.getBroadcast(
                this,
                0,
                Intent(ACTION_USB_PERMISSION).setPackage(packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usbManager.requestPermission(driver.device, pi)
            txtGps.text = "Pidiendo permiso USB..."
            return
        }
        openPort()
    }

    private fun openPort() {
        val driver = findDriver()
        if (driver == null) {
            txtGps.text = "Antena no detectada"
            return
        }
        val connection = usbManager.openDevice(driver.device)
        if (connection == null) {
            txtGps.text = "No se pudo abrir el USB"
            return
        }
        val p = driver.ports[0]
        try {
            p.open(connection)
            p.setParameters(BAUD_RATE, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: Exception) {
            txtGps.text = "Error USB: ${e.message}"
            runCatching { p.close() }
            return
        }
        port = p
        ioManager = SerialInputOutputManager(p, this).also { ioExecutor.submit(it) }
        txtGps.text = "Esperando GPS..."
    }

    private fun disconnect() {
        ioManager?.stop()
        ioManager = null
        runCatching { port?.close() }
        port = null
    }

    // ---------- Datos del GPS (hilo de E/S) ----------

    override fun onNewData(data: ByteArray) {
        val text = String(data, Charsets.US_ASCII)
        synchronized(lineBuffer) {
            lineBuffer.append(text)
            var idx = lineBuffer.indexOf("\n")
            while (idx >= 0) {
                val line = lineBuffer.substring(0, idx).trim()
                lineBuffer.delete(0, idx + 1)
                if (line.isNotEmpty()) handleSentence(line)
                idx = lineBuffer.indexOf("\n")
            }
        }
    }

    override fun onRunError(e: Exception) {
        runOnUiThread {
            txtGps.text = "USB desconectado"
            disconnect()
        }
    }

    private fun handleSentence(line: String) {
        when (val ev = parser.parse(line)) {
            is NmeaEvent.Position -> if (!demoActive) onPosition(ev, true)
            is NmeaEvent.Fix -> runOnUiThread {
                sats = ev.sats
                renderGps()
            }
            null -> Unit
        }
    }

    private fun onPosition(ev: NmeaEvent.Position, render: Boolean) {
        lastLat = ev.lat
        lastLon = ev.lon
        lastKmh = ev.speedKmh
        hasFix = true
        val c = ev.courseDeg
        if (c != null && ev.speedKmh > 1.5) lastCourse = c

        val prev = lastRawMs
        if (prev != null) {
            val d = ev.timeMs - prev
            if (d in 1L..1000L) {
                val inst = 1000.0 / d
                hz = if (hz == 0.0) inst else hz * 0.95 + inst * 0.05
            }
        }
        lastRawMs = ev.timeMs

        val st = engine?.onFix(ev.lat, ev.lon, ev.speedKmh, ev.timeMs)
        lastState = st

        if (!demoActive && st != null) {
            val circ = circuit
            val rec = recorder
            if (circ != null && rec != null &&
                rec.onSample(circ, st.gpsTimeMs, ev.lat, ev.lon, ev.speedKmh)
            ) {
                engine?.resetSession()
            }
        }

        if (!render) return
        runOnUiThread {
            txtSpeed.text = String.format(Locale.US, "%.0f", ev.speedKmh)
            renderGps()
            if (st != null) renderEngine(st)
            updateLock()
            if (!demoActive && !autoLoadDone) {
                autoLoadDone = true
                autoLoad(ev.lat, ev.lon)
            }
        }
    }

    /** Carga el circuito guardado más cercano la primera vez que hay señal (no en mitad de una vuelta). */
    private fun autoLoad(lat: Double, lon: Double) {
        if (reconName != null) return
        if (lastState?.running == true) return
        val near = store.nearest(lat, lon, AUTOLOAD_M) ?: return
        if (near.name != circuit?.name) {
            selectCircuit(near)
            toast("Circuito cargado: ${near.name}")
        }
    }

    // ---------- Pantalla ----------

    private fun renderGps() {
        txtGps.text = when {
            demoActive -> String.format(Locale.US, "DEMO ×%d · GPS simulado %.0f Hz", demoFactor, hz)
            !hasFix -> "GPS sin señal"
            else -> String.format(Locale.US, "GPS %.0f Hz · %d sat", hz, sats)
        }
    }

    private fun renderNet() {
        when {
            !settings.enabled -> {
                txtNet.text = "PIT: desactivado"
                txtNet.setTextColor(COL_MUTED)
            }
            netStatus == NetStatus.OK -> {
                txtNet.text = "PIT: conectado"
                txtNet.setTextColor(COL_GREEN)
            }
            netStatus == NetStatus.ERROR -> {
                txtNet.text = "PIT: sin red"
                txtNet.setTextColor(COL_RED)
            }
            else -> {
                txtNet.text = "PIT: conectando…"
                txtNet.setTextColor(COL_MUTED)
            }
        }
    }

    private fun renderEngine(st: EngineState) {
        txtLap.text = fmtMs(st.currentLapMs)
        txtLast.text = fmtMs(st.lastLapMs)
        txtBest.text = fmtMs(st.bestLapMs)
        txtOpt.text = fmtMs(st.optimalMs)
        renderChips(st.marks, st.sectorCount)

        val best = st.bestLapMs
        val range = if (best != null) best * DELTA_RANGE_FRACTION / 1000.0 else null
        if (range != null) {
            txtRangeNeg.text = String.format(Locale.US, "-%.2f s", range)
            txtRangePos.text = String.format(Locale.US, "+%.2f s", range)
        } else {
            txtRangeNeg.text = "-2 %"
            txtRangePos.text = "+2 %"
        }

        val d = st.deltaSec
        if (d != null && range != null && range > 0.0) {
            txtDelta.text = String.format(Locale.US, "%+.3f", d)
            txtDelta.setTextColor(if (d <= 0.0) COL_GREEN else COL_RED)
            deltaBar.setRatio((d / range).toFloat())
        } else {
            txtDelta.text = "—.—"
            txtDelta.setTextColor(COL_GREEN)
            deltaBar.setRatio(0f)
        }

        if (reconName == null) {
            val name = circuit?.name ?: ""
            val prefix = if (demoActive) "DEMO ×$demoFactor · " else ""
            txtTop.text = if (st.running) {
                "${prefix}Vuelta ${st.lapNumber} · S${st.sector}/${st.sectorCount} · $name"
            } else {
                "${prefix}$name · cruza la meta para empezar"
            }
        }
    }

    private fun renderChips(marks: List<SectorMark?>, count: Int) {
        if (chipCount != count) {
            chipsRow.removeAllViews()
            for (i in 0 until count) {
                val tv = TextView(this)
                tv.textSize = 12f
                tv.typeface = Typeface.DEFAULT_BOLD
                tv.gravity = Gravity.CENTER
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                if (i > 0) lp.marginStart = dp(6)
                tv.layoutParams = lp
                chipsRow.addView(tv)
            }
            chipCount = count
        }
        for (i in 0 until count) {
            val tv = chipsRow.getChildAt(i) as TextView
            val m = marks.getOrNull(i)
            val bg = GradientDrawable()
            bg.cornerRadius = dp(8).toFloat()
            if (m == null) {
                bg.setColor(COL_NEUTRAL)
                tv.setTextColor(COL_MUTED)
                tv.text = "S${i + 1} --"
            } else {
                val fill: Int
                val fg: Int
                when (m.kind) {
                    MarkKind.NEUTRAL -> { fill = COL_NEUTRAL; fg = Color.WHITE }
                    MarkKind.PURPLE -> { fill = COL_PURPLE; fg = Color.WHITE }
                    MarkKind.GREEN -> { fill = COL_GREEN; fg = COL_DARK }
                    MarkKind.YELLOW -> { fill = COL_YELLOW; fg = COL_DARK }
                }
                bg.setColor(fill)
                tv.setTextColor(fg)
                tv.text = "S${i + 1} " + String.format(Locale.US, "%.2f", m.ms / 1000.0)
            }
            tv.background = bg
        }
    }

    private fun resetDisplay() {
        txtLap.text = "--:--.---"
        txtLast.text = "--:--.---"
        txtBest.text = "--:--.---"
        txtOpt.text = "--:--.---"
        txtDelta.text = "—.—"
        txtDelta.setTextColor(COL_GREEN)
        deltaBar.setRatio(0f)
        txtRangeNeg.text = "-2 %"
        txtRangePos.text = "+2 %"
        renderChips(emptyList(), circuit?.sectorCount ?: 3)
    }

    private fun refreshTop() {
        val name = reconName
        txtTop.text = when {
            name != null -> "Reconocimiento «$name» · meta ${if (draftFinish != null) "✔" else "—"} · sectores ${draftSectors.size}"
            demoActive -> "DEMO ×$demoFactor · toca aquí para cambiar la velocidad"
            circuit == null -> "Sin circuito · pulsa MENÚ"
            else -> "${circuit?.name} · cruza la meta para empezar"
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Bloqueo en movimiento ----------

    private fun locked(): Boolean = !demoActive && lastKmh > LOCK_KMH

    private fun updateLock() {
        btnMenu.alpha = if (locked()) 0.4f else 1f
    }

    private fun checkUnlocked(): Boolean {
        if (locked()) {
            toast("Bloqueado: vas a más de ${LOCK_KMH.toInt()} km/h")
            return false
        }
        return true
    }

    // ---------- Mensajes del pit (solo texto, sin sonido ni voz ni vibración) ----------

    private fun showPitMessages(list: List<PitMessage>) {
        if (list.isEmpty()) return
        bannerPit.text = list.joinToString("  |  ") { it.text }
        bannerPit.setBackgroundResource(R.drawable.banner_pit)
        bannerPit.setTextColor(Color.parseColor("#141413"))
        bannerPit.removeCallbacks(clearMsg)
        bannerPit.postDelayed(clearMsg, MSG_SHOW_MS)
    }

    private fun clearPitMessage() {
        bannerPit.text = "Sin mensajes del pit"
        bannerPit.setBackgroundResource(R.drawable.banner_dim)
        bannerPit.setTextColor(COL_MUTED)
    }

    // ---------- Telemetría hacia el pit ----------

    private fun batteryPct(): Int {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun buildTelemetry(): String? {
        if (!hasFix && !demoActive) return null
        val o = JSONObject()
        o.put("t", System.currentTimeMillis())
        o.put("lat", lastLat)
        o.put("lon", lastLon)
        o.put("kmh", Math.round(lastKmh))
        o.put("circuito", circuit?.name ?: "")
        o.put("demo", demoActive)
        o.put("bat", batteryPct())
        o.put("v", APP_VERSION)
        val st = lastState
        if (st != null) {
            o.put("lap", st.lapNumber)
            o.put("sector", st.sector)
            o.put("sectores", st.sectorCount)
            o.put("run", st.running)
            st.currentLapMs?.let { o.put("cur", it) }
            st.lastLapMs?.let { o.put("last", it) }
            st.bestLapMs?.let { o.put("best", it) }
            st.optimalMs?.let { o.put("opt", it) }
            st.deltaSec?.let { o.put("delta", it) }
        }
        return o.toString()
    }

    private fun lapJson(r: LapResult): String {
        val o = JSONObject()
        o.put("n", r.number)
        o.put("ms", r.lapMs)
        val arr = JSONArray()
        for (s in r.splits) arr.put(s)
        o.put("s", arr)
        o.put("t", System.currentTimeMillis())
        o.put("circuito", circuit?.name ?: "")
        o.put("demo", demoActive)
        return o.toString()
    }

    // ---------- Menú ----------

    private fun showMenu() {
        if (!checkUnlocked()) return
        val items = arrayOf(
            "Elegir circuito",
            "Nuevo circuito en el mapa",
            "Editar circuito en el mapa",
            "Nuevo circuito por reconocimiento",
            "Borrar circuito",
            "Importar circuito",
            "Exportar circuito",
            "Historial de sesiones",
            if (demoActive) "Detener demo" else "Modo demo",
            "Ajustes y pit crew"
        )
        AlertDialog.Builder(this)
            .setTitle("Menú")
            .setItems(items) { _, w ->
                if (demoActive && w < 7) {
                    toast("Detén la demo primero")
                } else {
                    when (w) {
                        0 -> chooseCircuit()
                        1 -> askName(true)
                        2 -> editCircuitOnMap()
                        3 -> askName(false)
                        4 -> deleteCircuit()
                        5 -> importLauncher.launch(arrayOf("*/*"))
                        6 -> exportCircuit()
                        7 -> startActivity(Intent(this, HistoryActivity::class.java))
                        8 -> toggleDemo()
                        9 -> showSettings()
                        else -> Unit
                    }
                }
            }
            .show()
    }

    private fun askName(onMap: Boolean) {
        val input = EditText(this)
        input.hint = "Nombre del circuito"
        AlertDialog.Builder(this)
            .setTitle(if (onMap) "Nuevo circuito en el mapa" else "Nuevo circuito")
            .setView(input)
            .setPositiveButton("Empezar") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) {
                    if (onMap) openMapEditor(n, true) else startRecon(n)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun chooseCircuit() {
        val list = store.list()
        if (list.isEmpty()) {
            toast("No hay circuitos guardados")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Elegir circuito")
            .setItems(list.map { it.name }.toTypedArray()) { _, i -> selectCircuit(list[i]) }
            .show()
    }

    private fun deleteCircuit() {
        val list = store.list()
        if (list.isEmpty()) {
            toast("No hay circuitos guardados")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Borrar circuito")
            .setItems(list.map { it.name }.toTypedArray()) { _, i ->
                val c = list[i]
                store.delete(c.name)
                statsStore.clear(c.name)
                if (circuit?.name == c.name) {
                    recorder?.end()
                    circuit = null
                    engine = null
                    lastState = null
                    store.activeName = null
                    resetDisplay()
                }
                refreshTop()
                toast("Circuito borrado")
            }
            .show()
    }

    private fun openMapEditor(name: String, isNew: Boolean) {
        val i = Intent(this, MapEditorActivity::class.java)
        i.putExtra("name", name)
        i.putExtra("new", isNew)
        if (hasFix) {
            i.putExtra("lat", lastLat)
            i.putExtra("lon", lastLon)
        }
        startActivity(i)
    }

    private fun editCircuitOnMap() {
        val c = circuit
        if (c == null) {
            toast("No hay circuito activo")
            return
        }
        openMapEditor(c.name, false)
    }

    private fun exportCircuit() {
        val c = circuit
        if (c == null) {
            toast("No hay circuito activo")
            return
        }
        Export.share(this, c.name + ".json", c.toJson(), "application/json")
    }

    private fun importCircuit(uri: android.net.Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalStateException("archivo vacío")
            val c = Circuit.fromJson(text)
            store.save(c)
            selectCircuit(c)
            toast("Circuito importado: ${c.name}")
        } catch (e: Exception) {
            toast("No se pudo importar: ${e.message}")
        }
    }

    // ---------- Modo demo ----------

    private fun toggleDemo() {
        if (demoActive) stopDemo() else startDemo()
    }

    private fun startDemo() {
        if (reconName != null) exitRecon()
        recorder?.end()
        savedCircuit = circuit
        demoActive = true
        circuit = DemoCircuit.circuit
        engine = buildEngine(DemoCircuit.circuit, false)
        lastState = null
        hz = 0.0
        lastRawMs = null
        resetDisplay()
        val d = DemoSource(Handler(Looper.getMainLooper())) { ev, render -> onPosition(ev, render) }
        d.factor = demoFactor
        demo = d
        refreshTop()
        d.start()
        toast("Demo en marcha: toca la barra superior para cambiar la velocidad")
    }

    private fun stopDemo() {
        demo?.stop()
        demo = null
        demoActive = false
        circuit = savedCircuit ?: store.loadActive()
        engine = circuit?.let { buildEngine(it, true) }
        lastState = null
        lastKmh = 0.0
        hz = 0.0
        lastRawMs = null
        resetDisplay()
        refreshTop()
        renderGps()
        updateLock()
    }

    private fun cycleDemoSpeed() {
        demoFactor = when (demoFactor) {
            1 -> 2
            2 -> 4
            else -> 1
        }
        demo?.factor = demoFactor
        toast("Demo ×$demoFactor")
    }

    // ---------- Ajustes y pit crew ----------

    private fun showSettings() {
        val pad = dp(16)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 2, pad, 0)

        fun label(t: String): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = 12f
            v.setTextColor(COL_MUTED)
            v.setPadding(0, dp(10), 0, 0)
            return v
        }

        val swEnabled = CheckBox(this)
        swEnabled.text = "Activar conexión con el pit"
        swEnabled.isChecked = settings.enabled

        val etDb = EditText(this)
        etDb.hint = "https://tu-proyecto-default-rtdb.firebaseio.com"
        etDb.setText(settings.dbUrl)
        etDb.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI

        val etRoom = EditText(this)
        etRoom.setText(settings.ensureRoom())
        etRoom.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS

        val btnNew = Button(this)
        btnNew.text = "Generar código nuevo"
        btnNew.setOnClickListener { etRoom.setText(NetSettings.newCode()) }

        val etInt = EditText(this)
        etInt.inputType = InputType.TYPE_CLASS_NUMBER
        etInt.setText(settings.intervalS.toString())

        val etPanel = EditText(this)
        etPanel.hint = "https://usuario.github.io/panel-pit/"
        etPanel.setText(settings.panelUrl)
        etPanel.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI

        val swTrace = CheckBox(this)
        swTrace.text = "Guardar la traza GPS completa de las sesiones"
        swTrace.isChecked = settings.saveTrace

        box.addView(swEnabled)
        box.addView(label("URL de Firebase Realtime Database"))
        box.addView(etDb)
        box.addView(label("Código de sala (10 caracteres; el mismo en el panel del pit)"))
        box.addView(etRoom)
        box.addView(btnNew)
        box.addView(label("Intervalo de envío en segundos (mínimo 10; más alto = menos batería)"))
        box.addView(etInt)
        box.addView(label("URL del panel del pit (para compartir el enlace)"))
        box.addView(etPanel)
        box.addView(swTrace)

        fun saveAll() {
            settings.enabled = swEnabled.isChecked
            settings.dbUrl = etDb.text.toString()
            settings.room = etRoom.text.toString()
            settings.intervalS = etInt.text.toString().toIntOrNull() ?: 10
            settings.panelUrl = etPanel.text.toString()
            settings.saveTrace = swTrace.isChecked
            link?.start()
            renderNet()
        }

        val scroll = ScrollView(this)
        scroll.addView(box)
        AlertDialog.Builder(this)
            .setTitle("Ajustes y pit crew")
            .setView(scroll)
            .setPositiveButton("Guardar") { _, _ -> saveAll() }
            .setNeutralButton("Compartir enlace del pit") { _, _ ->
                saveAll()
                shareLink()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun shareLink() {
        val panel = settings.panelUrl
        if (panel.isBlank() || settings.dbUrl.isBlank()) {
            toast("Falta la URL del panel o la de Firebase")
            return
        }
        val sep = if (panel.contains("?")) "&" else "?"
        val url = panel + sep + "db=" + URLEncoder.encode(settings.dbUrl, "UTF-8") +
            "&room=" + settings.room
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, url)
        startActivity(Intent.createChooser(i, "Compartir enlace del pit"))
    }

    // ---------- Reconocimiento de circuito ----------

    private fun startRecon(name: String) {
        reconName = name
        draftFinish = null
        draftSectors.clear()
        bannerPit.visibility = View.GONE
        reconBar.visibility = View.VISIBLE
        refreshTop()
    }

    private fun exitRecon() {
        reconName = null
        draftFinish = null
        draftSectors.clear()
        reconBar.visibility = View.GONE
        bannerPit.visibility = View.VISIBLE
        refreshTop()
    }

    private fun currentPoint(): GatePoint? {
        val course = lastCourse
        if (!hasFix || course == null) {
            toast("Aún no hay rumbo: avanza o camina unos segundos")
            return null
        }
        return GatePoint(lastLat, lastLon, course)
    }

    private fun markFinish() {
        if (!checkUnlocked()) return
        val p = currentPoint() ?: return
        draftFinish = p
        refreshTop()
        toast("Meta marcada")
    }

    private fun markSector() {
        if (!checkUnlocked()) return
        if (draftFinish == null) {
            toast("Marca primero la meta")
            return
        }
        val p = currentPoint() ?: return
        draftSectors.add(p)
        refreshTop()
        toast("Sector marcado")
    }

    private fun saveCircuit() {
        if (!checkUnlocked()) return
        val name = reconName ?: return
        val finish = draftFinish
        if (finish == null) {
            toast("Marca primero la meta")
            return
        }
        val c = Circuit(name, finish, draftSectors.toList())
        store.save(c)
        exitRecon()
        selectCircuit(c)
        toast("Circuito guardado: ${c.sectorCount} sectores")
    }
}
