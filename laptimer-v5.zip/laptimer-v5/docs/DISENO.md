# Diseño de la pantalla del piloto (horizontal)

## Colores (aprobados, no cambiar)
- Fondo `#0B0D10`; tarjetas `#12161B` con esquinas de 16 dp
- Verde acento `#C6F432` (más rápido, mejor vuelta); rojo `#FF5A5F` (más lento)
- Texto secundario `#9AA3AE`; ámbar `#F5A524` (mensajes del pit)
- Sectores tipo F1: morado `#A855F7`, verde `#C6F432`, amarillo `#FACC15`, neutro `#1E242B`

## Jerarquía
1. **Delta** (protagonista): tarjeta grande a la izquierda, hasta 150 sp. Barra de ±2 % de la mejor vuelta,
   verde a la izquierda si ganas tiempo, roja a la derecha si lo pierdes. Etiquetas de rango en segundos.
2. **Tiempo de vuelta** con las cajitas de sector S1..Sn debajo (colores F1).
3. **Mejor / Última / Óptima** en tres tarjetas pequeñas (mejor y óptima incluyen el historial del circuito).
4. **Velocidad**: tarjeta pequeña y gris, secundaria a propósito.
5. **Banda inferior**: mensajes del pit (ámbar, solo texto, 2 minutos en pantalla) o botones del reconocimiento.
6. Barra superior: estado, MENÚ, red del pit y GPS.

## Reglas
- Sin sonido, sin voz y sin vibración en ningún momento.
- Por encima de 10 km/h se bloquean el menú y los botones de marcado (no en modo demo).
