# Lap Timer · versión 0.5

Cronómetro propio para antena GPS u-blox de 25 Hz por USB. Instalación paso a paso en `LEEME-INSTALACION.md`.

## Novedades de la 0.5
- **Logo** nuevo (medidor de delta con aguja) como icono adaptable de Android.
- **Modo demo** y **Circuito Demo** (óvalo de 714 m con 3 sectores, piloto virtual a 25 Hz, x1/x2/x4).
  Sirve para probar todo en casa, quieto. Las vueltas demo no se guardan en el historial.
- **Historial de sesiones**: se graban solas al moverte con un circuito activo. Detalle con vueltas y sectores,
  exportación a CSV y GPX.
- **Análisis post-sesión**: compara dos vueltas con velocidad por distancia, delta por distancia y trazado
  coloreado por velocidad.
- **Mejor vuelta guardada por circuito**: la siguiente sesión arranca con delta desde la primera vuelta.
  Mejor y óptima muestran los mejores históricos del circuito.
- **Colores de sector tipo F1**: morado (mejor que todo lo conocido), verde (mejor de la sesión), amarillo (más lento).
- **Circuitos en el mapa** (OpenStreetMap): colocar meta y sectores tocando, arrastrar, fijar el sentido; importar y exportar.
- **Carga automática** del circuito guardado más cercano (menos de 3 km) al tener señal.
- **Bloqueo** del menú y de los botones de marcado por encima de 10 km/h (no en demo).
- **Pit crew por Firebase** (REST, sin SDK): telemetría cada 10 s o más, vueltas al cerrarse, mensajes de texto del pit
  en la banda inferior. Sin sonido, voz ni vibración. Panel web en `pit-panel/`.

## Cómo funciona la red
Un único intercambio cada N segundos (mínimo 10, configurable): sube posición y estado, sube las vueltas
terminadas y baja los mensajes nuevos. No hay conexión permanente, para ahorrar batería. Solo funciona con la app
abierta. Los mensajes del pit llegan con ese retraso como máximo.

## Ajustes en el código
`LapEngine.kt`: `GATE_HALF_WIDTH_M` (15 m), `MIN_LAP_MS` (10 s). `MainActivity.kt`: `DELTA_RANGE_FRACTION` (0,02),
`LOCK_KMH` (10), `MSG_SHOW_MS` (2 min), `AUTOLOAD_M` (3000 m).
