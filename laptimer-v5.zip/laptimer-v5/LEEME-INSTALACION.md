# Instalación paso a paso (desde un iPhone, con repositorio privado)

## A. Compilar la app 0.5 en GitHub
1. En tu repositorio privado, borra el zip antiguo (`laptimer-v2.zip`): ábrelo, tres puntos, *Delete file*.
2. Sustituye el contenido de `.github/workflows/build.yml` por el de `docs/build-desde-zip.yml`
   (está dentro de este zip, puedes abrirlo en Archivos y copiarlo). Este flujo usa siempre el zip más reciente,
   así que en las próximas versiones solo tendrás que subir el zip nuevo.
3. **Add file > Upload files** y sube `laptimer-v5.zip` sin descomprimir. Commit.
4. Pestaña **Actions**: arranca "Build APK" (3 a 5 minutos). Con ✓ verde, el APK está en **Releases > APK más reciente > laptimer.apk**.
5. Descárgalo en tu móvil Android e instálalo encima de la versión anterior (se mantienen tus circuitos).

## B. Firebase (una vez)
Desde el navegador del móvil, mejor en modo "sitio de escritorio".
1. console.firebase.google.com, inicia sesión con tu cuenta de Google, **Crear proyecto** (nombre libre, sin Analytics).
2. **Compilación > Realtime Database > Crear base de datos**, elige una ubicación de Europa y **modo bloqueado**.
3. Pestaña **Reglas**: pega el contenido de `docs/firebase-rules.json` y **Publicar**.
4. Pestaña **Datos**: copia la URL de la base de datos (algo como `https://nombre-default-rtdb.europe-west1.firebasedatabase.app`).
El plan gratuito debería sobrar para este uso; confírmalo al crear el proyecto.

## C. Panel web del pit (repositorio público aparte)
Con cuenta gratuita, GitHub Pages solo publica repositorios públicos, por eso va separado. No contiene datos sensibles.
1. **+ > New repository**, nombre `panel-pit`, **Public**.
2. **Add file > Upload files** y sube `pit-panel/index.html` (el archivo suelto). Commit.
3. **Settings > Pages**: *Deploy from a branch*, rama `main`, carpeta `/ (root)`, **Save**.
4. En 1 o 2 minutos estará en `https://TU_USUARIO.github.io/panel-pit/`.

## D. Configurar la app
**MENÚ > Ajustes y pit crew**: activa la conexión, pega la URL de Firebase, deja el código de sala generado
(o genera otro), pon el intervalo (10 s o más), pega la URL del panel y toca **Compartir enlace del pit**.
Quien abra ese enlace ve el panel ya configurado.

## E. Probar en casa, quieto
1. **MENÚ > Modo demo**. Toca la barra superior para cambiar la velocidad (x1, x2, x4).
2. Abre el panel: verás los datos del piloto virtual (con etiqueta DEMO) y las vueltas.
3. Manda "BOX" desde el panel: aparece en la banda ámbar de la app en el siguiente intercambio.

## Privacidad
Cualquiera que tenga el enlace del panel ve tu posición mientras la app está conectada. El código de sala tiene
10 caracteres. Para cortar el acceso, genera un código nuevo en Ajustes.
