package com.ejemplo.laptimer

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.net.URLEncoder
import java.util.Locale

/** Menú de inicio: se abre antes de las pantallas de vueltas. */
class HomeActivity : AppCompatActivity() {

    private lateinit var store: CircuitStore
    private lateinit var statsStore: StatsStore
    private lateinit var settings: NetSettings
    private lateinit var txtCircuit: TextView
    private lateinit var txtAntenna: TextView
    private lateinit var txtPit: TextView
    private lateinit var txtMode: TextView

    private val muted = Color.parseColor("#9AA3AE")
    private val lime = Color.parseColor("#C6F432")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        store = CircuitStore(this)
        statsStore = StatsStore(this)
        settings = NetSettings(this)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun openPage(target: Class<*>) = startActivity(Intent(this, target))

    private fun roundBg(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun menuButton(text: String, primary: Boolean, action: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.gravity = Gravity.CENTER
        b.textSize = if (primary) 22f else 15f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(if (primary) Color.parseColor("#0B0D10") else Color.WHITE)
        b.background = roundBg(if (primary) lime else Color.parseColor("#12161B"), 16)
        b.isClickable = true
        b.setOnClickListener { action() }
        return b
    }

    private fun statusLine(): TextView {
        val t = TextView(this)
        t.textSize = 15f
        t.setTextColor(muted)
        t.setPadding(0, dp(8), 0, 0)
        return t
    }

    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(Color.parseColor("#0B0D10"))
        root.setPadding(dp(16), dp(12), dp(16), dp(12))

        // Izquierda: identidad, estado e INICIAR SESIÓN
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.background = roundBg(Color.parseColor("#12161B"), 16)
        left.setPadding(dp(20), dp(16), dp(20), dp(16))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.mipmap.ic_launcher)
        head.addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)))
        val title = TextView(this)
        title.text = "Lap Timer  1.0"
        title.textSize = 24f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.setPadding(dp(12), 0, 0, 0)
        head.addView(title)
        left.addView(head)

        txtCircuit = statusLine()
        txtAntenna = statusLine()
        txtPit = statusLine()
        txtMode = statusLine()
        left.addView(txtCircuit)
        left.addView(txtAntenna)
        left.addView(txtPit)
        left.addView(txtMode)

        left.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        left.addView(
            menuButton("INICIAR SESIÓN", true) {
                startActivity(Intent(this, MainActivity::class.java))
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72))
        )
        root.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        // Derecha: resto de funciones
        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        fun row(vararg items: Pair<String, () -> Unit>) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for ((i, item) in items.withIndex()) {
                val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                if (i > 0) lp.marginStart = dp(10)
                r.addView(menuButton(item.first, false, item.second), lp)
            }
            val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            if (right.childCount > 0) rlp.topMargin = dp(10)
            right.addView(r, rlp)
        }
        row(
            "MODO DEMO" to {
                val i = Intent(this, MainActivity::class.java)
                i.putExtra("demo", true)
                startActivity(i)
            },
            "CIRCUITOS" to { openPage(CircuitsActivity::class.java) }
        )
        row(
            "HISTORIAL" to { startActivity(Intent(this, HistoryActivity::class.java)) },
            "RECORDS" to { startActivity(Intent(this, RecordsActivity::class.java)) }
        )
        row(
            "AJUSTES DE SESIÓN" to { openPage(SessionSettingsActivity::class.java) },
            "AJUSTES Y PIT CREW" to { openPage(PitSettingsActivity::class.java) }
        )
        row(
            "MODO DE RACE" to { openPage(ModePageActivity::class.java) },
            "CONFIGURAR ENDURANCE" to { openPage(EnduranceActivity::class.java) }
        )
        row(
            "RACE SUMMARIES" to { openPage(RacesActivity::class.java) },
            "COPIA DE SEGURIDAD" to { openPage(BackupActivity::class.java) }
        )
        val rlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        rlp.marginStart = dp(12)
        root.addView(right, rlp)
        return root
    }

    private fun refreshStatus() {
        val c = store.loadActive()
        txtCircuit.text = "Circuito activo: " + (c?.name ?: "ninguno")
        val usb = getSystemService(Context.USB_SERVICE) as UsbManager
        val has = UsbSerialProber.getDefaultProber().findAllDrivers(usb).isNotEmpty()
        txtAntenna.text = "Antena USB: " + (if (has) "detectada" else "no detectada")
        txtAntenna.setTextColor(if (has) lime else muted)
        txtPit.text = if (settings.enabled) {
            "Pit crew: activado · sala " + settings.room
        } else {
            "Pit crew: desactivado"
        }
        txtMode.text = "Modo: " + settings.raceModeLabel()
        txtMode.setTextColor(if (settings.isEndurance()) lime else muted)
    }
}
