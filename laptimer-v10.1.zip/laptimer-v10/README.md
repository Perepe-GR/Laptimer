# Lap Timer · versión 1.0

Cronómetro propio para antena GPS u-blox de 25 Hz por USB. Instalación y actualización en `LEEME-INSTALACION.md`.

## Novedades de la 1.0
- **Stint**: el tiempo de conducción empieza al cruzar PIT OUT (no al confirmar el cambio).
- **Modos**: track day es libre; sprint es una race con laps totales y/o duración (termina la primera que se cumpla);
  endurance como hasta ahora. Aviso **FINAL LAP** y diálogo **RACE FINISHED** al terminar.
- **Race summaries**: al terminar la race o cerrar la sesión se guarda un resumen (laps con tiempo, tipo de lap y, en
  endurance, driver y stint; sin sectores) en la app (INICIO > RACE SUMMARIES) y en Firebase (`races/<car>/<id>`), visible en el panel.
- **Drivers**: la lista de drivers es solo una lista. Quién conduce cada stint se elige en la estrategia. Sin siguiente driver
  definido, la confirmación se bloquea (**NO DRIVER - ASK PIT**) hasta que el panel envíe quién entra.
- **LAP actual**: cabecera "LAP n" en la tarjeta del tiempo; en sprint "LAP n / total" con barra de progreso (por laps y/o tiempo).
- **OUT LAP / IN LAP**: con carril de PIT, los sectores se miden desde PIT OUT y hasta PIT IN. Ajuste para que cuenten como lap
  numerada. Nunca entran en BEST, récords ni mejores sectores (son laps parciales).
- **PADDOCK**: zona dibujable en el editor del mapa (+ PADDOCK, vértices arrastrables). Dentro de la zona sale la pantalla
  amarilla "PADDOCK" (también si abres la sesión dentro). Salir del paddock por PIT OUT cuenta como OUT LAP.
- **Layout**: BEST / LAST / OPTIMAL en tres filas anchas con tiempos grandes; delta y tarjeta del tiempo algo más pequeños;
  tiempo del resumen al cruzar FINISH más grande y blanco.
- **Tercer layout (mapa)**: desliza desde el centro; ciclo completa → simplificada → mapa (izquierda = siguiente, derecha = anterior).
  Trazado de tu última lap coloreado por sectores, tu posición, líneas de FINISH/sectores/PIT y zona PADDOCK; delta, tiempo, LAP y stint en las esquinas.
- **Inglés**: LAP, BEST, LAST, OPTIMAL, PIT, PADDOCK, DRIVER, STINT, SECTOR, FINISH, RACE, CAR en toda la interfaz y el panel;
  los menús siguen en español.
- **Panel**: sin mapa; LAP log completo de la race con barra deslizable (sin sectores); Race summaries; "Limpiar sala" borra
  los cars que no transmiten (todo si no transmite ninguno); mensajes rápidos en inglés.

## Ajustes en el código
`MainActivity.kt`: `DELTA_UI_MS`, `MSG_MAX_MS`, `TOPBAR_MS`, `AUTOLOAD_M`, `SIGNAL_TIMEOUT_MS`, `STINT_WARN_MIN`,
`PIT_BLINK_MS`, `PIT_MAX_MS`, `DEMO_LANE_TRAVEL_MS`, `RACE_RESUME_MS`. `LapEngine.kt`: `MIN_LAP_MS`.
`Races.kt`: modelo y almacén del resumen de race. `PageActivity.kt` es la base de las pantallas de menú.
