# Lap Timer · versión 0.2

Cronómetro propio para antena GPS u-blox de 25 Hz por USB (NMEA a 115200).
Esta versión añade el diseño nuevo, circuitos con sectores, delta en vivo y vuelta óptima.

## Qué hace
- **Delta en vivo en cada posición**: compara tu tiempo con el que tu mejor vuelta tardó en
  llegar al mismo punto del circuito (25 actualizaciones por segundo, suavizado ligero).
- **Barra del delta de ±2 % de la mejor vuelta**, verde si ganas tiempo y roja si lo pierdes.
- **Circuitos** con meta y puntos de sector (3 sectores = 2 puntos intermedios + meta).
  Se crean con una vuelta de reconocimiento y se guardan con nombre.
- **Vuelta óptima**: suma de tus mejores sectores. Aparece al completar la primera vuelta.
- Tiempo de vuelta, mejor, última y velocidad (secundaria).
- Cruce de meta y sectores con interpolación entre muestras (precisión mucho mejor que 1 muestra).

## Qué NO hace todavía
- Mensajes del pit crew (la banda inferior está reservada).
- Guardar sesiones ni exportar datos.
- Reconocimiento automático de circuito.

## Obtener el APK sin instalar nada (GitHub)
1. Crea una cuenta gratuita en github.com y un repositorio nuevo (privado vale).
2. Descomprime el zip. En el repositorio pulsa "uploading an existing file" y arrastra el
   CONTENIDO de la carpeta `laptimer-v2` (no la carpeta), incluida `.github`. Pulsa "Commit changes".
   Usa la rama `main`.
3. Pestaña **Actions**: arranca solo "Build APK" (3 a 5 minutos).
4. APK listo, de dos formas:
   - **Releases** (columna derecha del repositorio): "APK más reciente" > `laptimer-v2.apk`.
     Se puede descargar directamente desde el móvil.
   - Dentro de la ejecución, sección **Artifacts**: `laptimer-apk`.
5. Instálalo en el móvil permitiendo "instalar apps de orígenes desconocidos".

Si el flujo sale en rojo: abre `COPILOT_TAREAS.md` y pega la tarea 1 en Copilot, o crea un Issue
con la plantilla "Corregir compilación" y asígnaselo a Copilot si tu plan lo permite.
El código nunca se ha compilado en local, así que un primer fallo es posible.

## Crear un circuito (vuelta de reconocimiento)
1. Conecta la antena (hub USB-C con carga) y espera a que arriba ponga "GPS 25 Hz".
2. **CIRCUITO > Nuevo circuito**, pon un nombre.
3. En la línea de meta pulsa **MARCAR META**. Después, al pasar por cada punto de sector, **MARCAR SECTOR**
   (para 3 sectores, dos puntos). Pulsa **GUARDAR**.
4. La app guarda el circuito y lo deja activo. Empieza a contar al cruzar la meta.

**Seguridad:** no pulses botones conduciendo. Haz el reconocimiento con un acompañante o caminando el
circuito: la app necesita el rumbo, que el GPS da en cuanto te mueves (basta caminar).

## Ajustes en el código
En `LapEngine.kt`: `GATE_HALF_WIDTH_M` (ancho de la línea, 15 m a cada lado) y `MIN_LAP_MS`
(vuelta mínima válida, 10 s). En `MainActivity.kt`: `DELTA_RANGE_FRACTION` (0,02 = ±2 %).

## Formato de circuito (JSON, en el almacenamiento privado de la app)
```json
{
  "nombre": "Mi circuito",
  "meta": { "lat": 41.0000, "lon": 1.0000, "rumbo": 90 },
  "sectores": [
    { "lat": 41.0010, "lon": 1.0020, "rumbo": 180 },
    { "lat": 41.0030, "lon": 1.0005, "rumbo": 270 }
  ]
}
```
(Coordenadas de ejemplo inventadas.)
