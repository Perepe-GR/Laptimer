# Instrucciones para Copilot

## Qué es este proyecto
App Android (Kotlin, vistas XML, sin Compose) de cronometraje de vueltas para pilotos.
Lee un receptor GPS u-blox externo de 25 Hz por USB (NMEA a 115200 baudios) con la
librería `usb-serial-for-android`. Pantalla en horizontal, pensada para ir montada en el vehículo.

## Idioma
Interfaz, comentarios y mensajes de commit en español.

## Estructura (app/src/main/java/com/ejemplo/laptimer)
- `NmeaParser.kt`: parsea RMC (posición, velocidad, rumbo, hora) y GGA (satélites, HDOP).
- `Geo.kt`: marco plano local en metros.
- `Circuit.kt`: circuito = meta + puntos de sector (JSON en almacenamiento privado).
- `LapEngine.kt`: cruce de meta/sectores con interpolación, mejor vuelta como traza de
  referencia, delta en vivo por posición, vuelta óptima (suma de mejores sectores).
- `DeltaBarView.kt`: barra del delta (rango ±2 % de la mejor vuelta).
- `MainActivity.kt`: USB, menú de circuitos, reconocimiento de circuito y pantalla.

## Reglas
- Mantén `minSdk 24`, el `applicationId` y las versiones de Gradle/AGP/Kotlin salvo que se pida lo contrario.
- No añadas dependencias nuevas sin necesidad. Todavía no hay red ni Firebase.
- Cambios mínimos y localizados. No reescribas archivos enteros para arreglar un error.
- Diseño de referencia y colores: `docs/DISENO.md`. No cambies colores ni jerarquía visual sin que se pida.

## Compilación
La compila GitHub Actions (workflow "Build APK", `gradle assembleDebug`). Si falla:
lee el log del paso "Compilar APK", corrige solo lo necesario y abre un Pull Request.
Nunca se ha compilado en local: pueden aparecer errores de sintaxis o de API de Kotlin/Android.
