package com.ejemplo.laptimer

import kotlin.math.cos

/** Marco plano local (metros) centrado en un punto. Válido a escala de circuito. */
class LocalFrame(lat0: Double, private val lon0: Double, private val latRef: Double = lat0) {
    private val kx = 111_320.0 * cos(Math.toRadians(lat0))
    private val ky = 110_574.0

    fun x(lon: Double): Double = (lon - lon0) * kx
    fun y(lat: Double): Double = (lat - latRef) * ky
}
