package com.ejemplo.laptimer

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Línea de paso: segmento a-b perpendicular al rumbo, más la dirección de marcha (dx, dy). */
private class Gate(
    val ax: Double, val ay: Double,
    val bx: Double, val by: Double,
    val dx: Double, val dy: Double
)

/** Muestra de la vuelta de referencia: tiempo (ms desde el inicio de vuelta) y posición local. */
class RefSample(val t: Long, val x: Double, val y: Double)

/**
 * Vuelta de referencia (la mejor). Dada una posición, devuelve en qué instante de la
 * vuelta pasó la referencia por el punto más cercano de su trazado.
 */
class ReferenceLap(samples: List<RefSample>) {
    private val n = samples.size
    private val xs = DoubleArray(n) { samples[it].x }
    private val ys = DoubleArray(n) { samples[it].y }
    private val ts = LongArray(n) { samples[it].t }
    private val cum = DoubleArray(n) // distancia acumulada a lo largo de la traza (m)
    private var last = 0
    private var misses = 0

    init {
        for (i in 1 until n) {
            cum[i] = cum[i - 1] + hypot(xs[i] - xs[i - 1], ys[i] - ys[i - 1])
        }
    }

    fun reset() {
        last = 0
        misses = 0
    }

    fun timeAt(x: Double, y: Double): Double? {
        if (n < 2) return null

        var lo = last
        var hi = last
        if (misses > 50) {
            // Perdido (trompo, salida de pista): búsqueda global
            lo = 0
            hi = n - 2
        } else {
            // Ventana: 15 m hacia atrás y 80 m hacia delante de la última posición
            while (lo > 0 && cum[last] - cum[lo - 1] < 15.0) lo--
            while (hi < n - 2 && cum[hi + 1] - cum[last] < 80.0) hi++
        }
        if (hi > n - 2) hi = n - 2

        var bestD = Double.MAX_VALUE
        var bestT = 0.0
        var bestIdx = last
        for (i in lo..hi) {
            val sx = xs[i + 1] - xs[i]
            val sy = ys[i + 1] - ys[i]
            val len2 = sx * sx + sy * sy
            val u = if (len2 < 1e-9) 0.0
            else (((x - xs[i]) * sx + (y - ys[i]) * sy) / len2).coerceIn(0.0, 1.0)
            val px = xs[i] + u * sx
            val py = ys[i] + u * sy
            val d = hypot(x - px, y - py)
            if (d < bestD) {
                bestD = d
                bestT = ts[i] + u * (ts[i + 1] - ts[i])
                bestIdx = i
            }
        }

        if (bestD > 40.0) {
            misses++
            return null
        }
        misses = 0
        last = bestIdx
        return bestT
    }
}

data class EngineState(
    val running: Boolean,
    val lapNumber: Int,
    val sector: Int,
    val sectorCount: Int,
    val currentLapMs: Long?,
    val lastLapMs: Long?,
    val bestLapMs: Long?,
    val optimalMs: Long?,
    val deltaSec: Double?,
    val speedKmh: Double
)

/**
 * Motor de cronometraje:
 *  - detecta el paso por meta y sectores (cruce de línea con interpolación entre muestras),
 *  - guarda la mejor vuelta como traza de referencia,
 *  - calcula el delta en vivo en cada posición frente a esa referencia,
 *  - calcula la vuelta óptima como suma de los mejores sectores.
 */
class LapEngine(private val circuit: Circuit) {

    companion object {
        const val GATE_HALF_WIDTH_M = 15.0
        const val MIN_LAP_MS = 10_000L
        const val MAX_GAP_MS = 1_000L
        private const val HALF_DAY_MS = 43_200_000L
        private const val DAY_MS = 86_400_000L
    }

    private val frame = LocalFrame(circuit.finish.lat, circuit.finish.lon)
    private val finishGate = makeGate(circuit.finish)

    /** Orden de paso dentro de una vuelta: sectores intermedios y, al final, la meta. */
    private val sequence: List<Gate> = circuit.sectors.map { makeGate(it) } + finishGate

    private var hasPrev = false
    private var prevX = 0.0
    private var prevY = 0.0
    private var prevT = 0L
    private var dayOffset = 0L
    private var lastRaw: Long? = null

    private var lapStart: Double? = null
    private var expected = 0
    private var splitStart = 0.0
    private val currentSplits = ArrayList<Long>()
    private val trace = ArrayList<RefSample>()

    private var lapsCompleted = 0
    private var lastLapMs: Long? = null
    private var bestLapMs: Long? = null
    private val bestSectors = LongArray(sequence.size) { Long.MAX_VALUE }
    private var reference: ReferenceLap? = null
    private var deltaSmooth: Double? = null

    private fun makeGate(p: GatePoint): Gate {
        val x = frame.x(p.lon)
        val y = frame.y(p.lat)
        val h = Math.toRadians(p.headingDeg)
        val dx = sin(h)
        val dy = cos(h)
        val px = -dy * GATE_HALF_WIDTH_M
        val py = dx * GATE_HALF_WIDTH_M
        return Gate(x + px, y + py, x - px, y - py, dx, dy)
    }

    @Synchronized
    fun onFix(lat: Double, lon: Double, speedKmh: Double, rawTimeMs: Long): EngineState {
        // Cambio de día (medianoche UTC)
        val prevRaw = lastRaw
        if (prevRaw != null && rawTimeMs < prevRaw - HALF_DAY_MS) dayOffset += DAY_MS
        lastRaw = rawTimeMs
        val t = rawTimeMs + dayOffset
        val x = frame.x(lon)
        val y = frame.y(lat)

        if (hasPrev && t > prevT && t - prevT <= MAX_GAP_MS) {
            processSegment(prevX, prevY, prevT.toDouble(), x, y, t.toDouble())
        }
        hasPrev = true
        prevX = x
        prevY = y
        prevT = t

        var current: Long? = null
        var delta: Double? = null
        val start = lapStart
        if (start != null) {
            val rel = t - start
            current = Math.round(rel)
            if (rel > 0.0) trace.add(RefSample(Math.round(rel), x, y))

            val ref = reference
            if (ref != null) {
                val refT = ref.timeAt(x, y)
                if (refT != null) {
                    val raw = rel - refT
                    val s = deltaSmooth?.let { it * 0.7 + raw * 0.3 } ?: raw
                    deltaSmooth = s
                    delta = s / 1000.0
                }
            }
        }

        return EngineState(
            running = lapStart != null,
            lapNumber = lapsCompleted + 1,
            sector = expected + 1,
            sectorCount = sequence.size,
            currentLapMs = current,
            lastLapMs = lastLapMs,
            bestLapMs = bestLapMs,
            optimalMs = optimal(),
            deltaSec = delta,
            speedKmh = speedKmh
        )
    }

    private fun optimal(): Long? =
        if (bestSectors.all { it != Long.MAX_VALUE }) bestSectors.sum() else null

    /** Fracción (0..1) del segmento de movimiento donde cruza la línea, o null. Solo en sentido de marcha. */
    private fun crossing(g: Gate, x1: Double, y1: Double, x2: Double, y2: Double): Double? {
        val rx = x2 - x1
        val ry = y2 - y1
        val sx = g.bx - g.ax
        val sy = g.by - g.ay
        val den = rx * sy - ry * sx
        if (abs(den) < 1e-9) return null
        val t = ((g.ax - x1) * sy - (g.ay - y1) * sx) / den
        val u = ((g.ax - x1) * ry - (g.ay - y1) * rx) / den
        if (t < 0.0 || t > 1.0 || u < 0.0 || u > 1.0) return null
        if (rx * g.dx + ry * g.dy <= 0.0) return null
        return t
    }

    private fun processSegment(
        x1: Double, y1: Double, t1: Double,
        x2: Double, y2: Double, t2: Double
    ) {
        val running = lapStart != null
        val gate = if (running) sequence[expected] else finishGate
        val f = crossing(gate, x1, y1, x2, y2)
        if (f != null) {
            val tc = t1 + (t2 - t1) * f
            val xc = x1 + (x2 - x1) * f
            val yc = y1 + (y2 - y1) * f
            if (running) onGate(tc, xc, yc) else startLap(tc, xc, yc)
            return
        }

        // Cruzar la meta sin haber pasado por todos los sectores invalida la vuelta: se reinicia.
        if (running && expected < sequence.size - 1) {
            val f2 = crossing(finishGate, x1, y1, x2, y2)
            if (f2 != null) {
                startLap(
                    t1 + (t2 - t1) * f2,
                    x1 + (x2 - x1) * f2,
                    y1 + (y2 - y1) * f2
                )
            }
        }
    }

    private fun startLap(tc: Double, xc: Double, yc: Double) {
        lapStart = tc
        expected = 0
        splitStart = tc
        currentSplits.clear()
        trace.clear()
        trace.add(RefSample(0L, xc, yc))
        reference?.reset()
        deltaSmooth = null
    }

    private fun onGate(tc: Double, xc: Double, yc: Double) {
        currentSplits.add(Math.round(tc - splitStart))
        splitStart = tc
        expected++
        if (expected < sequence.size) return // sector intermedio

        // Vuelta completa
        val start = lapStart ?: return
        val lap = Math.round(tc - start)
        if (lap >= MIN_LAP_MS) {
            lastLapMs = lap
            lapsCompleted++
            for (i in currentSplits.indices) {
                if (currentSplits[i] < bestSectors[i]) bestSectors[i] = currentSplits[i]
            }
            val best = bestLapMs
            if (best == null || lap < best) {
                bestLapMs = lap
                trace.add(RefSample(lap, xc, yc))
                reference = ReferenceLap(ArrayList(trace))
            }
        }
        startLap(tc, xc, yc)
    }
}
