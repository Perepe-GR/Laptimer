package com.ejemplo.laptimer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.util.SerialInputOutputManager
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), SerialInputOutputManager.Listener {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.ejemplo.laptimer.USB_PERMISSION"
        private const val BAUD_RATE = 115200
        private const val DELTA_RANGE_FRACTION = 0.02 // la barra cubre ±2 % de la mejor vuelta
        private val GREEN = Color.parseColor("#C6F432")
        private val RED = Color.parseColor("#FF5A5F")
    }

    private lateinit var txtTop: TextView
    private lateinit var btnCircuit: Button
    private lateinit var txtGps: TextView
    private lateinit var txtDelta: TextView
    private lateinit var deltaBar: DeltaBarView
    private lateinit var txtRangeNeg: TextView
    private lateinit var txtRangePos: TextView
    private lateinit var txtLap: TextView
    private lateinit var txtBest: TextView
    private lateinit var txtLast: TextView
    private lateinit var txtOpt: TextView
    private lateinit var txtSpeed: TextView
    private lateinit var bannerPit: TextView
    private lateinit var reconBar: View
    private lateinit var btnMarkFinish: Button
    private lateinit var btnMarkSector: Button
    private lateinit var btnSave: Button
    private lateinit var btnCancel: Button

    private val usbManager by lazy { getSystemService(Context.USB_SERVICE) as UsbManager }
    private val parser = NmeaParser()
    private val lineBuffer = StringBuilder()
    private val ioExecutor: ExecutorService = Executors.newCachedThreadPool()

    private var port: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null

    private lateinit var store: CircuitStore
    @Volatile private var circuit: Circuit? = null
    @Volatile private var engine: LapEngine? = null

    // Última posición conocida (hilo USB -> UI)
    @Volatile private var hasFix = false
    @Volatile private var lastLat = 0.0
    @Volatile private var lastLon = 0.0
    @Volatile private var lastCourse: Double? = null
    private var hz = 0.0
    private var lastRawMs: Long? = null
    private var sats = 0

    // Reconocimiento de circuito (borrador)
    private var reconName: String? = null
    private var draftFinish: GatePoint? = null
    private val draftSectors = mutableListOf<GatePoint>()

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_USB_PERMISSION) return
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                openPort()
            } else {
                toast("Permiso USB denegado")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        bindViews()
        store = CircuitStore(this)
        circuit = store.loadActive()
        engine = circuit?.let { LapEngine(it) }

        btnCircuit.setOnClickListener { showMenu() }
        btnMarkFinish.setOnClickListener { markFinish() }
        btnMarkSector.setOnClickListener { markSector() }
        btnSave.setOnClickListener { saveCircuit() }
        btnCancel.setOnClickListener { exitRecon() }

        ContextCompat.registerReceiver(
            this,
            permissionReceiver,
            IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        resetDisplay()
        refreshTop()
    }

    private fun bindViews() {
        txtTop = findViewById(R.id.txtTop)
        btnCircuit = findViewById(R.id.btnCircuit)
        txtGps = findViewById(R.id.txtGps)
        txtDelta = findViewById(R.id.txtDelta)
        deltaBar = findViewById(R.id.deltaBar)
        txtRangeNeg = findViewById(R.id.txtRangeNeg)
        txtRangePos = findViewById(R.id.txtRangePos)
        txtLap = findViewById(R.id.txtLap)
        txtBest = findViewById(R.id.txtBest)
        txtLast = findViewById(R.id.txtLast)
        txtOpt = findViewById(R.id.txtOpt)
        txtSpeed = findViewById(R.id.txtSpeed)
        bannerPit = findViewById(R.id.bannerPit)
        reconBar = findViewById(R.id.reconBar)
        btnMarkFinish = findViewById(R.id.btnMarkFinish)
        btnMarkSector = findViewById(R.id.btnMarkSector)
        btnSave = findViewById(R.id.btnSave)
        btnCancel = findViewById(R.id.btnCancel)
    }

    override fun onResume() {
        super.onResume()
        connect()
    }

    override fun onPause() {
        disconnect()
        super.onPause()
    }

    override fun onDestroy() {
        unregisterReceiver(permissionReceiver)
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    // ---------- Conexión USB ----------

    private fun findDriver(): UsbSerialDriver? =
        UsbSerialProber.getDefaultProber().findAllDrivers(usbManager).firstOrNull()

    private fun connect() {
        if (port != null) return
        val driver = findDriver()
        if (driver == null) {
            txtGps.text = "Conecta la antena por USB"
            return
        }
        if (!usbManager.hasPermission(driver.device)) {
            val pi = PendingIntent.getBroadcast(
                this,
                0,
                Intent(ACTION_USB_PERMISSION).setPackage(packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usbManager.requestPermission(driver.device, pi)
            txtGps.text = "Pidiendo permiso USB..."
            return
        }
        openPort()
    }

    private fun openPort() {
        val driver = findDriver()
        if (driver == null) {
            txtGps.text = "Antena no detectada"
            return
        }
        val connection = usbManager.openDevice(driver.device)
        if (connection == null) {
            txtGps.text = "No se pudo abrir el USB"
            return
        }
        val p = driver.ports[0]
        try {
            p.open(connection)
            p.setParameters(BAUD_RATE, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        } catch (e: Exception) {
            txtGps.text = "Error USB: ${e.message}"
            runCatching { p.close() }
            return
        }
        port = p
        ioManager = SerialInputOutputManager(p, this).also { ioExecutor.submit(it) }
        txtGps.text = "Esperando GPS..."
    }

    private fun disconnect() {
        ioManager?.stop()
        ioManager = null
        runCatching { port?.close() }
        port = null
    }

    // ---------- Datos del GPS (hilo de E/S) ----------

    override fun onNewData(data: ByteArray) {
        val text = String(data, Charsets.US_ASCII)
        synchronized(lineBuffer) {
            lineBuffer.append(text)
            var idx = lineBuffer.indexOf("\n")
            while (idx >= 0) {
                val line = lineBuffer.substring(0, idx).trim()
                lineBuffer.delete(0, idx + 1)
                if (line.isNotEmpty()) handleSentence(line)
                idx = lineBuffer.indexOf("\n")
            }
        }
    }

    override fun onRunError(e: Exception) {
        runOnUiThread {
            txtGps.text = "USB desconectado"
            disconnect()
        }
    }

    private fun handleSentence(line: String) {
        when (val ev = parser.parse(line)) {
            is NmeaEvent.Position -> onPosition(ev)
            is NmeaEvent.Fix -> runOnUiThread {
                sats = ev.sats
                renderGps()
            }
            null -> Unit
        }
    }

    private fun onPosition(ev: NmeaEvent.Position) {
        lastLat = ev.lat
        lastLon = ev.lon
        hasFix = true
        val c = ev.courseDeg
        if (c != null && ev.speedKmh > 1.5) lastCourse = c

        val prev = lastRawMs
        if (prev != null) {
            val d = ev.timeMs - prev
            if (d in 1L..1000L) {
                val inst = 1000.0 / d
                hz = if (hz == 0.0) inst else hz * 0.95 + inst * 0.05
            }
        }
        lastRawMs = ev.timeMs

        val st = engine?.onFix(ev.lat, ev.lon, ev.speedKmh, ev.timeMs)
        runOnUiThread {
            txtSpeed.text = String.format(Locale.US, "%.0f", ev.speedKmh)
            renderGps()
            if (st != null) renderEngine(st)
        }
    }

    // ---------- Pantalla ----------

    private fun renderGps() {
        txtGps.text = if (!hasFix) {
            "GPS sin señal"
        } else {
            String.format(Locale.US, "GPS %.0f Hz · %d sat", hz, sats)
        }
    }

    private fun renderEngine(st: EngineState) {
        txtLap.text = fmtLap(st.currentLapMs)
        txtLast.text = fmtLap(st.lastLapMs)
        txtBest.text = fmtLap(st.bestLapMs)
        txtOpt.text = fmtLap(st.optimalMs)

        val best = st.bestLapMs
        val range = if (best != null) best * DELTA_RANGE_FRACTION / 1000.0 else null
        if (range != null) {
            txtRangeNeg.text = String.format(Locale.US, "-%.2f s", range)
            txtRangePos.text = String.format(Locale.US, "+%.2f s", range)
        } else {
            txtRangeNeg.text = "-2 %"
            txtRangePos.text = "+2 %"
        }

        val d = st.deltaSec
        if (d != null && range != null && range > 0.0) {
            txtDelta.text = String.format(Locale.US, "%+.3f", d)
            txtDelta.setTextColor(if (d <= 0.0) GREEN else RED)
            deltaBar.setRatio((d / range).toFloat())
        } else {
            txtDelta.text = "—.—"
            txtDelta.setTextColor(GREEN)
            deltaBar.setRatio(0f)
        }

        if (reconName == null) {
            val name = circuit?.name ?: ""
            txtTop.text = if (st.running) {
                "Vuelta ${st.lapNumber} · S${st.sector}/${st.sectorCount} · $name"
            } else {
                "$name · cruza la meta para empezar"
            }
        }
    }

    private fun resetDisplay() {
        txtLap.text = "--:--.---"
        txtLast.text = "--:--.---"
        txtBest.text = "--:--.---"
        txtOpt.text = "--:--.---"
        txtDelta.text = "—.—"
        txtDelta.setTextColor(GREEN)
        deltaBar.setRatio(0f)
        txtRangeNeg.text = "-2 %"
        txtRangePos.text = "+2 %"
    }

    private fun refreshTop() {
        val name = reconName
        txtTop.text = when {
            name != null -> "Reconocimiento «$name» · meta ${if (draftFinish != null) "✔" else "—"} · sectores ${draftSectors.size}"
            circuit == null -> "Sin circuito · pulsa CIRCUITO"
            else -> "${circuit?.name} · cruza la meta para empezar"
        }
    }

    private fun fmtLap(ms: Long?): String {
        if (ms == null) return "--:--.---"
        val min = ms / 60_000
        val sec = (ms % 60_000) / 1000
        val milli = ms % 1000
        return String.format(Locale.US, "%d:%02d.%03d", min, sec, milli)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // ---------- Menú de circuitos ----------

    private fun showMenu() {
        val items = arrayOf("Nuevo circuito (reconocimiento)", "Elegir circuito", "Borrar circuito")
        AlertDialog.Builder(this)
            .setTitle("Circuito")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> askName()
                    1 -> chooseCircuit()
                    2 -> deleteCircuit()
                }
            }
            .show()
    }

    private fun askName() {
        val input = EditText(this)
        input.hint = "Nombre del circuito"
        AlertDialog.Builder(this)
            .setTitle("Nuevo circuito")
            .setView(input)
            .setPositiveButton("Empezar") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) startRecon(n)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun chooseCircuit() {
        val list = store.list()
        if (list.isEmpty()) {
            toast("No hay circuitos guardados")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Elegir circuito")
            .setItems(list.map { it.name }.toTypedArray()) { _, i -> selectCircuit(list[i]) }
            .show()
    }

    private fun deleteCircuit() {
        val list = store.list()
        if (list.isEmpty()) {
            toast("No hay circuitos guardados")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Borrar circuito")
            .setItems(list.map { it.name }.toTypedArray()) { _, i ->
                val c = list[i]
                store.delete(c.name)
                if (circuit?.name == c.name) {
                    circuit = null
                    engine = null
                    store.activeName = null
                    resetDisplay()
                }
                refreshTop()
                toast("Circuito borrado")
            }
            .show()
    }

    private fun selectCircuit(c: Circuit) {
        circuit = c
        engine = LapEngine(c)
        store.activeName = c.name
        resetDisplay()
        refreshTop()
    }

    // ---------- Reconocimiento de circuito ----------

    private fun startRecon(name: String) {
        reconName = name
        draftFinish = null
        draftSectors.clear()
        bannerPit.visibility = View.GONE
        reconBar.visibility = View.VISIBLE
        refreshTop()
    }

    private fun exitRecon() {
        reconName = null
        draftFinish = null
        draftSectors.clear()
        reconBar.visibility = View.GONE
        bannerPit.visibility = View.VISIBLE
        refreshTop()
    }

    private fun currentPoint(): GatePoint? {
        val course = lastCourse
        if (!hasFix || course == null) {
            toast("Aún no hay rumbo: avanza o camina unos segundos")
            return null
        }
        return GatePoint(lastLat, lastLon, course)
    }

    private fun markFinish() {
        val p = currentPoint() ?: return
        draftFinish = p
        refreshTop()
        toast("Meta marcada")
    }

    private fun markSector() {
        if (draftFinish == null) {
            toast("Marca primero la meta")
            return
        }
        val p = currentPoint() ?: return
        draftSectors.add(p)
        refreshTop()
        toast("Sector marcado")
    }

    private fun saveCircuit() {
        val name = reconName ?: return
        val finish = draftFinish
        if (finish == null) {
            toast("Marca primero la meta")
            return
        }
        val c = Circuit(name, finish, draftSectors.toList())
        store.save(c)
        exitRecon()
        selectCircuit(c)
        toast("Circuito guardado: ${c.sectorCount} sectores")
    }
}
