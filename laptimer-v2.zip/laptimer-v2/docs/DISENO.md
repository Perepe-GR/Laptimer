# Diseño de la pantalla del piloto (horizontal)

## Colores (aprobados, no cambiar)
- Fondo: `#0B0D10`
- Tarjetas: `#12161B`, esquinas de 16 dp
- Verde acento: `#C6F432` (más rápido, mejor vuelta)
- Rojo (más lento): `#FF5A5F`
- Texto secundario: `#9AA3AE`
- Ámbar (mensajes del pit, versión futura): `#F5A524`

## Jerarquía
1. **Delta** (protagonista): tarjeta grande a la izquierda, cifras de hasta 150 sp, barra debajo.
   - La barra cubre ±2 % de la mejor vuelta; las etiquetas de los extremos muestran ese rango en segundos.
   - Negativo (más rápido): relleno a la izquierda en verde. Positivo: a la derecha en rojo.
2. **Tiempo de vuelta**: tarjeta a la derecha arriba.
3. **Mejor / Última / Óptima**: tres tarjetas pequeñas en fila.
4. **Velocidad**: tarjeta pequeña, texto gris claro, secundaria a propósito.
5. **Banda inferior**: mensajes del pit crew (por ahora "Sin mensajes del pit"); durante el
   reconocimiento de circuito se sustituye por los botones de marcado.

## Tipografía
`sans-serif-condensed`, negrita, cifras grandes. Etiquetas de 12–13 sp con espaciado de letras 0,1.
