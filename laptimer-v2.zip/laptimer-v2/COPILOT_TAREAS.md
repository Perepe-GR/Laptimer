# Tareas listas para pegar en GitHub Copilot

Usa el chat de Copilot en github.com (abre el repositorio y pulsa el icono de Copilot),
o, si tu plan incluye el agente de código, crea un Issue y asígnaselo a Copilot.

## 1. Si falla la compilación
> Revisa la última ejecución fallida del workflow "Build APK" de este repositorio. Lee el log del paso
> "Compilar APK", corrige solo lo necesario en el código y abre un Pull Request en español.
> Respeta .github/copilot-instructions.md.

Con el chat normal (sin agente), pega el error del log así:
> Este es el error de compilación del proyecto Android. Dime qué archivo y qué líneas cambiar y dame el código corregido: [pega aquí el error]

## 2. Ajuste visual
> Cambia [lo que quieras] en res/layout/activity_main.xml manteniendo los colores y la jerarquía de docs/DISENO.md.

## 3. Siguiente versión (cuando la 0.2 funcione)
Mensajes del pit crew por 4G/5G: la banda inferior ya está reservada. Requiere Firebase o MQTT,
una pequeña app web para el equipo y la suscripción en la app del piloto.
