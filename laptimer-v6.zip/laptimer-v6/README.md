# Lap Timer · versión 0.6

Cronómetro propio para antena GPS u-blox de 25 Hz por USB. Actualización paso a paso en `LEEME-INSTALACION.md`.

## Novedades de la 0.6
- **Menú de inicio** antes de las vueltas: iniciar sesión, modo demo, circuitos, historial, ajustes y pit crew,
  con el estado del circuito activo, la antena y el pit.
- **Dos vistas** en la sesión: completa y simplificada (delta gigante + sectores F1). Se cambia deslizando a
  izquierda o derecha desde el centro.
- **Barra superior oculta**: se muestra deslizando hacia abajo desde la parte alta, y se esconde a los 5 s.
- **Banda de mensajes oculta** si no hay mensajes. Cada mensaje trae su color y dura el sector en que llega y el
  siguiente (si llega en el último, hasta el final del sector 1 de la vuelta siguiente; si llega sin vuelta en curso,
  hasta cruzar 2 sectores tras empezar). Tope de seguridad de 10 minutos.
- **Delta a 5 Hz**: se muestra la media de cada ventana de 200 ms (el cálculo interno sigue a 25 Hz).
- **Velocidad** reducida a una tarjeta compacta y gris.
- **Panel del pit**: mapa al final, mensajes predeterminados con color (BOX, TODO OK, CUIDADO, SAFETY CAR,
  PISTA DESLIZANTE, SERÁS DOBLADO, PILOTOS DELANTE DOBLADOS) y mensaje personalizado con selector de color
  (amarillo, verde, rojo, azul, blanco y rayas rojas y amarillas).
- **Firma fija** del APK: desde la 0.6 las actualizaciones se instalan encima sin perder datos.

## Ajustes en el código
`LapEngine.kt`: `GATE_HALF_WIDTH_M`, `MIN_LAP_MS`. `MainActivity.kt`: `DELTA_RANGE_FRACTION`, `DELTA_UI_MS` (200),
`LOCK_KMH` (10), `MSG_SECTORS` (2), `MSG_MAX_MS` (10 min), `TOPBAR_MS` (5 s), `AUTOLOAD_M` (3000 m).
