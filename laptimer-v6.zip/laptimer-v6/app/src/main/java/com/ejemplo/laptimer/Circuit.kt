package com.ejemplo.laptimer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Punto de paso (meta o sector) con el rumbo de marcha en ese punto. */
data class GatePoint(val lat: Double, val lon: Double, val headingDeg: Double)

/**
 * Un circuito: meta + puntos de sector.
 * n puntos de sector = n + 1 sectores (el último termina en la meta).
 */
data class Circuit(
    val name: String,
    val finish: GatePoint,
    val sectors: List<GatePoint>
) {
    val sectorCount: Int get() = sectors.size + 1

    fun signature(): String = toJson().hashCode().toString()

    fun toJson(): String {
        val o = JSONObject()
        o.put("nombre", name)
        o.put("meta", pointToJson(finish))
        val arr = JSONArray()
        for (p in sectors) arr.put(pointToJson(p))
        o.put("sectores", arr)
        return o.toString(2)
    }

    companion object {
        private fun pointToJson(p: GatePoint): JSONObject {
            val o = JSONObject()
            o.put("lat", p.lat)
            o.put("lon", p.lon)
            o.put("rumbo", p.headingDeg)
            return o
        }

        private fun pointFromJson(o: JSONObject): GatePoint =
            GatePoint(o.getDouble("lat"), o.getDouble("lon"), o.getDouble("rumbo"))

        fun fromJson(text: String): Circuit {
            val o = JSONObject(text)
            val arr = o.optJSONArray("sectores") ?: JSONArray()
            val list = ArrayList<GatePoint>()
            for (i in 0 until arr.length()) list.add(pointFromJson(arr.getJSONObject(i)))
            return Circuit(o.getString("nombre"), pointFromJson(o.getJSONObject("meta")), list)
        }
    }
}

/** Guarda los circuitos como archivos JSON en el almacenamiento privado de la app. */
class CircuitStore(context: Context) {
    private val dir = File(context.filesDir, "circuits").apply { mkdirs() }
    private val prefs = context.getSharedPreferences("laptimer", Context.MODE_PRIVATE)

    private fun fileFor(name: String) =
        File(dir, name.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".json")

    fun save(c: Circuit) {
        fileFor(c.name).writeText(c.toJson())
    }

    fun delete(name: String) {
        fileFor(name).delete()
    }

    fun list(): List<Circuit> {
        val files = dir.listFiles() ?: return emptyList()
        return files
            .filter { it.extension == "json" }
            .mapNotNull { f -> runCatching { Circuit.fromJson(f.readText()) }.getOrNull() }
            .sortedBy { it.name.lowercase() }
    }

    /** Circuito guardado más cercano a (lat, lon) dentro de maxM metros, o null. */
    fun nearest(lat: Double, lon: Double, maxM: Double): Circuit? {
        var best: Circuit? = null
        var bestD = maxM
        for (c in list()) {
            val d = distanceM(lat, lon, c.finish.lat, c.finish.lon)
            if (d < bestD) {
                bestD = d
                best = c
            }
        }
        return best
    }

    fun saveLastPosition(lat: Double, lon: Double) {
        prefs.edit().putString("lastLat", lat.toString()).putString("lastLon", lon.toString()).apply()
    }

    fun lastPosition(): Pair<Double, Double>? {
        val a = prefs.getString("lastLat", null)?.toDoubleOrNull() ?: return null
        val b = prefs.getString("lastLon", null)?.toDoubleOrNull() ?: return null
        return Pair(a, b)
    }

    var activeName: String?
        get() = prefs.getString("activo", null)
        set(value) {
            prefs.edit().putString("activo", value).apply()
        }

    fun loadActive(): Circuit? {
        val n = activeName ?: return null
        return list().firstOrNull { it.name == n }
    }
}
