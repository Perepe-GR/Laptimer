package com.ejemplo.laptimer

import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** Ajustes de red y sesión guardados en el móvil. */
class NetSettings(context: Context) {
    private val p = context.getSharedPreferences("laptimer_net", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = p.getBoolean("enabled", false)
        set(v) {
            p.edit().putBoolean("enabled", v).apply()
        }

    var dbUrl: String
        get() = p.getString("db", "") ?: ""
        set(v) {
            p.edit().putString("db", v.trim().trimEnd('/')).apply()
        }

    var room: String
        get() = p.getString("room", "") ?: ""
        set(v) {
            p.edit().putString("room", v.trim().uppercase()).apply()
        }

    var intervalS: Int
        get() = p.getInt("interval", 10)
        set(v) {
            p.edit().putInt("interval", v.coerceAtLeast(10)).apply()
        }

    var panelUrl: String
        get() = p.getString("panel", "") ?: ""
        set(v) {
            p.edit().putString("panel", v.trim()).apply()
        }

    var saveTrace: Boolean
        get() = p.getBoolean("trace", true)
        set(v) {
            p.edit().putBoolean("trace", v).apply()
        }

    fun ensureRoom(): String {
        var r = room
        if (r.isBlank()) {
            r = newCode()
            room = r
        }
        return r
    }

    companion object {
        fun newCode(): String {
            val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            val rnd = SecureRandom()
            val sb = StringBuilder()
            for (i in 0 until 10) sb.append(alphabet[rnd.nextInt(alphabet.length)])
            return sb.toString()
        }
    }
}

class PitMessage(val key: String, val text: String, val bg: String)

enum class NetStatus { OFF, OK, ERROR }

/**
 * Conexión con Firebase Realtime Database por su API REST (sin SDK, solo la URL de la base de datos).
 *
 * Para ahorrar batería hace un único intercambio cada `intervalS` segundos (mínimo 10):
 *  - sube la telemetría ("live") y las vueltas terminadas ("laps"),
 *  - baja los mensajes nuevos del pit ("msgs").
 * No usa conexión permanente. Los mensajes del pit llegan como mucho con ese retraso.
 */
class FirebaseRestLink(
    private val settings: NetSettings,
    private val telemetry: () -> String?,
    private val onMessages: (List<PitMessage>) -> Unit,
    private val onStatus: (NetStatus) -> Unit
) {
    private var exec: ScheduledExecutorService? = null
    private val pendingLaps = ConcurrentLinkedQueue<String>()
    private var lastKey: String? = null
    private var first = true

    fun enqueueLap(json: String) {
        pendingLaps.add(json)
        while (pendingLaps.size > 200) pendingLaps.poll()
    }

    fun start() {
        stop()
        if (!settings.enabled || settings.dbUrl.isBlank() || settings.room.isBlank()) {
            onStatus(NetStatus.OFF)
            return
        }
        first = true
        lastKey = null
        val e = Executors.newSingleThreadScheduledExecutor()
        exec = e
        val period = settings.intervalS.toLong().coerceAtLeast(10L)
        e.scheduleWithFixedDelay({ cycle() }, 0L, period, TimeUnit.SECONDS)
    }

    fun stop() {
        exec?.shutdownNow()
        exec = null
    }

    private fun cycle() {
        try {
            val t = telemetry()
            if (t != null) request("PUT", "live", t, "")
            while (true) {
                val lap = pendingLaps.peek() ?: break
                request("POST", "laps", lap, "")
                pendingLaps.poll()
            }
            fetchMessages()
            onStatus(NetStatus.OK)
        } catch (e: Exception) {
            onStatus(NetStatus.ERROR)
        }
    }

    private fun fetchMessages() {
        val txt = request("GET", "msgs", null, "?orderBy=%22%24key%22&limitToLast=5").trim()
        val keys: List<String>
        var o: JSONObject? = null
        if (txt.isEmpty() || txt == "null") {
            keys = emptyList()
        } else {
            val obj = JSONObject(txt)
            o = obj
            val list = ArrayList<String>()
            val it = obj.keys()
            while (it.hasNext()) list.add(it.next())
            list.sort()
            keys = list
        }
        if (first) {
            lastKey = keys.lastOrNull()
            first = false
            return
        }
        val seen = lastKey
        val fresh = keys.filter { seen == null || it > seen }
        if (fresh.isEmpty() || o == null) return
        lastKey = fresh.last()
        val msgs = ArrayList<PitMessage>()
        for (k in fresh) {
            val text = o.getJSONObject(k).optString("text", "")
            val bg = o.getJSONObject(k).optString("bg", "amarillo")
            if (text.isNotBlank()) msgs.add(PitMessage(k, text, bg))
        }
        if (msgs.isNotEmpty()) onMessages(msgs)
    }

    private fun request(method: String, path: String, body: String?, query: String): String {
        val url = URL(settings.dbUrl + "/rooms/" + settings.room + "/" + path + ".json" + query)
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 6000
            c.readTimeout = 6000
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code")
            return text
        } finally {
            c.disconnect()
        }
    }
}
