package com.ejemplo.laptimer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/** Mejores marcas históricas de un circuito (Long.MAX_VALUE = sin dato). */
class CircuitStats(val signature: String, val bestLapMs: Long?, val bestSectors: LongArray)

class Persisted(val stats: CircuitStats, val ref: List<RefSample>?)

/**
 * Guarda por circuito la mejor vuelta, los mejores sectores y la traza de la mejor vuelta
 * (referencia del delta). Si el circuito cambia (firma distinta) los datos se ignoran.
 */
class StatsStore(context: Context) {
    private val dir = File(context.filesDir, "stats").apply { mkdirs() }

    private fun key(name: String) = name.replace(Regex("[^A-Za-z0-9_-]"), "_")
    private fun jsonFile(name: String) = File(dir, key(name) + ".json")
    private fun refFile(name: String) = File(dir, key(name) + ".ref")

    fun save(c: Circuit, stats: CircuitStats, ref: List<RefSample>?) {
        try {
            val o = JSONObject()
            o.put("firma", stats.signature)
            val best = stats.bestLapMs
            if (best != null) o.put("mejor", best)
            val arr = JSONArray()
            for (v in stats.bestSectors) arr.put(if (v == Long.MAX_VALUE) -1L else v)
            o.put("sectores", arr)
            jsonFile(c.name).writeText(o.toString())
            if (ref != null) {
                DataOutputStream(BufferedOutputStream(FileOutputStream(refFile(c.name)))).use { out ->
                    out.writeInt(ref.size)
                    for (s in ref) {
                        out.writeInt(s.t.toInt())
                        out.writeFloat(s.x.toFloat())
                        out.writeFloat(s.y.toFloat())
                    }
                }
            }
        } catch (e: Exception) {
            // sin almacenamiento disponible: se ignora
        }
    }

    fun load(c: Circuit): Persisted? {
        try {
            val f = jsonFile(c.name)
            if (!f.exists()) return null
            val o = JSONObject(f.readText())
            if (o.optString("firma") != c.signature()) return null
            val arr = o.getJSONArray("sectores")
            val sec = LongArray(arr.length())
            for (i in 0 until arr.length()) {
                val v = arr.getLong(i)
                sec[i] = if (v < 0) Long.MAX_VALUE else v
            }
            val best: Long? = if (o.has("mejor")) o.getLong("mejor") else null
            val stats = CircuitStats(c.signature(), best, sec)
            var ref: List<RefSample>? = null
            val rf = refFile(c.name)
            if (rf.exists()) {
                DataInputStream(BufferedInputStream(FileInputStream(rf))).use { inp ->
                    val n = inp.readInt()
                    val list = ArrayList<RefSample>(n)
                    for (i in 0 until n) {
                        val t = inp.readInt().toLong()
                        val x = inp.readFloat().toDouble()
                        val y = inp.readFloat().toDouble()
                        list.add(RefSample(t, x, y))
                    }
                    ref = list
                }
            }
            return Persisted(stats, ref)
        } catch (e: Exception) {
            return null
        }
    }

    fun clear(name: String) {
        jsonFile(name).delete()
        refFile(name).delete()
    }
}
