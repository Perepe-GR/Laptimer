package com.ejemplo.laptimer

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polyline
import java.io.File

/**
 * Editor de circuitos sobre OpenStreetMap: se toca el mapa para colocar la meta y los sectores,
 * se arrastran los puntos para moverlos y se fija el sentido de marcha con un segundo toque.
 * El orden en que se añaden los sectores es el orden de paso.
 */
class MapEditorActivity : AppCompatActivity() {

    private enum class Mode { IDLE, FINISH_POS, FINISH_DIR, SECTOR_POS, SECTOR_DIR, SET_DIR }

    private lateinit var map: MapView
    private lateinit var hint: TextView
    private lateinit var store: CircuitStore
    private var name = ""
    private val points = ArrayList<GatePoint>() // 0 = meta, 1.. = sectores en orden de paso
    private var selected = -1
    private var mode = Mode.IDLE
    private var pending: GeoPoint? = null
    private var gpsLat = Double.NaN
    private var gpsLon = Double.NaN
    private val dynamic = ArrayList<Overlay>()
    private val density get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, getSharedPreferences("osm", MODE_PRIVATE))
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(cacheDir, "osmdroid")
        cfg.osmdroidTileCache = File(cacheDir, "osmdroid/tiles")

        store = CircuitStore(this)
        name = intent.getStringExtra("name") ?: "Circuito"
        val isNew = intent.getBooleanExtra("new", false)
        gpsLat = intent.getDoubleExtra("lat", Double.NaN)
        gpsLon = intent.getDoubleExtra("lon", Double.NaN)
        if (!isNew) {
            val c = store.list().firstOrNull { it.name == name }
            if (c != null) {
                points.add(c.finish)
                points.addAll(c.sectors)
            }
        }

        val root = FrameLayout(this)
        map = MapView(this)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        root.addView(map, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        hint = TextView(this)
        hint.setBackgroundColor(0xCC0B0D10.toInt())
        hint.setTextColor(Color.WHITE)
        hint.textSize = 13f
        val pad = (8 * density).toInt()
        hint.setPadding(pad * 2, pad, pad * 2, pad)
        root.addView(
            hint,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
        )

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(0xCC0B0D10.toInt())
        fun addButton(text: String, action: () -> Unit) {
            val b = Button(this)
            b.text = text
            b.textSize = 11f
            b.setOnClickListener { action() }
            bar.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        addButton("+ META") { mode = Mode.FINISH_POS; pending = null; updateHint() }
        addButton("+ SECTOR") {
            if (points.isEmpty()) toast("Primero coloca la meta")
            else { mode = Mode.SECTOR_POS; pending = null; updateHint() }
        }
        addButton("SENTIDO") {
            if (selected !in points.indices) toast("Toca primero un punto del mapa")
            else { mode = Mode.SET_DIR; updateHint() }
        }
        addButton("BORRAR") {
            if (selected in points.indices) {
                points.removeAt(selected)
                selected = -1
                redraw()
                updateHint()
            } else toast("Toca primero un punto del mapa")
        }
        addButton("MI POSICIÓN") {
            if (gpsLat.isNaN()) toast("Sin posición GPS todavía")
            else map.controller.animateTo(GeoPoint(gpsLat, gpsLon))
        }
        addButton("GUARDAR") { save() }
        addButton("SALIR") { finish() }
        root.addView(
            bar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        )
        setContentView(root)

        val receiver = object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                onTap(p)
                return true
            }

            override fun longPressHelper(p: GeoPoint): Boolean = false
        }
        map.overlays.add(MapEventsOverlay(receiver))

        when {
            points.isNotEmpty() -> {
                map.controller.setZoom(17.0)
                map.controller.setCenter(GeoPoint(points[0].lat, points[0].lon))
            }
            !gpsLat.isNaN() -> {
                map.controller.setZoom(17.0)
                map.controller.setCenter(GeoPoint(gpsLat, gpsLon))
            }
            else -> {
                map.controller.setZoom(6.0)
                map.controller.setCenter(GeoPoint(40.4, -3.7))
            }
        }
        redraw()
        updateHint()
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
    }

    override fun onPause() {
        map.onPause()
        super.onPause()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun updateHint() {
        hint.text = when (mode) {
            Mode.IDLE -> "«$name» · Toca + META o + SECTOR. Arrastra un punto para moverlo; toca un punto y SENTIDO para girarlo. Los sectores se numeran en el orden en que los añades."
            Mode.FINISH_POS -> "Toca el mapa donde está la línea de META."
            Mode.SECTOR_POS -> "Toca el mapa donde está el sector."
            Mode.FINISH_DIR, Mode.SECTOR_DIR, Mode.SET_DIR -> "Ahora toca un punto hacia donde avanzas (sentido de marcha)."
        }
    }

    private fun onTap(p: GeoPoint) {
        when (mode) {
            Mode.FINISH_POS -> {
                pending = p
                mode = Mode.FINISH_DIR
            }
            Mode.SECTOR_POS -> {
                pending = p
                mode = Mode.SECTOR_DIR
            }
            Mode.FINISH_DIR, Mode.SECTOR_DIR -> {
                val a = pending
                if (a != null) {
                    val h = bearingDeg(a.latitude, a.longitude, p.latitude, p.longitude)
                    val gp = GatePoint(a.latitude, a.longitude, h)
                    if (mode == Mode.FINISH_DIR) {
                        if (points.isEmpty()) points.add(gp) else points[0] = gp
                        selected = 0
                    } else {
                        points.add(gp)
                        selected = points.size - 1
                    }
                }
                pending = null
                mode = Mode.IDLE
            }
            Mode.SET_DIR -> {
                if (selected in points.indices) {
                    val s = points[selected]
                    points[selected] = s.copy(headingDeg = bearingDeg(s.lat, s.lon, p.latitude, p.longitude))
                }
                mode = Mode.IDLE
            }
            Mode.IDLE -> selected = -1
        }
        redraw()
        updateHint()
    }

    private fun addLine(a: GeoPoint, b: GeoPoint, color: Int, width: Float) {
        val pl = Polyline(map)
        pl.setPoints(listOf(a, b))
        pl.outlinePaint.color = color
        pl.outlinePaint.strokeWidth = width
        dynamic.add(pl)
        map.overlays.add(pl)
    }

    private fun redraw() {
        map.overlays.removeAll(dynamic)
        dynamic.clear()

        for (i in points.indices) {
            val p = points[i]
            val f = LocalFrame(p.lat, p.lon)
            val h = Math.toRadians(p.headingDeg)
            val dx = Math.sin(h)
            val dy = Math.cos(h)
            val accent = if (i == 0) 0xFFC6F432.toInt() else 0xFFF5A524.toInt()

            // Línea de paso (±15 m, perpendicular al rumbo) y flecha del sentido de marcha
            val px = -dy * LapEngine.GATE_HALF_WIDTH_M
            val py = dx * LapEngine.GATE_HALF_WIDTH_M
            addLine(
                GeoPoint(f.lat(py), f.lon(px)),
                GeoPoint(f.lat(-py), f.lon(-px)),
                accent, 6f * density
            )
            addLine(
                GeoPoint(p.lat, p.lon),
                GeoPoint(f.lat(30.0 * dy), f.lon(30.0 * dx)),
                if (i == selected) Color.WHITE else 0xFFB8C0CC.toInt(), 3f * density
            )

            val m = Marker(map)
            m.position = GeoPoint(p.lat, p.lon)
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            m.icon = labelIcon(if (i == 0) "M" else i.toString(), i == selected, i == 0)
            m.isDraggable = true
            m.setOnMarkerClickListener { _, _ ->
                selected = i
                mode = Mode.IDLE
                map.post { redraw(); updateHint() }
                true
            }
            m.setOnMarkerDragListener(object : Marker.OnMarkerDragListener {
                override fun onMarkerDrag(marker: Marker?) {}
                override fun onMarkerDragStart(marker: Marker?) {}
                override fun onMarkerDragEnd(marker: Marker?) {
                    val mp = marker?.position ?: return
                    if (i in points.indices) {
                        points[i] = points[i].copy(lat = mp.latitude, lon = mp.longitude)
                    }
                    map.post { redraw() }
                }
            })
            dynamic.add(m)
            map.overlays.add(m)
        }

        val pd = pending
        if (pd != null) {
            val m = Marker(map)
            m.position = pd
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            m.icon = labelIcon("?", true, false)
            dynamic.add(m)
            map.overlays.add(m)
        }
        map.invalidate()
    }

    private fun labelIcon(text: String, isSelected: Boolean, finish: Boolean): Drawable {
        val s = (36 * density).toInt()
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val accent = if (finish) 0xFFC6F432.toInt() else 0xFFF5A524.toInt()
        p.color = if (isSelected) Color.WHITE else accent
        c.drawCircle(s / 2f, s / 2f, s / 2f, p)
        p.color = 0xFF0B0D10.toInt()
        c.drawCircle(s / 2f, s / 2f, s / 2f - 3f * density, p)
        p.color = accent
        p.textSize = s * 0.5f
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        c.drawText(text, s / 2f, s / 2f + p.textSize * 0.35f, p)
        return BitmapDrawable(resources, bmp)
    }

    private fun save() {
        if (points.isEmpty()) {
            toast("Coloca al menos la meta")
            return
        }
        val c = Circuit(name, points[0], points.drop(1))
        store.save(c)
        store.activeName = name
        toast("Circuito guardado: ${c.sectorCount} sectores")
        finish()
    }
}
