package com.ejemplo.laptimer

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.net.URLEncoder

/** Menú de inicio: se abre antes de las pantallas de vueltas. */
class HomeActivity : AppCompatActivity() {

    private lateinit var store: CircuitStore
    private lateinit var statsStore: StatsStore
    private lateinit var settings: NetSettings
    private lateinit var txtCircuit: TextView
    private lateinit var txtAntenna: TextView
    private lateinit var txtPit: TextView

    private val muted = Color.parseColor("#9AA3AE")
    private val lime = Color.parseColor("#C6F432")

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importCircuit(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        store = CircuitStore(this)
        statsStore = StatsStore(this)
        settings = NetSettings(this)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun roundBg(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun menuButton(text: String, primary: Boolean, action: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.gravity = Gravity.CENTER
        b.textSize = if (primary) 22f else 17f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(if (primary) Color.parseColor("#0B0D10") else Color.WHITE)
        b.background = roundBg(if (primary) lime else Color.parseColor("#12161B"), 16)
        b.isClickable = true
        b.setOnClickListener { action() }
        return b
    }

    private fun statusLine(): TextView {
        val t = TextView(this)
        t.textSize = 15f
        t.setTextColor(muted)
        t.setPadding(0, dp(8), 0, 0)
        return t
    }

    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(Color.parseColor("#0B0D10"))
        root.setPadding(dp(16), dp(12), dp(16), dp(12))

        // Izquierda: identidad, estado e INICIAR SESIÓN
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.background = roundBg(Color.parseColor("#12161B"), 16)
        left.setPadding(dp(20), dp(16), dp(20), dp(16))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.mipmap.ic_launcher)
        head.addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)))
        val title = TextView(this)
        title.text = "Lap Timer  0.6"
        title.textSize = 24f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.setPadding(dp(12), 0, 0, 0)
        head.addView(title)
        left.addView(head)

        txtCircuit = statusLine()
        txtAntenna = statusLine()
        txtPit = statusLine()
        left.addView(txtCircuit)
        left.addView(txtAntenna)
        left.addView(txtPit)

        left.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        left.addView(
            menuButton("INICIAR SESIÓN", true) {
                startActivity(Intent(this, MainActivity::class.java))
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(72))
        )
        root.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        // Derecha: resto de funciones
        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        fun add(text: String, action: () -> Unit) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            if (right.childCount > 0) lp.topMargin = dp(10)
            right.addView(menuButton(text, false, action), lp)
        }
        add("MODO DEMO") {
            val i = Intent(this, MainActivity::class.java)
            i.putExtra("demo", true)
            startActivity(i)
        }
        add("CIRCUITOS") { showCircuits() }
        add("HISTORIAL") { startActivity(Intent(this, HistoryActivity::class.java)) }
        add("AJUSTES Y PIT CREW") { showSettings() }
        val rlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        rlp.marginStart = dp(12)
        root.addView(right, rlp)
        return root
    }

    private fun refreshStatus() {
        val c = store.loadActive()
        txtCircuit.text = "Circuito activo: " + (c?.name ?: "ninguno")
        val usb = getSystemService(Context.USB_SERVICE) as UsbManager
        val has = UsbSerialProber.getDefaultProber().findAllDrivers(usb).isNotEmpty()
        txtAntenna.text = "Antena USB: " + (if (has) "detectada" else "no detectada")
        txtAntenna.setTextColor(if (has) lime else muted)
        txtPit.text = if (settings.enabled) {
            "Pit crew: activado · sala " + settings.room
        } else {
            "Pit crew: desactivado"
        }
    }

    // ---------- Circuitos ----------

    private fun showCircuits() {
        val items = arrayOf(
            "Elegir circuito",
            "Nuevo circuito en el mapa",
            "Editar circuito en el mapa",
            "Nuevo circuito por reconocimiento",
            "Borrar circuito",
            "Importar circuito",
            "Exportar circuito"
        )
        AlertDialog.Builder(this)
            .setTitle("Circuitos")
            .setItems(items) { _, w ->
                when (w) {
                    0 -> chooseCircuit()
                    1 -> askName(true)
                    2 -> editOnMap()
                    3 -> askName(false)
                    4 -> deleteCircuit()
                    5 -> importLauncher.launch(arrayOf("*/*"))
                    6 -> exportCircuit()
                    else -> Unit
                }
            }
            .show()
    }

    private fun askName(onMap: Boolean) {
        val input = EditText(this)
        input.hint = "Nombre del circuito"
        AlertDialog.Builder(this)
            .setTitle(if (onMap) "Nuevo circuito en el mapa" else "Nuevo circuito por reconocimiento")
            .setView(input)
            .setPositiveButton("Empezar") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty()) {
                    if (onMap) openMapEditor(n, true) else startRecon(n)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun startRecon(name: String) {
        val i = Intent(this, MainActivity::class.java)
        i.putExtra("recon", name)
        startActivity(i)
    }

    private fun chooseCircuit() {
        val list = store.list()
        if (list.isEmpty()) {
            toast("No hay circuitos guardados")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Elegir circuito")
            .setItems(list.map { it.name }.toTypedArray()) { _, i ->
                store.activeName = list[i].name
                refreshStatus()
                toast("Circuito activo: ${list[i].name}")
            }
            .show()
    }

    private fun deleteCircuit() {
        val list = store.list()
        if (list.isEmpty()) {
            toast("No hay circuitos guardados")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Borrar circuito")
            .setItems(list.map { it.name }.toTypedArray()) { _, i ->
                val c = list[i]
                store.delete(c.name)
                statsStore.clear(c.name)
                if (store.activeName == c.name) store.activeName = null
                refreshStatus()
                toast("Circuito borrado")
            }
            .show()
    }

    private fun openMapEditor(name: String, isNew: Boolean) {
        val i = Intent(this, MapEditorActivity::class.java)
        i.putExtra("name", name)
        i.putExtra("new", isNew)
        val pos = store.lastPosition()
        if (pos != null) {
            i.putExtra("lat", pos.first)
            i.putExtra("lon", pos.second)
        }
        startActivity(i)
    }

    private fun editOnMap() {
        val c = store.loadActive()
        if (c == null) {
            toast("No hay circuito activo")
            return
        }
        openMapEditor(c.name, false)
    }

    private fun exportCircuit() {
        val c = store.loadActive()
        if (c == null) {
            toast("No hay circuito activo")
            return
        }
        Export.share(this, c.name + ".json", c.toJson(), "application/json")
    }

    private fun importCircuit(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: throw IllegalStateException("archivo vacío")
            val c = Circuit.fromJson(text)
            store.save(c)
            store.activeName = c.name
            refreshStatus()
            toast("Circuito importado: ${c.name}")
        } catch (e: Exception) {
            toast("No se pudo importar: ${e.message}")
        }
    }

    // ---------- Ajustes y pit crew ----------

    private fun showSettings() {
        val pad = dp(16)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 2, pad, 0)

        fun label(t: String): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = 12f
            v.setTextColor(muted)
            v.setPadding(0, dp(10), 0, 0)
            return v
        }

        val swEnabled = CheckBox(this)
        swEnabled.text = "Activar conexión con el pit"
        swEnabled.isChecked = settings.enabled

        val etDb = EditText(this)
        etDb.hint = "https://tu-proyecto-default-rtdb.firebaseio.com"
        etDb.setText(settings.dbUrl)
        etDb.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI

        val etRoom = EditText(this)
        etRoom.setText(settings.ensureRoom())
        etRoom.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS

        val btnNew = Button(this)
        btnNew.text = "Generar código nuevo"
        btnNew.setOnClickListener { etRoom.setText(NetSettings.newCode()) }

        val etInt = EditText(this)
        etInt.inputType = InputType.TYPE_CLASS_NUMBER
        etInt.setText(settings.intervalS.toString())

        val etPanel = EditText(this)
        etPanel.hint = "https://usuario.github.io/panel-pit/"
        etPanel.setText(settings.panelUrl)
        etPanel.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI

        val swTrace = CheckBox(this)
        swTrace.text = "Guardar la traza GPS completa de las sesiones"
        swTrace.isChecked = settings.saveTrace

        box.addView(swEnabled)
        box.addView(label("URL de Firebase Realtime Database"))
        box.addView(etDb)
        box.addView(label("Código de sala (10 caracteres; el mismo en el panel del pit)"))
        box.addView(etRoom)
        box.addView(btnNew)
        box.addView(label("Intervalo de envío en segundos (mínimo 10; más alto = menos batería)"))
        box.addView(etInt)
        box.addView(label("URL del panel del pit (para compartir el enlace)"))
        box.addView(etPanel)
        box.addView(swTrace)

        fun saveAll() {
            settings.enabled = swEnabled.isChecked
            settings.dbUrl = etDb.text.toString()
            settings.room = etRoom.text.toString()
            settings.intervalS = etInt.text.toString().toIntOrNull() ?: 10
            settings.panelUrl = etPanel.text.toString()
            settings.saveTrace = swTrace.isChecked
            refreshStatus()
        }

        val scroll = ScrollView(this)
        scroll.addView(box)
        AlertDialog.Builder(this)
            .setTitle("Ajustes y pit crew")
            .setView(scroll)
            .setPositiveButton("Guardar") { _, _ -> saveAll() }
            .setNeutralButton("Compartir enlace del pit") { _, _ ->
                saveAll()
                shareLink()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun shareLink() {
        val panel = settings.panelUrl
        if (panel.isBlank() || settings.dbUrl.isBlank()) {
            toast("Falta la URL del panel o la de Firebase")
            return
        }
        val sep = if (panel.contains("?")) "&" else "?"
        val url = panel + sep + "db=" + URLEncoder.encode(settings.dbUrl, "UTF-8") +
            "&room=" + settings.room
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, url)
        startActivity(Intent.createChooser(i, "Compartir enlace del pit"))
    }
}
