package com.ejemplo.laptimer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Una vuelta de una sesión. Los offsets son milisegundos desde el inicio de la sesión. */
class LapRecord(
    val number: Int,
    val lapMs: Long,
    val splits: List<Long>,
    val startOffsetMs: Long,
    val endOffsetMs: Long
)

class SessionRecord(
    val id: String,
    val circuitName: String,
    val startEpochMs: Long,
    val sectorCount: Int,
    val laps: MutableList<LapRecord> = ArrayList(),
    var maxSpeedKmh: Double = 0.0,
    var distanceM: Double = 0.0,
    var durationMs: Long = 0L
) {
    fun bestLap(): LapRecord? = laps.minByOrNull { it.lapMs }

    fun toJson(): String {
        val o = JSONObject()
        o.put("id", id)
        o.put("circuito", circuitName)
        o.put("inicio", startEpochMs)
        o.put("sectores", sectorCount)
        o.put("vmax", maxSpeedKmh)
        o.put("dist", distanceM)
        o.put("dur", durationMs)
        val arr = JSONArray()
        for (l in laps) {
            val lo = JSONObject()
            lo.put("n", l.number)
            lo.put("ms", l.lapMs)
            val sp = JSONArray()
            for (s in l.splits) sp.put(s)
            lo.put("s", sp)
            lo.put("a", l.startOffsetMs)
            lo.put("b", l.endOffsetMs)
            arr.put(lo)
        }
        o.put("vueltas", arr)
        return o.toString()
    }

    companion object {
        fun fromJson(text: String): SessionRecord {
            val o = JSONObject(text)
            val r = SessionRecord(
                o.getString("id"), o.getString("circuito"), o.getLong("inicio"), o.getInt("sectores")
            )
            r.maxSpeedKmh = o.optDouble("vmax", 0.0)
            r.distanceM = o.optDouble("dist", 0.0)
            r.durationMs = o.optLong("dur", 0L)
            val arr = o.getJSONArray("vueltas")
            for (i in 0 until arr.length()) {
                val lo = arr.getJSONObject(i)
                val sp = lo.getJSONArray("s")
                val splits = ArrayList<Long>()
                for (k in 0 until sp.length()) splits.add(sp.getLong(k))
                r.laps.add(LapRecord(lo.getInt("n"), lo.getLong("ms"), splits, lo.getLong("a"), lo.getLong("b")))
            }
            return r
        }
    }
}

class SessionStore(context: Context) {
    private val dir = File(context.filesDir, "sessions").apply { mkdirs() }

    private fun jsonFile(id: String) = File(dir, "$id.json")
    fun traceFile(id: String) = File(dir, "$id.trc")

    fun save(r: SessionRecord) {
        try {
            jsonFile(r.id).writeText(r.toJson())
        } catch (e: Exception) {
            // sin almacenamiento: se ignora
        }
    }

    fun delete(id: String) {
        jsonFile(id).delete()
        traceFile(id).delete()
    }

    fun get(id: String): SessionRecord? =
        runCatching { SessionRecord.fromJson(jsonFile(id).readText()) }.getOrNull()

    fun list(): List<SessionRecord> {
        val files = dir.listFiles() ?: return emptyList()
        return files
            .filter { it.extension == "json" }
            .mapNotNull { f -> runCatching { SessionRecord.fromJson(f.readText()) }.getOrNull() }
            .sortedByDescending { it.startEpochMs }
    }
}

/** Traza GPS de una sesión: tiempo (ms desde el inicio), posición y velocidad. */
class Trace(val t: IntArray, val lat: DoubleArray, val lon: DoubleArray, val v: FloatArray) {
    val size: Int get() = t.size
}

/** Escribe la traza en binario compacto: 24 bytes por muestra (unos 2 MB por hora a 25 Hz). */
class TraceWriter(file: File) {
    private val out = DataOutputStream(BufferedOutputStream(FileOutputStream(file, true), 1 shl 16))
    private var count = 0

    fun add(offsetMs: Long, lat: Double, lon: Double, kmh: Float) {
        try {
            out.writeInt(offsetMs.toInt())
            out.writeDouble(lat)
            out.writeDouble(lon)
            out.writeFloat(kmh)
            count++
            if (count % 250 == 0) out.flush()
        } catch (e: Exception) {
            // se ignora
        }
    }

    fun close() {
        try {
            out.flush()
            out.close()
        } catch (e: Exception) {
            // se ignora
        }
    }
}

object TraceReader {
    fun read(file: File): Trace? {
        if (!file.exists()) return null
        val n = (file.length() / 24).toInt()
        if (n < 2) return null
        val t = IntArray(n)
        val la = DoubleArray(n)
        val lo = DoubleArray(n)
        val v = FloatArray(n)
        try {
            DataInputStream(BufferedInputStream(FileInputStream(file), 1 shl 16)).use { inp ->
                for (i in 0 until n) {
                    t[i] = inp.readInt()
                    la[i] = inp.readDouble()
                    lo[i] = inp.readDouble()
                    v[i] = inp.readFloat()
                }
            }
        } catch (e: Exception) {
            return null
        }
        return Trace(t, la, lo, v)
    }
}

/**
 * Graba sesiones automáticamente: empieza al moverse (más de 5 km/h) y termina tras 5 minutos
 * parado, al cambiar de circuito o al cerrar la app. Solo se guardan las que tienen vueltas.
 */
class SessionRecorder(private val store: SessionStore, private val saveTrace: () -> Boolean) {
    private var rec: SessionRecord? = null
    private var writer: TraceWriter? = null
    private var t0 = 0L
    private var lastLat = Double.NaN
    private var lastLon = Double.NaN
    private var stoppedSince = -1L

    /** Devuelve true si con esta muestra ha empezado una sesión nueva. */
    @Synchronized
    fun onSample(circuit: Circuit, gpsT: Long, lat: Double, lon: Double, kmh: Double): Boolean {
        var started = false
        if (rec == null) {
            if (kmh < 5.0) return false
            val id = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            rec = SessionRecord(id, circuit.name, System.currentTimeMillis(), circuit.sectorCount)
            writer = if (saveTrace()) TraceWriter(store.traceFile(id)) else null
            t0 = gpsT
            lastLat = Double.NaN
            lastLon = Double.NaN
            stoppedSince = -1L
            started = true
        }
        val r = rec ?: return started
        val off = gpsT - t0
        if (!lastLat.isNaN()) r.distanceM += distanceM(lastLat, lastLon, lat, lon)
        lastLat = lat
        lastLon = lon
        if (kmh > r.maxSpeedKmh) r.maxSpeedKmh = kmh
        r.durationMs = off
        writer?.add(off, lat, lon, kmh.toFloat())
        if (kmh < 2.0) {
            if (stoppedSince < 0) stoppedSince = gpsT
            else if (gpsT - stoppedSince > 300_000L) end()
        } else {
            stoppedSince = -1L
        }
        return started
    }

    @Synchronized
    fun onLap(res: LapResult) {
        val r = rec ?: return
        r.laps.add(LapRecord(res.number, res.lapMs, res.splits, res.startMs - t0, res.endMs - t0))
        store.save(r)
    }

    @Synchronized
    fun end() {
        val r = rec ?: return
        writer?.close()
        writer = null
        rec = null
        if (r.laps.isEmpty()) store.delete(r.id) else store.save(r)
    }
}
