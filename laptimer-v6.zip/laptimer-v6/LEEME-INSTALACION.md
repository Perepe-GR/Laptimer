# Actualizar de la 0.5 a la 0.6

## Antes de empezar (solo esta vez)
La 0.5 y la 0.6 están firmadas con claves distintas, así que Android no las deja instalar una encima de otra:
hay que **desinstalar la 0.5**, y con ella se borran circuitos, sesiones y ajustes de la app.
A partir de la 0.6 la firma es fija y las siguientes versiones se instalan encima sin perder nada.

Antes de desinstalar, en la app 0.5:
1. **MENÚ > Ajustes y pit crew**: apunta la URL de Firebase y el código de sala (o toca *Compartir enlace del pit*
   y guarda ese enlace en Notas).
2. **MENÚ > Elegir circuito**, elige uno y luego **MENÚ > Exportar circuito**. Guarda el archivo (Notas, Drive,
   WhatsApp contigo mismo). Repite con cada circuito.
3. Opcional: en **MENÚ > Historial de sesiones**, abre cada sesión que quieras conservar y exporta CSV o GPX.

## 1. Compilar la 0.6 en GitHub
1. En tu repositorio privado: **Add file > Upload files** y sube `laptimer-v6.zip` sin descomprimir. Commit.
   El flujo de compilación usa siempre el zip con el número más alto, así que `laptimer-v5.zip` puede quedarse.
2. Pestaña **Actions**: arranca "Build APK" (3 a 5 minutos). Con ✓ verde, entra en **Releases > APK más reciente**
   y descarga `laptimer.apk` desde tu Android.
3. Si sale en rojo, copia el error del paso "Compilar APK" y pégalo en el chat.

## 2. Instalar en el Android
1. Desinstala la 0.5 (mantén pulsado el icono > Información de la app > Desinstalar).
2. Abre `laptimer.apk` e instálala.

## 3. Recuperar tus datos
1. **INICIO > AJUSTES Y PIT CREW**: activa la conexión, pega la URL de Firebase, **el mismo código de sala de antes**
   (así el enlace del panel sigue valiendo), el intervalo y la URL del panel. Guardar.
2. **INICIO > CIRCUITOS > Importar circuito**: elige cada archivo exportado.

## 4. Actualizar el panel web
1. Descomprime `laptimer-v6.zip` en Archivos, o usa el `index.html` suelto que te pasó el chat.
2. En el repositorio público `panel-pit`: **Add file > Upload files**, sube el `index.html` nuevo y **Commit changes**.
   Sustituye al anterior.
3. Espera 1 o 2 minutos. Si sigue igual, abre el panel con `?v=6` al final de la dirección para saltarte la caché.
4. Las reglas de Firebase **no cambian**.

## Gestos en la pantalla de sesión
- **Barra superior** (estado, INICIO): desliza hacia abajo desde la parte alta de la pantalla, empezando un poco
  por debajo del borde. Se oculta sola a los 5 s o deslizando hacia arriba.
- **Cambiar de vista** (completa / simplificada): desliza a izquierda o derecha empezando por el centro.
- **Mensajes del pit**: aparecen abajo con su color y desaparecen al terminar el sector siguiente al de llegada.
