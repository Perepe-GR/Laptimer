# Diseño de la pantalla del piloto (horizontal)

## Colores (aprobados, no cambiar)
- Fondo `#0B0D10`; tarjetas `#12161B` con esquinas de 16 dp
- Verde acento `#C6F432` (más rápido, mejor vuelta); rojo `#FF5A5F` (más lento)
- Texto secundario `#9AA3AE`
- Sectores tipo F1: morado `#A855F7`, verde `#C6F432`, amarillo `#FACC15`, neutro `#1E242B`
- Mensajes del pit: amarillo `#FACC15`, verde `#22C55E`, rojo `#EF4444`, azul `#2563EB`, blanco `#F2F4F7`,
  rayas = amarillo con 4 rayas rojas verticales (9 franjas iguales) y el texto sobre una etiqueta oscura

## Vista completa
1. **Delta** (protagonista): tarjeta grande a la izquierda, refresco a 5 Hz. Barra de ±2 % de la mejor vuelta.
2. **Tiempo de vuelta** con las cajitas de sector S1..Sn (colores F1).
3. **Mejor / Última / Óptima** en tres tarjetas pequeñas.
4. **Velocidad**: tarjeta compacta (40 dp), texto gris; importancia mínima a propósito.

## Vista simplificada
Delta gigante con su barra y, debajo, los sectores F1 en grande. Sin nada más.

## Elementos ocultos
- **Barra superior** (estado, INICIO, red, GPS): oculta. Se muestra deslizando hacia abajo desde la parte alta
  (no desde el borde, que lo usa Android). Se esconde sola a los 5 s o deslizando hacia arriba.
- **Banda inferior**: solo visible con un mensaje del pit o durante el reconocimiento de circuito.

## Gestos
- Cambio de vista: deslizar a izquierda o derecha empezando por el centro (no choca con el gesto "atrás").

## Reglas
- Sin sonido, sin voz y sin vibración en ningún momento.
- Por encima de 10 km/h se bloquean INICIO y los botones de marcado (no en modo demo).
